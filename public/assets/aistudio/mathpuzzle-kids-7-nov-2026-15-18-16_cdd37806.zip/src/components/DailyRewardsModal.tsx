import React, { useState } from 'react';
import { OwlMascot } from './GameIllustrations';
import { useGameAudio, formatNum } from '../utils/sound';
import {
  Gift,
  Check,
  Sparkles,
  Flame,
  Coins,
  Crown,
  Star,
  Zap,
  Lightbulb,
  X,
  Award,
} from 'lucide-react';

export interface DailyRewardDay {
  day: number;
  coins: number;
  bonusTitle: string;
  icon: string;
  description: string;
}

export const DAILY_REWARD_DAYS: DailyRewardDay[] = [
  { day: 1, coins: 25, bonusTitle: 'نجمة سحرية', icon: '🌟', description: 'بداية مشجعة لأسبوع الذكاء' },
  { day: 2, coins: 35, bonusTitle: 'تلميح ذكي', icon: '💡', description: 'تلميح فوري للألغاز الصعبة' },
  { day: 3, coins: 50, bonusTitle: 'شعلة الحماس', icon: '🔥', description: 'مضاعفة نقاط سلاسل الفوز' },
  { day: 4, coins: 65, bonusTitle: 'طاقة البرق', icon: '⚡', description: 'سرعة بديهة وحساب ذهني' },
  { day: 5, coins: 85, bonusTitle: 'وسام العبقرية', icon: '🦉', description: 'بطاقة بومة الحكمة الخاصة' },
  { day: 6, coins: 110, bonusTitle: 'جوهرة نادرة', icon: '💎', description: 'مكافأة مميزة للمثابرة' },
  { day: 7, coins: 200, bonusTitle: 'التاج الذهبي الأسطوري', icon: '👑', description: 'جائزة الأسبوع الكبرى!' },
];

export interface DailyRewardState {
  lastClaimDate: string | null; // 'YYYY-MM-DD'
  currentStreak: number; // 1 to 7
  totalCoins: number;
  claimedHistory: number[]; // e.g. [1, 2]
}

export function getTodayDateString(): string {
  const now = new Date();
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
}

export function isClaimableToday(lastClaimDate: string | null): boolean {
  if (!lastClaimDate) return true;
  return lastClaimDate !== getTodayDateString();
}

interface DailyRewardsModalProps {
  state: DailyRewardState;
  useEastern: boolean;
  onClaim: (coinsEarned: number, day: number) => void;
  onClose: () => void;
}

export const DailyRewardsModal: React.FC<DailyRewardsModalProps> = ({
  state,
  useEastern,
  onClaim,
  onClose,
}) => {
  const { playSuccess, playStarReveal, playClick } = useGameAudio();
  const [justClaimed, setJustClaimed] = useState(false);
  const [claimedDay, setClaimedDay] = useState<number | null>(null);

  const canClaim = isClaimableToday(state.lastClaimDate);
  // Streak is 1-based (1..7), so 0-based index is (currentStreak - 1) % 7.
  // If the user just claimed in this modal session, keep showing the claimed day index.
  const computedDayIndex = Math.max(0, (Math.max(1, state.currentStreak) - 1) % 7);
  const activeDayIndex = claimedDay !== null ? claimedDay - 1 : computedDayIndex;
  const todayReward = DAILY_REWARD_DAYS[activeDayIndex] || DAILY_REWARD_DAYS[0];

  const handleClaim = () => {
    if (!canClaim || justClaimed) return;
    playSuccess();
    playStarReveal(3);
    setJustClaimed(true);
    setClaimedDay(todayReward.day);
    onClaim(todayReward.coins, todayReward.day);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-pop">
      <div className="relative w-full max-w-2xl bg-[#FFFDF7] rounded-3xl border-2 border-[#E2D9C8] shadow-2xl p-6 sm:p-8 space-y-6 overflow-hidden">
        {/* Decorative corner sparkles */}
        <div className="absolute top-0 right-0 w-32 h-32 bg-amber-400/10 rounded-full blur-2xl -mr-10 -mt-10 pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-32 h-32 bg-indigo-500/10 rounded-full blur-2xl -ml-10 -mb-10 pointer-events-none" />

        {/* Modal Header */}
        <div className="flex items-center justify-between pb-3 border-b border-[#E5DEC9]">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-amber-100 text-amber-700 rounded-2xl border border-amber-300">
              <Gift className="w-6 h-6 animate-bounce" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-amber-800">مكافآت الدخول اليومي</span>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-200 text-amber-900 flex items-center gap-1">
                  <Flame className="w-3 h-3 fill-amber-600 text-amber-600" />
                  <span>سلسلة {formatNum(state.currentStreak, useEastern)} أيام</span>
                </span>
              </div>
              <h2 className="text-xl sm:text-2xl font-bold font-display text-slate-900">
                صندوق هدايا الأرقام اليومية
              </h2>
            </div>
          </div>

          <button
            type="button"
            onClick={() => {
              playClick();
              onClose();
            }}
            className="p-2 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-xl transition-colors"
            aria-label="إغلاق"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Mascot Greeting */}
        <div className="flex items-center gap-4 bg-gradient-to-l from-amber-50 via-[#FAF6EE] to-white p-4 rounded-2xl border border-amber-200">
          <OwlMascot mood={justClaimed ? 'celebrating' : canClaim ? 'super_excited' : 'happy'} size={68} />
          <div className="space-y-1 flex-1">
            <h4 className="text-sm font-bold text-slate-900">
              {justClaimed
                ? '🎉 مبروك يا بطل! أضيفت المكافأة إلى رصيدك بنجاح!'
                : canClaim
                ? `هدية اليوم جاهزة لك يا عبقري! انقر للاستلام!`
                : 'لقد استلمت هدية اليوم! عد غداً لمضاعفة مكافأتك!'}
            </h4>
            <p className="text-xs text-slate-600 leading-relaxed">
              كل يوم تسجل فيه الدخول، تحصل على عملات ذهبية تساعدك في كشف الأسرار وفتح الأوسمة والشهادات الفخرية.
            </p>
          </div>
        </div>

        {/* 7-Days Calendar Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-7 gap-2.5">
          {DAILY_REWARD_DAYS.map((item, idx) => {
            const isToday = idx === activeDayIndex;
            const isClaimed = idx < activeDayIndex || (isToday && (!canClaim || justClaimed));
            const isLocked = idx > activeDayIndex;

            return (
              <div
                key={item.day}
                className={`relative rounded-2xl p-3 flex flex-col items-center justify-between text-center transition-all border ${
                  isToday && canClaim && !justClaimed
                    ? 'bg-gradient-to-b from-amber-100 to-amber-50 border-amber-400 ring-2 ring-amber-400/50 scale-105 shadow-md animate-coin-glow'
                    : isClaimed
                    ? 'bg-emerald-50/70 border-emerald-300 text-emerald-900'
                    : 'bg-white border-slate-200 text-slate-400 opacity-80'
                }`}
              >
                <div className="text-[10px] font-bold text-slate-500 mb-1">
                  اليوم {formatNum(item.day, useEastern)}
                </div>

                <div className="text-2xl my-1 relative">
                  {item.icon}
                  {isClaimed && (
                    <span className="absolute -bottom-1 -right-1 bg-emerald-600 text-white rounded-full p-0.5">
                      <Check className="w-3 h-3 stroke-[3]" />
                    </span>
                  )}
                </div>

                <div className="space-y-0.5 mt-1">
                  <div className="font-mono-num font-bold text-xs sm:text-sm text-amber-700 flex items-center justify-center gap-0.5">
                    <span>+{formatNum(item.coins, useEastern)}</span>
                    <Coins className="w-3 h-3 text-amber-500 fill-amber-400" />
                  </div>
                  <div className="text-[9px] font-medium text-slate-500 truncate max-w-[70px]">
                    {item.bonusTitle}
                  </div>
                </div>

                {isToday && canClaim && !justClaimed && (
                  <span className="mt-2 text-[9px] font-bold text-amber-900 bg-amber-300 px-1.5 py-0.5 rounded-full">
                    متاح الآن!
                  </span>
                )}
              </div>
            );
          })}
        </div>

        {/* Claim Action / Status */}
        <div className="pt-2 flex flex-col sm:flex-row items-center justify-between gap-4 border-t border-slate-100">
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1.5 bg-[#FAF6EE] px-3.5 py-2 rounded-xl border border-[#E5DEC9]">
              <Coins className="w-4 h-4 text-amber-500 fill-amber-400 animate-spin" style={{ animationDuration: '6s' }} />
              <span className="text-xs text-slate-500">رصيدك الكلي:</span>
              <span className="font-mono-num font-bold text-base text-amber-700">
                {formatNum(state.totalCoins + (justClaimed ? todayReward.coins : 0), useEastern)} عملة
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2.5 w-full sm:w-auto">
            {canClaim && !justClaimed ? (
              <button
                type="button"
                onClick={handleClaim}
                className="tactile-button w-full sm:w-auto px-7 py-3 rounded-2xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-display font-bold text-sm border-2 border-b-4 border-amber-700 flex items-center justify-center gap-2 shadow-md animate-pop whitespace-nowrap"
              >
                <Sparkles className="w-4 h-4 text-slate-950" />
                <span>استلم {formatNum(todayReward.coins, useEastern)} عملة اليوم!</span>
              </button>
            ) : (
              <button
                type="button"
                onClick={() => {
                  playClick();
                  onClose();
                }}
                className="tactile-button w-full sm:w-auto px-6 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-display font-bold text-xs flex items-center justify-center gap-1.5 whitespace-nowrap"
              >
                <Check className="w-4 h-4 text-emerald-400" />
                <span>تم استلام مكافأة اليوم (حسناً)</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
