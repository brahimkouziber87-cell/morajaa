import React, { useState } from 'react';
import {
  ADVENTURE_LEVELS,
  DifficultyTier,
  DIFFICULTY_CONFIGS,
} from '../data/puzzles';
import { OwlMascot, PuzzleSymbolIcon } from './GameIllustrations';
import { formatNum, useGameAudio } from '../utils/sound';
import { coachService } from '../utils/pedagogicalCoach';
import { globalDeduplicator } from '../utils/mathEngine';
import { Award, RotateCcw, CheckCircle2, BarChart2, TrendingUp, Sparkles, Target, ShieldCheck, BrainCircuit } from 'lucide-react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  Cell,
  CartesianGrid,
} from 'recharts';

export interface PlayerProgress {
  playerName: string;
  levelStars: Record<number, number>;
  quickSolvedCount: number;
  currentStreak: number;
  bestStreak: number;
  difficultyStats: Record<DifficultyTier, number>;
  coins?: number;
  dailyReward?: {
    lastClaimDate: string | null;
    currentStreak: number;
  };
}

interface AchievementsProps {
  progress: PlayerProgress;
  useEastern: boolean;
  onUpdateName: (name: string) => void;
  onResetProgress: () => void;
  onSelectLevel: (levelId: number) => void;
}

interface CustomTooltipProps {
  active?: boolean;
  payload?: Array<{
    payload: {
      name: string;
      fullName: string;
      count: number;
      fill: string;
      operations: string;
      age: string;
    };
  }>;
  useEastern: boolean;
}

const CustomBarTooltip: React.FC<CustomTooltipProps> = ({ active, payload, useEastern }) => {
  if (active && payload && payload.length) {
    const data = payload[0].payload;
    return (
      <div className="bg-white/95 backdrop-blur-xs p-3.5 rounded-2xl shadow-lg border-2 border-slate-200 text-right min-w-[180px]">
        <div className="flex items-center gap-2 mb-1.5">
          <span className="w-3 h-3 rounded-full" style={{ backgroundColor: data.fill }} />
          <span className="font-bold text-sm text-slate-900 font-display">{data.fullName}</span>
        </div>
        <div className="text-xs text-slate-500 mb-1">
          الفئة العمرية: <span className="font-bold text-slate-700">{data.age}</span>
        </div>
        <div className="text-xs text-slate-600 mb-2">
          العمليات: <span className="font-mono-num font-bold text-indigo-700">{data.operations}</span>
        </div>
        <div className="bg-slate-50 px-2.5 py-1.5 rounded-xl border border-slate-200/80 flex items-center justify-between">
          <span className="text-xs text-slate-600">الألغاز المكتملة:</span>
          <span className="font-mono-num font-bold text-base text-slate-900">
            {formatNum(data.count, useEastern)} لغز
          </span>
        </div>
      </div>
    );
  }
  return null;
};

export const AchievementsView: React.FC<AchievementsProps> = ({
  progress,
  useEastern,
  onUpdateName,
  onResetProgress,
}) => {
  const [confirmReset, setConfirmReset] = useState(false);
  const { playClick } = useGameAudio();

  const totalStarsEarned = Object.values(progress.levelStars).reduce((a, b) => a + b, 0);
  const maxAdventureStars = ADVENTURE_LEVELS.length * 3;
  const completedLevelsCount = Object.keys(progress.levelStars).length;
  const totalSolvedAll = (progress.difficultyStats?.easy ?? 0) +
    (progress.difficultyStats?.medium ?? 0) +
    (progress.difficultyStats?.hard ?? 0);

  // Prepare Recharts Data
  const chartData = [
    {
      key: 'easy',
      name: 'سهل',
      fullName: 'المستوى السهل',
      count: progress.difficultyStats?.easy ?? 0,
      fill: '#10B981', // Emerald
      operations: '+ ، -',
      age: '5 - 7 سنوات',
      target: 10,
    },
    {
      key: 'medium',
      name: 'متوسط',
      fullName: 'المستوى المتوسط',
      count: progress.difficultyStats?.medium ?? 0,
      fill: '#F59E0B', // Amber
      operations: '+ ، - ، ×',
      age: '7 - 9 سنوات',
      target: 10,
    },
    {
      key: 'hard',
      name: 'صعب',
      fullName: 'المستوى الصعب',
      count: progress.difficultyStats?.hard ?? 0,
      fill: '#EF4444', // Rose/Red
      operations: '+ ، - ، × ، ÷',
      age: '9 - 12 سنة',
      target: 10,
    },
  ];

  const maxVal = Math.max(5, ...chartData.map((d) => d.count)) + 2;

  const medals = [
    {
      id: 'first_step',
      title: 'وسام الخطوة الأولى',
      desc: 'إتمام أول لغز بنجاح في وادي الجسور',
      unlocked: completedLevelsCount >= 1 || progress.quickSolvedCount >= 1,
      icon: 'star' as const,
    },
    {
      id: 'easy_champ',
      title: 'بطل المستوى السهل',
      desc: 'إتقان عمليات الجمع والطرح للأعداد الصغيرة (1 - 15)',
      unlocked: (progress.difficultyStats?.easy ?? 0) >= 3 || completedLevelsCount >= 2,
      icon: 'apple' as const,
    },
    {
      id: 'medium_master',
      title: 'فارس المستوى المتوسط',
      desc: 'حل ألغاز الأعداد حتى 50 مع جداول الضرب البسيطة',
      unlocked:
        (progress.difficultyStats?.medium ?? 0) >= 3 ||
        [3, 5, 8, 11].some((id) => (progress.levelStars[id] ?? 0) > 0),
      icon: 'gem' as const,
    },
    {
      id: 'hard_genius',
      title: 'عبقري المستوى المتقدم',
      desc: 'حل أصعب المعادلات والشبكات الكبرى حتى 100',
      unlocked:
        (progress.difficultyStats?.hard ?? 0) >= 2 ||
        [6, 9, 12].some((id) => (progress.levelStars[id] ?? 0) > 0),
      icon: 'crown' as const,
    },
    {
      id: 'streak_hero',
      title: 'سلسلة العباقرة المتواصلة',
      desc: 'حل 3 ألغاز متتالية بنجاح دون أخطاء',
      unlocked: progress.bestStreak >= 3,
      icon: 'crystal' as const,
    },
    {
      id: 'grand_champion',
      title: 'وسام التميز الرياضي الكبير',
      desc: 'جمع 20 نجمة ذهبية أو إكمال جميع جزر التعلم',
      unlocked: totalStarsEarned >= 20 || completedLevelsCount >= 10,
      icon: 'moon' as const,
    },
  ];

  return (
    <div className="max-w-5xl mx-auto space-y-10 pb-12">
      {/* Top Header Card */}
      <div className="tactile-card rounded-2xl p-6 bg-white">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 pb-6 border-b border-slate-200/80">
          <div className="flex items-center gap-4">
            <OwlMascot mood="happy" size={68} />
            <div>
              <h1 className="text-2xl font-bold font-display text-slate-900">
                سجل الإنجازات والتقدم الرياضي
              </h1>
              <p className="text-sm text-slate-600 mt-1">
                تتبع بياني مرئي لعدد الألغاز المحلولة في كل مستوى (سهل، متوسط، صعب)
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <label htmlFor="explorer-name" className="text-xs font-bold text-slate-600 whitespace-nowrap">
              اسم البطل:
            </label>
            <input
              id="explorer-name"
              type="text"
              value={progress.playerName}
              onChange={(e) => onUpdateName(e.target.value)}
              placeholder="اكتب اسمك هنا..."
              className="px-3.5 py-2 rounded-xl border border-slate-300 text-sm font-bold text-slate-900 bg-[#FAF6EE] focus:outline-none focus:border-amber-500 w-48"
            />
          </div>
        </div>

        {/* Difficulty Breakdown Stats */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-6 pt-6">
          <div>
            <span className="text-xs text-slate-500 block">مجموع النجوم</span>
            <span className="font-mono-num text-2xl font-bold text-amber-600 mt-1 block">
              {formatNum(totalStarsEarned, useEastern)} / {formatNum(maxAdventureStars, useEastern)}
            </span>
          </div>
          <div>
            <span className="text-xs text-slate-500 block">إجمالي التحديات المحلولة</span>
            <span className="font-mono-num text-2xl font-bold text-indigo-700 mt-1 block">
              {formatNum(totalSolvedAll, useEastern)} لغز
            </span>
          </div>
          <div>
            <span className="text-xs text-slate-500 block">أعلى سلسلة إجابات صحيحة</span>
            <span className="font-mono-num text-2xl font-bold text-emerald-700 mt-1 block">
              {formatNum(progress.bestStreak, useEastern)} متتالية
            </span>
          </div>
          <div>
            <span className="text-xs text-slate-500 block">المراحل المكتملة بالخريطة</span>
            <span className="font-mono-num text-2xl font-bold text-sky-700 mt-1 block">
              {formatNum(completedLevelsCount, useEastern)} / {formatNum(ADVENTURE_LEVELS.length, useEastern)}
            </span>
          </div>
        </div>
      </div>

      {/* ===================================================================
          RECHARTS BAR CHART: Solved Puzzles per Difficulty Level
      =================================================================== */}
      <div className="tactile-card rounded-3xl p-6 sm:p-7 bg-white space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-100">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-amber-50 text-amber-700 rounded-2xl border border-amber-200">
              <BarChart2 className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold font-display text-slate-900">
                الرسم البياني لإنجاز الألغاز حسب مستوى الصعوبة
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                يوضح عدد التحديات التي حلها الطفل في كل مستوى (سهل، متوسط، صعب)
              </p>
            </div>
          </div>
          <div className="flex items-center gap-3 text-xs font-bold text-slate-600">
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded-full bg-emerald-500 inline-block" />
              <span>سهل ({formatNum(progress.difficultyStats?.easy ?? 0, useEastern)})</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded-full bg-amber-500 inline-block" />
              <span>متوسط ({formatNum(progress.difficultyStats?.medium ?? 0, useEastern)})</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded-full bg-rose-500 inline-block" />
              <span>صعب ({formatNum(progress.difficultyStats?.hard ?? 0, useEastern)})</span>
            </div>
          </div>
        </div>

        {/* Visual Chart Container */}
        <div className="w-full h-72 sm:h-80 select-none" dir="ltr">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={chartData}
              margin={{ top: 20, right: 30, left: 10, bottom: 20 }}
              barSize={54}
            >
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E2E8F0" />
              <XAxis
                dataKey="name"
                tick={{ fill: '#334155', fontSize: 14, fontWeight: 700, fontFamily: 'Tajawal, sans-serif' }}
                axisLine={{ stroke: '#CBD5E1' }}
                tickLine={false}
              />
              <YAxis
                allowDecimals={false}
                domain={[0, maxVal]}
                tick={{ fill: '#64748B', fontSize: 12, fontFamily: 'IBM Plex Mono, monospace' }}
                axisLine={{ stroke: '#CBD5E1' }}
                tickLine={false}
              />
              <Tooltip
                content={<CustomBarTooltip useEastern={useEastern} />}
                cursor={{ fill: 'rgba(241, 245, 249, 0.6)' }}
              />
              <Bar dataKey="count" radius={[12, 12, 0, 0]}>
                {chartData.map((entry, index) => (
                  <Cell
                    key={`cell-${index}`}
                    fill={entry.fill}
                    className="transition-all duration-300 hover:opacity-85"
                  />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Detailed 3-tier metric tiles below the chart */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
          {chartData.map((tier) => {
            const pctOfGoal = Math.min(100, Math.round((tier.count / tier.target) * 100));
            return (
              <div
                key={tier.key}
                className="p-4 rounded-2xl bg-[#FAF6EE] border border-[#E5DEC9] flex flex-col justify-between space-y-2"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-3 h-3 rounded-full" style={{ backgroundColor: tier.fill }} />
                    <span className="font-bold text-sm text-slate-900 font-display">
                      {tier.fullName}
                    </span>
                  </div>
                  <span className="text-[10px] font-bold text-slate-500 font-mono-num">
                    {tier.age}
                  </span>
                </div>

                <div className="flex items-baseline justify-between pt-1">
                  <span className="text-xs text-slate-500">تم حل:</span>
                  <span className="font-mono-num text-xl font-bold text-slate-900">
                    {formatNum(tier.count, useEastern)}{' '}
                    <span className="text-xs text-slate-400 font-normal">/ {formatNum(tier.target, useEastern)} هدف</span>
                  </span>
                </div>

                {/* Micro Progress Bar */}
                <div className="w-full h-2 bg-slate-200/80 rounded-full overflow-hidden">
                  <div
                    className="h-full rounded-full transition-all duration-500"
                    style={{
                      width: `${pctOfGoal}%`,
                      backgroundColor: tier.fill,
                    }}
                  />
                </div>

                <div className="flex items-center justify-between text-[11px] text-slate-500 pt-0.5">
                  <span>العمليات: {tier.operations}</span>
                  <span className="font-bold font-mono-num">{formatNum(pctOfGoal, useEastern)}%</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Difficulty Breakdown Cards */}
      <div className="space-y-4">
        <h2 className="text-xl font-bold font-display text-slate-900">
          خصائص مستويات الصعوبة والعمليات المقررة
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {(['easy', 'medium', 'hard'] as DifficultyTier[]).map((tier) => {
            const meta = DIFFICULTY_CONFIGS[tier];
            const count = progress.difficultyStats?.[tier] ?? 0;
            return (
              <div key={tier} className="tactile-card rounded-2xl p-5 bg-white space-y-3">
                <div className="flex items-center justify-between">
                  <span className={`text-xs font-bold px-2.5 py-1 rounded-lg border ${meta.badgeBg}`}>
                    {meta.label}
                  </span>
                  <span className="text-xs text-slate-500 font-bold">{meta.ageRange}</span>
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900 mt-1">
                    العمليات: {meta.operations.join(' ، ')}
                  </h3>
                  <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                    {meta.description} (نطاق الأعداد: {meta.numbersRange})
                  </p>
                </div>
                <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs">
                  <span className="text-slate-500">الألغاز المحلولة:</span>
                  <span className="font-mono-num font-bold text-slate-900">
                    {formatNum(count, useEastern)} لغز
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Pedagogical Diagnostics & Non-Repeating Operations Report */}
      <div className="tactile-card rounded-3xl p-6 sm:p-7 bg-white space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-100">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-indigo-50 text-indigo-700 rounded-2xl border border-indigo-200">
              <BrainCircuit className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold font-display text-slate-900">
                التشخيص التربوي الذكي ومحرك منع تكرار العمليات
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                تحليل علمي لأنماط الأخطاء الرياضية وضمان التنوع الكامل في المسائل المولدة
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-emerald-50 border border-emerald-200 text-xs font-bold text-emerald-800">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <span>
              عمليات فريدة بلا تكرار: {formatNum(Math.max(totalSolvedAll, globalDeduplicator.getUniqueCount()), useEastern)} عملية
            </span>
          </div>
        </div>

        {(() => {
          const stats = coachService.getPatternStats();
          if (stats.length === 0) {
            return (
              <div className="p-5 rounded-2xl bg-[#FAF6EE] border border-[#E5DEC9] flex flex-col sm:flex-row items-center justify-between gap-4">
                <div className="space-y-1 text-center sm:text-right">
                  <div className="text-xs font-bold text-emerald-700">
                    ✓ سجل خالٍ من الأخطاء المنهجية المتكررة في هذه الجلسة
                  </div>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    يعمل محرك الرياضيات (Fisher-Yates + التوقيع الجبري الموحد) على توليد مسائل غير مكررة مع مراقبة 10 أنماط من الأخطاء الشائعة (مثل أولوية العمليات، والاحتفاظ، والخلط بين الضرب والجمع).
                  </p>
                </div>
                <span className="px-3.5 py-1.5 rounded-xl bg-white border border-emerald-200 text-xs font-bold text-emerald-800 whitespace-nowrap">
                  دقة مفاهيمية ممتازة 🌟
                </span>
              </div>
            );
          }

          return (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
              {stats.map((item) => (
                <div
                  key={item.type}
                  className="p-4 rounded-2xl bg-[#FAF6EE] border border-[#E5DEC9] space-y-1.5"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-indigo-900">{item.title}</span>
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-mono-num font-bold bg-amber-100 text-amber-900 border border-amber-300">
                      تكرر {formatNum(item.count, useEastern)} مرات
                    </span>
                  </div>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    <span className="font-bold text-emerald-800">التوصية التربوية: </span>
                    {item.remediation}
                  </p>
                </div>
              ))}
            </div>
          );
        })()}
      </div>

      {/* Medals */}
      <div className="space-y-4">
        <h2 className="text-xl font-bold font-display text-slate-900">أوسمة الشرف والتفوق</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {medals.map((medal) => (
            <div
              key={medal.id}
              className={`tactile-card rounded-2xl p-5 flex items-start gap-4 transition-opacity ${
                medal.unlocked ? 'bg-white' : 'bg-slate-50/70 opacity-65'
              }`}
            >
              <div className="p-3 rounded-2xl bg-[#FAF6EE] border border-[#E5DEC9] shrink-0">
                <PuzzleSymbolIcon type={medal.icon} size={36} />
              </div>
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <h3 className="text-sm font-bold font-display text-slate-900">{medal.title}</h3>
                  {medal.unlocked && (
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" aria-label="مكتسب" />
                  )}
                </div>
                <p className="text-xs text-slate-600 leading-relaxed">{medal.desc}</p>
                <p className="text-xs font-medium text-slate-500 pt-1">
                  {medal.unlocked ? '✓ تم فتح الوسام' : '· قيد الإنجاز'}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Certificate of Excellence */}
      <div className="tactile-card rounded-2xl p-8 bg-gradient-to-b from-[#FFFDF9] to-[#FAF3E0] border-2 border-amber-300 text-center space-y-4">
        <div className="flex justify-center">
          <Award className="w-12 h-12 text-amber-600" />
        </div>
        <p className="text-xs font-bold text-amber-800">شهادة تقدير وتفوق في الحساب الذهني</p>
        <h2 className="text-2xl sm:text-3xl font-bold font-display text-slate-900">
          يشهد مختبر الأرقام (MathPuzzle Kids) بأن البطل
        </h2>
        <div className="inline-block px-8 py-2 border-b-2 border-amber-600 text-2xl font-bold font-display text-indigo-950">
          {progress.playerName.trim() || 'فارس الرياضيات الصغير'}
        </div>
        <p className="text-sm text-slate-700 max-w-xl mx-auto leading-relaxed">
          قد أظهر مهارات استثنائية في حل الألغاز عبر مختلف مستويات الصعوبة، وحقق مجموع{' '}
          <span className="font-mono-num font-bold text-amber-700">
            {formatNum(totalStarsEarned, useEastern)}
          </span>{' '}
          نجمة ذهبية مع إتمام{' '}
          <span className="font-mono-num font-bold text-emerald-700">
            {formatNum(totalSolvedAll, useEastern)}
          </span>{' '}
          تحدياً رياضياً بنجاح وتفوق!
        </p>
      </div>

      {/* Reset progress */}
      <div className="flex items-center justify-end pt-2">
        {!confirmReset ? (
          <button
            type="button"
            onClick={() => setConfirmReset(true)}
            className="text-xs font-medium text-slate-500 hover:text-rose-700 flex items-center gap-1.5 transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>إعادة تصفير سجل التقدم</span>
          </button>
        ) : (
          <div className="flex items-center gap-3 bg-rose-50 px-4 py-2 rounded-xl border border-rose-200">
            <span className="text-xs font-bold text-rose-900">تأكيد مسح النجوم والإنجازات؟</span>
            <button
              type="button"
              onClick={() => {
                playClick();
                onResetProgress();
                setConfirmReset(false);
              }}
              className="px-3 py-1 text-xs font-bold bg-rose-600 text-white rounded-lg hover:bg-rose-700"
            >
              نعم، تصفير
            </button>
            <button
              type="button"
              onClick={() => setConfirmReset(false)}
              className="px-3 py-1 text-xs font-bold text-slate-700 hover:text-slate-900"
            >
              إلغاء
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
