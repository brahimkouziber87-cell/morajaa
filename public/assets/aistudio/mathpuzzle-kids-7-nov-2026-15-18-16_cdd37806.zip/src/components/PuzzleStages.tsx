import React, { useState, useEffect, useRef } from 'react';
import {
  LevelConfig,
  BridgePuzzleData,
  BalancePuzzleData,
  MagicGridData,
  CodeBreakerData,
  SpeedMathProblem,
  DifficultyTier,
  generateSpeedProblems,
  DIFFICULTY_CONFIGS,
} from '../data/puzzles';
import { PuzzleSymbolIcon, SYMBOL_NAMES_AR, SymbolType } from './GameIllustrations';
import { sound, formatNum } from '../utils/sound';
import { Check, RotateCcw, Sparkles, Scale, ArrowRight, Zap, Timer } from 'lucide-react';

export interface MistakeDetails {
  guessed: number;
  expected: number;
  operator?: string;
  context?: string;
  num1?: number;
  num2?: number;
}

interface StageProps {
  level: LevelConfig;
  useEastern: boolean;
  hintLevel: number;
  onSolve: (earnedStars: number) => void;
  onMistake: (feedbackMsg: string, details?: MistakeDetails) => void;
}

// ============================================================================
// 1. BRIDGE & SEQUENCE PUZZLE STAGE
// ============================================================================
export const BridgePuzzleStage: React.FC<StageProps> = ({
  level,
  useEastern,
  hintLevel,
  onSolve,
  onMistake,
}) => {
  const data = level.bridgeData as BridgePuzzleData;
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [shake, setShake] = useState(false);
  const [solved, setSolved] = useState(false);
  const [mistakes, setMistakes] = useState(0);

  useEffect(() => {
    setSelectedOption(null);
    setShake(false);
    setSolved(false);
    setMistakes(0);
  }, [level]);

  const handleSelectOption = (num: number) => {
    if (solved) return;
    sound.playClick();
    setSelectedOption(num);
  };

  const handleVerify = () => {
    if (selectedOption === null || solved) return;
    if (selectedOption === data.correctAnswer) {
      setSolved(true);
      sound.playSuccess();
      const stars = mistakes === 0 ? 3 : mistakes === 1 ? 2 : 1;
      setTimeout(() => onSolve(stars), 650);
    } else {
      setMistakes((m) => m + 1);
      setShake(true);
      sound.playRetry();
      const diff = selectedOption - data.correctAnswer;
      const hintMsg =
        diff > 0
          ? `العدد ${formatNum(selectedOption, useEastern)} أكبر من المطلوب بقليل. جرب عدداً أصغر!`
          : `العدد ${formatNum(selectedOption, useEastern)} أصغر من المطلوب بقليل. جرب عدداً أكبر!`;
      onMistake(hintMsg, {
        guessed: selectedOption,
        expected: data.correctAnswer,
        operator: data.equation?.operator || '+',
        context: data.subType || 'bridge',
        num1: data.equation?.left ?? undefined,
        num2: data.equation?.right ?? undefined,
      });
      setTimeout(() => setShake(false), 400);
    }
  };

  const renderVisualGroup = (count: number, iconType: SymbolType = 'apple') => {
    const safeCount = Math.min(15, Math.max(0, count));
    return (
      <div className="flex flex-wrap items-center justify-center gap-1.5 max-w-[170px] p-2.5 bg-[#FAF6EE] rounded-xl border border-[#E5DEC9]">
        {Array.from({ length: safeCount }, (_, i) => (
          <PuzzleSymbolIcon key={i} type={iconType} size={22} className="animate-pop" />
        ))}
      </div>
    );
  };

  return (
    <div className={`space-y-6 ${shake ? 'animate-shake' : ''}`}>
      {/* Visual Canvas */}
      <div className="relative rounded-2xl bg-gradient-to-b from-[#E0F2FE] to-[#BAE6FD] border-2 border-[#7DD3FC] p-6 overflow-hidden">
        <div className="flex items-center justify-between text-xs font-bold text-sky-800 mb-4">
          <span>الضفة الأولى</span>
          <span className="bg-white/80 px-2.5 py-0.5 rounded-full border border-sky-300">
            جسر الأرقام ({DIFFICULTY_CONFIGS[level.difficulty].label})
          </span>
          <span>الضفة المقابلة</span>
        </div>

        {data.subType === 'sequence' && data.sequence ? (
          <div className="py-4">
            {(hintLevel >= 1 || solved) && data.stepRule && (
              <div className="flex items-center justify-center gap-4 sm:gap-8 mb-2" dir="ltr">
                {[0, 1, 2, 3].map((i) => (
                  <div
                    key={i}
                    className="text-xs font-mono-num font-bold text-emerald-800 bg-emerald-100/90 px-2 py-0.5 rounded border border-emerald-300"
                  >
                    {formatNum(data.stepRule!, useEastern)} <ArrowRight className="inline w-3 h-3" />
                  </div>
                ))}
              </div>
            )}

            <div className="flex items-center justify-center gap-2.5 sm:gap-4 flex-wrap" dir="ltr">
              {data.sequence.map((stone, idx) => {
                const isMissing = stone === null;
                const displayVal = isMissing ? selectedOption : stone;
                return (
                  <div
                    key={idx}
                    className={`w-14 h-16 sm:w-18 sm:h-20 rounded-2xl flex flex-col items-center justify-center font-mono-num text-xl sm:text-2xl font-bold border-b-4 transition-all ${
                      isMissing
                        ? solved
                          ? 'bg-emerald-500 text-white border-emerald-700 scale-105'
                          : selectedOption !== null
                          ? 'bg-amber-400 text-slate-900 border-amber-600 scale-105'
                          : 'bg-white/90 text-amber-600 border-amber-400 border-dashed border-2'
                        : 'bg-[#F8FAFC] text-slate-800 border-slate-400'
                    }`}
                  >
                    <span>
                      {displayVal !== null && displayVal !== undefined
                        ? formatNum(displayVal, useEastern)
                        : '؟'}
                    </span>
                    <span className="text-[10px] font-sans font-normal opacity-75">
                      حجر {formatNum(idx + 1, useEastern)}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>
        ) : (
          /* Equation Bridge */
          <div className="py-2 space-y-4">
            {data.equation && (
              <div className="flex flex-col items-center gap-4">
                {level.difficulty === 'easy' && (
                  <div className="flex flex-wrap items-center justify-center gap-4" dir="ltr">
                    {data.equation.left !== null &&
                      renderVisualGroup(data.equation.left, data.visualIcon || 'apple')}
                    <span className="text-2xl font-bold text-sky-900 font-mono-num">
                      {data.equation.operator}
                    </span>
                    {data.equation.right !== null ? (
                      renderVisualGroup(data.equation.right, data.visualIcon || 'apple')
                    ) : selectedOption !== null ? (
                      renderVisualGroup(selectedOption, data.visualIcon || 'apple')
                    ) : (
                      <div className="px-4 py-2.5 rounded-xl border-2 border-dashed border-amber-500 bg-amber-50/80 text-amber-800 text-xs font-bold">
                        اختر عدداً لترى التمثيل
                      </div>
                    )}
                  </div>
                )}

                <div
                  className="flex items-center justify-center gap-3 sm:gap-4 bg-white/95 px-6 py-4 rounded-2xl border-b-4 border-sky-300"
                  dir="ltr"
                >
                  <div className="w-14 h-14 rounded-xl bg-slate-100 border-b-3 border-slate-300 flex items-center justify-center font-mono-num text-2xl font-bold text-slate-800">
                    {data.equation.left !== null
                      ? formatNum(data.equation.left, useEastern)
                      : selectedOption !== null
                      ? formatNum(selectedOption, useEastern)
                      : '؟'}
                  </div>

                  <span className="font-mono-num text-2xl font-bold text-amber-600">
                    {data.equation.operator}
                  </span>

                  <div
                    className={`w-14 h-14 rounded-xl flex items-center justify-center font-mono-num text-2xl font-bold border-b-3 ${
                      data.equation.right === null
                        ? solved
                          ? 'bg-emerald-500 text-white border-emerald-700'
                          : 'bg-amber-100 text-amber-900 border-amber-400 border-2 border-dashed'
                        : 'bg-slate-100 text-slate-800 border-slate-300'
                    }`}
                  >
                    {data.equation.right !== null
                      ? formatNum(data.equation.right, useEastern)
                      : selectedOption !== null
                      ? formatNum(selectedOption, useEastern)
                      : '؟'}
                  </div>

                  <span className="font-mono-num text-2xl font-bold text-slate-500">=</span>

                  <div
                    className={`w-16 h-14 rounded-xl flex items-center justify-center font-mono-num text-2xl font-bold border-b-3 ${
                      data.equation.result === null
                        ? solved
                          ? 'bg-emerald-500 text-white border-emerald-700'
                          : 'bg-amber-100 text-amber-900 border-amber-400 border-2 border-dashed'
                        : 'bg-slate-100 text-slate-800 border-slate-300'
                    }`}
                  >
                    {data.equation.result !== null
                      ? formatNum(data.equation.result, useEastern)
                      : selectedOption !== null
                      ? formatNum(selectedOption, useEastern)
                      : '؟'}
                  </div>
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Options */}
      <div className="space-y-3">
        <p className="text-sm font-bold text-slate-700 text-center">{data.prompt}</p>
        <div className="flex items-center justify-center gap-3 flex-wrap" dir="ltr">
          {data.options.map((opt) => {
            const isSelected = selectedOption === opt;
            return (
              <button
                key={opt}
                type="button"
                onClick={() => handleSelectOption(opt)}
                className={`tactile-button w-15 h-15 sm:w-16 sm:h-16 rounded-2xl font-mono-num text-2xl font-bold flex items-center justify-center border-2 border-b-4 transition-all ${
                  isSelected
                    ? 'bg-amber-500 text-white border-amber-700 scale-105'
                    : 'bg-white text-slate-800 border-[#D6CFC2] hover:border-amber-400 hover:bg-amber-50/40'
                }`}
              >
                {formatNum(opt, useEastern)}
              </button>
            );
          })}
        </div>
      </div>

      <div className="flex justify-center pt-2">
        <button
          type="button"
          onClick={handleVerify}
          disabled={selectedOption === null || solved}
          className="tactile-button px-8 py-3.5 rounded-xl font-display font-bold text-base text-white bg-emerald-600 hover:bg-emerald-500 border-b-4 border-emerald-800 disabled:opacity-40 flex items-center gap-2 whitespace-nowrap"
        >
          <Check className="w-5 h-5" />
          <span>تحقق من حجر الجسر</span>
        </button>
      </div>
    </div>
  );
};

// ============================================================================
// 2. INTERACTIVE BALANCE SCALE LAB STAGE
// ============================================================================
export const BalanceLabStage: React.FC<StageProps> = ({
  level,
  useEastern,
  onSolve,
  onMistake,
}) => {
  const data = level.balanceData as BalancePuzzleData;
  const [selectedMysteryGuess, setSelectedMysteryGuess] = useState<number | null>(null);
  const [testedWrongGuess, setTestedWrongGuess] = useState<number | null>(null);
  const [shake, setShake] = useState(false);
  const [solved, setSolved] = useState(false);
  const [mistakes, setMistakes] = useState(0);

  useEffect(() => {
    setSelectedMysteryGuess(null);
    setTestedWrongGuess(null);
    setShake(false);
    setSolved(false);
    setMistakes(0);
  }, [level]);

  const leftKnownSum = data.leftFixedWeights.reduce((a, b) => a + b, 0);
  const rightTotal = data.rightFixedWeights.reduce((a, b) => a + b, 0);

  // Compute physical beam tilt angle only after verification attempt or solve
  // Positive deg tilts right pan down (right heavier), Negative deg tilts left pan down (left heavier)
  let beamTiltDeg = 0;
  if (!solved && testedWrongGuess !== null) {
    const simulatedLeft = leftKnownSum + data.leftMysteryCount * testedWrongGuess;
    const torqueDiff = rightTotal - simulatedLeft;
    beamTiltDeg = Math.max(-11, Math.min(11, torqueDiff * 1.6));
  }

  const handleVerify = () => {
    if (solved || selectedMysteryGuess === null) return;
    if (selectedMysteryGuess === data.targetAnswer) {
      setSolved(true);
      setTestedWrongGuess(null);
      sound.playSuccess();
      const stars = mistakes === 0 ? 3 : mistakes === 1 ? 2 : 1;
      setTimeout(() => onSolve(stars), 650);
    } else {
      setMistakes((m) => m + 1);
      setTestedWrongGuess(selectedMysteryGuess);
      setShake(true);
      sound.playRetry();
      const simLeft = leftKnownSum + data.leftMysteryCount * selectedMysteryGuess;
      const comparisonWord = simLeft > rightTotal ? 'أثقل' : 'أخف';
      onMistake(
        `لو كان وزن الصندوق ${formatNum(selectedMysteryGuess, useEastern)} لأصبحت الكفة اليسرى (${formatNum(
          simLeft,
          useEastern
        )}) ${comparisonWord} من الكفة اليمنى (${formatNum(rightTotal, useEastern)})!`,
        {
          guessed: selectedMysteryGuess,
          expected: data.targetAnswer,
          operator: '+',
          context: 'balance',
        }
      );
      setTimeout(() => setShake(false), 400);
    }
  };

  return (
    <div className={`space-y-6 ${shake ? 'animate-shake' : ''}`}>
      <div className="flex items-center justify-between bg-[#FAF6EE] px-4 py-2.5 rounded-xl border border-[#E5DEC9]">
        <div className="flex items-center gap-2 text-xs font-bold text-slate-700">
          <Scale className="w-4 h-4 text-sky-600" />
          <span>حالة الميزان:</span>
          {solved ? (
            <span className="text-emerald-700">
              ● متعادل تماماً ({formatNum(rightTotal, useEastern)} = {formatNum(rightTotal, useEastern)})
            </span>
          ) : testedWrongGuess !== null ? (
            <span className="text-rose-700">
              ● غير متوازن (الكفة اليسرى {formatNum(leftKnownSum + data.leftMysteryCount * testedWrongGuess, useEastern)} ≠ اليمنى {formatNum(rightTotal, useEastern)})
            </span>
          ) : (
            <span className="text-amber-700">● اختر وزن الصندوق (؟) ثم اضغط تحقق</span>
          )}
        </div>
        <span className="text-xs font-bold text-slate-500">
          المستوى: {DIFFICULTY_CONFIGS[level.difficulty].label}
        </span>
      </div>

      <div className="relative bg-gradient-to-b from-[#F8FAFC] to-[#F1F5F9] rounded-2xl border-2 border-slate-200 p-6 pt-10 pb-8 flex flex-col items-center">
        <div
          className="relative w-full max-w-lg transition-transform duration-500 ease-out"
          style={{ transform: `rotate(${beamTiltDeg}deg)` }}
          dir="ltr"
        >
          <div className="flex items-end justify-between px-2 sm:px-6 mb-2">
            {/* Pan 1 (Left) */}
            <div className="flex flex-col items-center w-44">
              <div className="flex flex-wrap items-end justify-center gap-1.5 min-h-[68px] p-2">
                {Array.from({ length: data.leftMysteryCount }, (_, i) => (
                  <div
                    key={`mys-${i}`}
                    className={`w-13 h-13 rounded-xl text-white border-2 border-b-4 flex flex-col items-center justify-center font-mono-num font-bold shadow-xs transition-colors ${
                      solved
                        ? 'bg-emerald-500 border-emerald-700'
                        : testedWrongGuess !== null
                        ? 'bg-rose-500 border-rose-700'
                        : 'bg-amber-500 border-amber-700'
                    }`}
                  >
                    <span className="text-lg">
                      {solved
                        ? formatNum(data.mysteryBoxValue, useEastern)
                        : selectedMysteryGuess !== null
                        ? formatNum(selectedMysteryGuess, useEastern)
                        : '؟'}
                    </span>
                    <span className="text-[10px] font-sans">صندوق</span>
                  </div>
                ))}
                {data.leftFixedWeights.map((w, i) => (
                  <div
                    key={`lf-${i}`}
                    className="w-12 h-12 rounded-xl bg-sky-600 text-white border-2 border-b-4 border-sky-800 flex items-center justify-center font-mono-num text-lg font-bold"
                  >
                    {formatNum(w, useEastern)}
                  </div>
                ))}
              </div>
              <div className="w-40 h-3.5 bg-slate-700 rounded-b-xl border-t-2 border-slate-400" />
              <div className="w-3 h-6 bg-slate-500" />
            </div>

            {/* Pan 2 (Right) */}
            <div className="flex flex-col items-center w-44">
              <div className="flex flex-wrap items-end justify-center gap-1.5 min-h-[68px] p-2">
                {data.rightFixedWeights.map((w, i) => (
                  <div
                    key={`rf-${i}`}
                    className="w-12 h-12 rounded-xl bg-sky-600 text-white border-2 border-b-4 border-sky-800 flex items-center justify-center font-mono-num text-lg font-bold"
                  >
                    {formatNum(w, useEastern)}
                  </div>
                ))}
              </div>
              <div className="w-40 h-3.5 bg-slate-700 rounded-b-xl border-t-2 border-slate-400" />
              <div className="w-3 h-6 bg-slate-500" />
            </div>
          </div>

          <div className="w-full h-4 bg-amber-700 rounded-full border-2 border-amber-900 shadow-xs" />
        </div>

        <div className="flex flex-col items-center -mt-1">
          <div className="w-0 h-0 border-l-[22px] border-l-transparent border-r-[22px] border-r-transparent border-b-[38px] border-b-slate-700" />
          <div className="w-32 h-3 bg-slate-800 rounded-full" />
        </div>

        <div className="mt-4 px-4 py-2 bg-white rounded-xl border border-slate-200 font-mono-num text-sm font-bold text-slate-700" dir="ltr">
          {data.leftMysteryCount > 1 ? `${formatNum(data.leftMysteryCount, useEastern)} × ` : ''}
          [ {selectedMysteryGuess !== null ? formatNum(selectedMysteryGuess, useEastern) : '؟'} ] +{' '}
          {formatNum(leftKnownSum, useEastern)} = {formatNum(rightTotal, useEastern)}
        </div>
      </div>

      <div className="space-y-3">
        <p className="text-sm font-bold text-slate-700 text-center">{data.prompt}</p>
        <div className="flex items-center justify-center gap-3 flex-wrap" dir="ltr">
          {data.availableWeights.map((w) => {
            const isSelected = selectedMysteryGuess === w;
            return (
              <button
                key={w}
                type="button"
                onClick={() => {
                  sound.playClick();
                  setSelectedMysteryGuess(w);
                  setTestedWrongGuess(null);
                }}
                className={`tactile-button w-16 h-16 rounded-2xl font-mono-num text-xl font-bold flex flex-col items-center justify-center border-2 border-b-4 transition-all ${
                  isSelected
                    ? 'bg-amber-500 text-white border-amber-700 scale-105'
                    : 'bg-white text-slate-800 border-[#D6CFC2] hover:border-sky-500 hover:bg-sky-50/40'
                }`}
              >
                <span>{formatNum(w, useEastern)}</span>
                <span className="text-[10px] font-sans font-normal text-slate-400">وزن</span>
              </button>
            );
          })}
        </div>
      </div>

      <div className="flex justify-center pt-2">
        <button
          type="button"
          onClick={handleVerify}
          disabled={solved || selectedMysteryGuess === null}
          className="tactile-button px-8 py-3.5 rounded-xl font-display font-bold text-base text-white bg-emerald-600 hover:bg-emerald-500 border-b-4 border-emerald-800 disabled:opacity-40 flex items-center gap-2 whitespace-nowrap"
        >
          <Check className="w-5 h-5" />
          <span>تحقق من توازن الميزان</span>
        </button>
      </div>
    </div>
  );
};

// ============================================================================
// 3. MAGIC NUMBER GRID STAGE
// ============================================================================
function findFirstEmptyCell(grid: (number | null)[][]): [number, number] | null {
  for (let r = 0; r < grid.length; r++) {
    for (let c = 0; c < grid[r].length; c++) {
      if (grid[r][c] === null) {
        return [r, c];
      }
    }
  }
  return null;
}

export const MagicGridStage: React.FC<StageProps> = ({
  level,
  useEastern,
  onSolve,
  onMistake,
}) => {
  const data = level.gridData as MagicGridData;
  const [grid, setGrid] = useState<(number | null)[][]>(() => data.initialGrid.map((r) => [...r]));
  const [selectedCell, setSelectedCell] = useState<[number, number] | null>(() =>
    findFirstEmptyCell(data.initialGrid)
  );
  const [shake, setShake] = useState(false);
  const [solved, setSolved] = useState(false);
  const [mistakes, setMistakes] = useState(0);

  useEffect(() => {
    const fresh = data.initialGrid.map((r) => [...r]);
    setGrid(fresh);
    setSelectedCell(findFirstEmptyCell(fresh));
    setShake(false);
    setSolved(false);
    setMistakes(0);
  }, [level]);

  const isCellEditable = (r: number, c: number) => data.initialGrid[r][c] === null;

  const handlePlaceNumber = (num: number) => {
    if (solved || !selectedCell) return;
    const [r, c] = selectedCell;
    if (!isCellEditable(r, c)) return;

    sound.playToggle(true);
    const nextGrid = grid.map((row) => [...row]);
    nextGrid[r][c] = num;
    setGrid(nextGrid);

    const nextEmpty = findFirstEmptyCell(nextGrid);
    if (nextEmpty) {
      setSelectedCell(nextEmpty);
    }
  };

  const getRowSum = (r: number) => grid[r].reduce<number>((acc, val) => acc + (val ?? 0), 0);
  const getColSum = (c: number) => (grid[0][c] ?? 0) + (grid[1][c] ?? 0) + (grid[2][c] ?? 0);
  const isAllFilled = grid.every((row) => row.every((cell) => cell !== null));

  const handleVerify = () => {
    if (!isAllFilled || solved) return;
    const rowsMatch = [0, 1, 2].every((r) => getRowSum(r) === data.targetRowSums[r]);
    const colsMatch = [0, 1, 2].every((c) => getColSum(c) === data.targetColSums[c]);

    if (rowsMatch && colsMatch) {
      setSolved(true);
      sound.playSuccess();
      const stars = mistakes === 0 ? 3 : mistakes === 1 ? 2 : 1;
      setTimeout(() => onSolve(stars), 650);
    } else {
      setMistakes((m) => m + 1);
      setShake(true);
      sound.playRetry();

      // Identify exact mismatched row or column for targeted pedagogical feedback
      const badRow = [0, 1, 2].find((r) => getRowSum(r) !== data.targetRowSums[r]);
      if (badRow !== undefined) {
        const curr = getRowSum(badRow);
        const targ = data.targetRowSums[badRow];
        onMistake(
          `في الصف ${formatNum(badRow + 1, useEastern)}، المجموع الحالي هو ${formatNum(
            curr,
            useEastern
          )} بينما الهدف المطلوب هو ${formatNum(targ, useEastern)}!`,
          {
            guessed: curr,
            expected: targ,
            operator: '+',
            context: 'magic_grid',
          }
        );
      } else {
        const badCol = [0, 1, 2].find((c) => getColSum(c) !== data.targetColSums[c]) ?? 0;
        const curr = getColSum(badCol);
        const targ = data.targetColSums[badCol];
        onMistake(
          `في العمود ${formatNum(badCol + 1, useEastern)}، المجموع الحالي هو ${formatNum(
            curr,
            useEastern
          )} بينما الهدف المطلوب هو ${formatNum(targ, useEastern)}!`,
          {
            guessed: curr,
            expected: targ,
            operator: '+',
            context: 'magic_grid',
          }
        );
      }
      setTimeout(() => setShake(false), 400);
    }
  };

  return (
    <div className={`space-y-6 ${shake ? 'animate-shake' : ''}`}>
      <div className="flex items-center justify-between bg-[#FAF6EE] px-4 py-2.5 rounded-xl border border-[#E5DEC9]">
        <span className="text-xs font-bold text-slate-700">
          انقر على الخانة الفارغة ثم اختر العدد المناسب
        </span>
        <button
          type="button"
          onClick={() => {
            sound.playClick();
            const fresh = data.initialGrid.map((r) => [...r]);
            setGrid(fresh);
            setSelectedCell(findFirstEmptyCell(fresh));
          }}
          className="text-xs font-bold text-slate-600 hover:text-slate-900 flex items-center gap-1"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>إعادة تعيين</span>
        </button>
      </div>

      <div className="flex flex-col items-center bg-[#F4EFE6] p-6 rounded-2xl border-2 border-[#E2D9C8]" dir="ltr">
        <div className="grid grid-cols-4 gap-2.5 sm:gap-3.5 items-center">
          {[0, 1, 2].map((r) => {
            const currentSum = getRowSum(r);
            const targetSum = data.targetRowSums[r];
            const rowFilled = grid[r].every((v) => v !== null);
            const rowCorrect = rowFilled && currentSum === targetSum;

            return (
              <React.Fragment key={`row-${r}`}>
                {[0, 1, 2].map((c) => {
                  const val = grid[r][c];
                  const editable = isCellEditable(r, c);
                  const isSelected = selectedCell?.[0] === r && selectedCell?.[1] === c;

                  return (
                    <button
                      key={`cell-${r}-${c}`}
                      type="button"
                      disabled={!editable}
                      onClick={() => {
                        sound.playClick();
                        setSelectedCell([r, c]);
                      }}
                      className={`w-16 h-16 sm:w-18 sm:h-18 rounded-2xl font-mono-num text-2xl font-bold flex flex-col items-center justify-center transition-all border-2 border-b-4 ${
                        !editable
                          ? 'bg-slate-200/90 text-slate-700 border-slate-300'
                          : isSelected
                          ? 'bg-amber-100 text-amber-950 border-amber-500 ring-2 ring-amber-400 scale-105'
                          : val !== null
                          ? 'bg-white text-indigo-900 border-indigo-300 hover:border-amber-400'
                          : 'bg-white/80 text-slate-400 border-dashed border-slate-400 hover:border-amber-400'
                      }`}
                    >
                      <span>{val !== null ? formatNum(val, useEastern) : '؟'}</span>
                      {editable && (
                        <span className="text-[10px] font-sans font-normal text-slate-400">
                          {isSelected ? 'محدد' : 'فارغ'}
                        </span>
                      )}
                    </button>
                  );
                })}

                <div
                  className={`px-3 py-2 rounded-xl font-mono-num text-sm font-bold flex flex-col items-center justify-center border ${
                    rowCorrect
                      ? 'bg-emerald-100 text-emerald-900 border-emerald-300'
                      : rowFilled
                      ? 'bg-rose-100 text-rose-900 border-rose-300'
                      : 'bg-white/70 text-slate-700 border-slate-300'
                  }`}
                >
                  <span className="text-[10px] font-sans">الصف</span>
                  <span>
                    {formatNum(currentSum, useEastern)} / {formatNum(targetSum, useEastern)}
                  </span>
                </div>
              </React.Fragment>
            );
          })}

          {[0, 1, 2].map((c) => {
            const currentColSum = getColSum(c);
            const targetColSum = data.targetColSums[c];
            const colFilled = [0, 1, 2].every((r) => grid[r][c] !== null);
            const colCorrect = colFilled && currentColSum === targetColSum;

            return (
              <div
                key={`col-${c}`}
                className={`px-2 py-2 rounded-xl font-mono-num text-sm font-bold flex flex-col items-center justify-center border ${
                  colCorrect
                    ? 'bg-emerald-100 text-emerald-900 border-emerald-300'
                    : colFilled
                    ? 'bg-rose-100 text-rose-900 border-rose-300'
                    : 'bg-white/70 text-slate-700 border-slate-300'
                }`}
              >
                <span className="text-[10px] font-sans">العمود</span>
                <span>
                  {formatNum(currentColSum, useEastern)} / {formatNum(targetColSum, useEastern)}
                </span>
              </div>
            );
          })}
          <div className="text-xs font-bold text-slate-500 font-sans text-center">الأهداف</div>
        </div>
      </div>

      <div className="space-y-2.5">
        <p className="text-xs font-bold text-slate-600 text-center">
          الأعداد المقترحة لإكمال الشبكة ({data.availableTiles.map((t) => formatNum(t, useEastern)).join(' ، ')}):
        </p>
        <div className="flex items-center justify-center gap-2 flex-wrap" dir="ltr">
          {Array.from(new Set([...data.availableTiles, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 12]))
            .sort((a, b) => a - b)
            .map((num) => {
              const isRecommended = data.availableTiles.includes(num);
              return (
                <button
                  key={num}
                  type="button"
                  onClick={() => handlePlaceNumber(num)}
                  className={`tactile-button w-12 h-12 sm:w-14 sm:h-14 rounded-xl font-mono-num text-xl font-bold flex items-center justify-center border-2 border-b-4 transition-colors ${
                    isRecommended
                      ? 'bg-amber-50 text-amber-950 border-amber-500 hover:bg-amber-100'
                      : 'bg-white text-slate-800 border-slate-300 hover:bg-slate-50'
                  }`}
                >
                  {formatNum(num, useEastern)}
                </button>
              );
            })}
        </div>
      </div>

      <div className="flex justify-center pt-1">
        <button
          type="button"
          onClick={handleVerify}
          disabled={!isAllFilled || solved}
          className="tactile-button px-8 py-3.5 rounded-xl font-display font-bold text-base text-white bg-emerald-600 hover:bg-emerald-500 border-b-4 border-emerald-800 disabled:opacity-40 flex items-center gap-2 whitespace-nowrap"
        >
          <Check className="w-5 h-5" />
          <span>تحقق من الشبكة السحرية</span>
        </button>
      </div>
    </div>
  );
};

// ============================================================================
// 4. CODE BREAKER (SYMBOL LOGIC) STAGE
// ============================================================================
export const CodeBreakerStage: React.FC<StageProps> = ({
  level,
  useEastern,
  hintLevel,
  onSolve,
  onMistake,
}) => {
  const data = level.codeData as CodeBreakerData;
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [shake, setShake] = useState(false);
  const [solved, setSolved] = useState(false);
  const [mistakes, setMistakes] = useState(0);

  useEffect(() => {
    setSelectedAnswer(null);
    setShake(false);
    setSolved(false);
    setMistakes(0);
  }, [level]);

  const handleVerify = () => {
    if (selectedAnswer === null || solved) return;
    if (selectedAnswer === data.correctAnswer) {
      setSolved(true);
      sound.playSuccess();
      const stars = mistakes === 0 ? 3 : mistakes === 1 ? 2 : 1;
      setTimeout(() => onSolve(stars), 650);
    } else {
      setMistakes((m) => m + 1);
      setShake(true);
      sound.playRetry();

      // Check if student fell into the Order of Operations trap: (s1 + s2) * s3 instead of s1 + (s2 * s3)
      const { s1, op1, s2, op2, s3 } = data.finalQuestion;
      const v1 = data.symbolValues[s1];
      const v2 = data.symbolValues[s2];
      const v3 = s3 ? data.symbolValues[s3] : 0;
      const isOrderOfOpsTrap =
        op1 === '+' && op2 === '×' && s3 && selectedAnswer === (v1 + v2) * v3;

      onMistake(
        isOrderOfOpsTrap
          ? `انتبه يا بطل! لقد جمعت قبل الضرب. في الرياضيات نحسب الضرب (×) أولاً ثم نجمع!`
          : `الشفرة ${formatNum(selectedAnswer, useEastern)} غير صحيحة! تتبع قيمة كل رمز من الدلائل الثلاثة.`,
        {
          guessed: selectedAnswer,
          expected: data.correctAnswer,
          operator: op2 || op1,
          context: isOrderOfOpsTrap ? 'order_of_operations' : 'code_breaker',
        }
      );
      setTimeout(() => setShake(false), 400);
    }
  };

  return (
    <div className={`space-y-6 ${shake ? 'animate-shake' : ''}`}>
      <div className="bg-[#FAF6EE] p-5 rounded-2xl border-2 border-[#E2D9C8] space-y-3">
        <div className="flex items-center justify-between mb-1">
          <span className="text-xs font-bold text-slate-700">الدلائل المنطقية لفك الشفرة:</span>
          <span className="text-xs font-bold text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded border border-indigo-200">
            {DIFFICULTY_CONFIGS[level.difficulty].label}
          </span>
        </div>

        <div className="grid grid-cols-1 gap-2.5">
          {data.clues.map((clue, idx) => (
            <div
              key={idx}
              className="flex items-center justify-between bg-white px-4 py-3 rounded-xl border border-[#E5DEC9]"
              dir="ltr"
            >
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-1.5">
                  <PuzzleSymbolIcon type={clue.symbols[0]} size={32} />
                  <span className="text-xs text-slate-500 font-sans">
                    ({SYMBOL_NAMES_AR[clue.symbols[0]]})
                  </span>
                </div>

                <span className="font-mono-num text-xl font-bold text-amber-600">
                  {clue.operator}
                </span>

                <div className="flex items-center gap-1.5">
                  <PuzzleSymbolIcon type={clue.symbols[1]} size={32} />
                  <span className="text-xs text-slate-500 font-sans">
                    ({SYMBOL_NAMES_AR[clue.symbols[1]]})
                  </span>
                </div>

                <span className="font-mono-num text-xl font-bold text-slate-400">=</span>

                <span className="font-mono-num text-2xl font-bold text-slate-900 bg-amber-50 px-3 py-1 rounded-lg border border-amber-200">
                  {formatNum(clue.result, useEastern)}
                </span>
              </div>

              {(hintLevel > idx || solved) && (
                <span className="text-xs font-bold text-emerald-700 font-sans" dir="rtl">
                  ✓ {formatNum(clue.explanation, useEastern)}
                </span>
              )}
            </div>
          ))}
        </div>
      </div>

      <div className="bg-indigo-950 text-white p-5 rounded-2xl border-b-4 border-indigo-900 flex flex-col items-center gap-3">
        <span className="text-xs text-indigo-200 font-medium">
          الشفرة النهائية لقفل الخزينة
          {data.finalQuestion.op2 === '×' ? ' (تذكر: الضرب × يسبق الجمع +)' : ':'}
        </span>
        <div className="flex items-center justify-center gap-3 flex-wrap" dir="ltr">
          <PuzzleSymbolIcon type={data.finalQuestion.s1} size={40} />
          <span className="font-mono-num text-2xl font-bold text-amber-400">
            {data.finalQuestion.op1}
          </span>
          <PuzzleSymbolIcon type={data.finalQuestion.s2} size={40} />
          {data.finalQuestion.op2 && data.finalQuestion.s3 && (
            <>
              <span className="font-mono-num text-2xl font-bold text-amber-400">
                {data.finalQuestion.op2}
              </span>
              <PuzzleSymbolIcon type={data.finalQuestion.s3} size={40} />
            </>
          )}
          <span className="font-mono-num text-2xl font-bold text-indigo-300">=</span>
          <div className="w-16 h-14 rounded-xl bg-white/10 border-2 border-amber-400 flex items-center justify-center font-mono-num text-2xl font-bold text-amber-300">
            {selectedAnswer !== null ? formatNum(selectedAnswer, useEastern) : '؟'}
          </div>
        </div>
      </div>

      <div className="flex items-center justify-center gap-3 flex-wrap" dir="ltr">
        {data.options.map((opt) => {
          const isSelected = selectedAnswer === opt;
          return (
            <button
              key={opt}
              type="button"
              onClick={() => {
                sound.playClick();
                setSelectedAnswer(opt);
              }}
              className={`tactile-button w-16 h-16 rounded-2xl font-mono-num text-2xl font-bold flex items-center justify-center border-2 border-b-4 transition-all ${
                isSelected
                  ? 'bg-amber-500 text-white border-amber-700 scale-105'
                  : 'bg-white text-slate-800 border-[#D6CFC2] hover:border-indigo-400'
              }`}
            >
              {formatNum(opt, useEastern)}
            </button>
          );
        })}
      </div>

      <div className="flex justify-center pt-1">
        <button
          type="button"
          onClick={handleVerify}
          disabled={selectedAnswer === null || solved}
          className="tactile-button px-8 py-3.5 rounded-xl font-display font-bold text-base text-white bg-emerald-600 hover:bg-emerald-500 border-b-4 border-emerald-800 disabled:opacity-40 flex items-center gap-2 whitespace-nowrap"
        >
          <Sparkles className="w-5 h-5" />
          <span>افتح قفل الخزينة</span>
        </button>
      </div>
    </div>
  );
};

// ============================================================================
// 5. SPEED MATH BLITZ STAGE (Fast-Paced Arithmetic Drill by Difficulty)
// ============================================================================
export const SpeedMathStage: React.FC<{
  difficulty: DifficultyTier;
  useEastern: boolean;
  onComplete: (score: number, total: number) => void;
}> = ({ difficulty, useEastern, onComplete }) => {
  const [problems, setProblems] = useState<SpeedMathProblem[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [timeLeft, setTimeLeft] = useState(45);
  const [gameOver, setGameOver] = useState(false);

  const scoreRef = useRef(score);
  scoreRef.current = score;
  const problemsLenRef = useRef(problems.length);
  problemsLenRef.current = problems.length;
  const onCompleteRef = useRef(onComplete);
  onCompleteRef.current = onComplete;

  useEffect(() => {
    const list = generateSpeedProblems(difficulty, 10);
    setProblems(list);
    setCurrentIndex(0);
    setScore(0);
    setTimeLeft(difficulty === 'easy' ? 45 : difficulty === 'medium' ? 40 : 35);
    setGameOver(false);
  }, [difficulty]);

  // Stable 1-second countdown interval without recreating every second
  useEffect(() => {
    if (gameOver) return;
    const timer = setInterval(() => {
      setTimeLeft((prev) => (prev > 0 ? prev - 1 : 0));
    }, 1000);
    return () => clearInterval(timer);
  }, [gameOver]);

  // Trigger completion cleanly when timer reaches 0
  useEffect(() => {
    if (timeLeft === 0 && !gameOver && problemsLenRef.current > 0) {
      setGameOver(true);
      onCompleteRef.current(scoreRef.current, problemsLenRef.current);
    }
  }, [timeLeft, gameOver]);

  const handleAnswer = (val: number) => {
    if (gameOver || !problems[currentIndex]) return;
    const isCorrect = val === problems[currentIndex].answer;
    const nextScore = isCorrect ? score + 1 : score;

    if (isCorrect) {
      sound.playSuccess();
      setScore(nextScore);
    } else {
      sound.playRetry();
    }

    if (currentIndex + 1 < problems.length) {
      setCurrentIndex(currentIndex + 1);
    } else {
      setGameOver(true);
      onComplete(nextScore, problems.length);
    }
  };

  const currentProb = problems[currentIndex];

  if (!currentProb) return null;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between bg-amber-50 p-4 rounded-2xl border border-amber-200">
        <div className="flex items-center gap-2">
          <Zap className="w-5 h-5 text-amber-600 fill-amber-500" />
          <span className="font-bold text-sm text-amber-900">
            سباق الحساب السريع ({DIFFICULTY_CONFIGS[difficulty].label})
          </span>
        </div>
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1.5 text-slate-700 font-mono-num text-sm font-bold">
            <Timer className="w-4 h-4 text-rose-600" />
            <span>{formatNum(timeLeft, useEastern)} ثانية</span>
          </div>
          <div className="text-sm font-bold text-emerald-800 bg-emerald-100 px-3 py-1 rounded-lg">
            النقاط: {formatNum(score, useEastern)} / {formatNum(problems.length, useEastern)}
          </div>
        </div>
      </div>

      {/* Problem Display */}
      <div className="bg-white p-8 rounded-3xl border-2 border-[#E2D9C8] flex flex-col items-center justify-center gap-6">
        <span className="text-xs text-slate-500 font-bold">
          السؤال {formatNum(currentIndex + 1, useEastern)} من {formatNum(problems.length, useEastern)} (بدون تكرار)
        </span>
        <div className="flex items-center justify-center gap-4 font-mono-num text-4xl sm:text-5xl font-bold text-slate-900" dir="ltr">
          <span>{formatNum(currentProb.num1, useEastern)}</span>
          <span className="text-amber-600">{currentProb.operator}</span>
          <span>{formatNum(currentProb.num2, useEastern)}</span>
          <span className="text-slate-400">=</span>
          <span className="text-sky-600 font-bold">؟</span>
        </div>

        <div className="grid grid-cols-2 gap-4 w-full max-w-md pt-4" dir="ltr">
          {currentProb.options.map((opt, i) => (
            <button
              key={i}
              type="button"
              onClick={() => handleAnswer(opt)}
              className="tactile-button py-4 rounded-2xl font-mono-num text-2xl font-bold bg-[#FAF6EE] hover:bg-amber-100 text-slate-900 border-2 border-b-4 border-amber-300"
            >
              {formatNum(opt, useEastern)}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};
