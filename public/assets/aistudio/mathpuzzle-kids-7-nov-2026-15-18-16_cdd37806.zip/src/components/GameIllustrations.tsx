import React, { useState } from 'react';
import { sound, formatNum } from '../utils/sound';
import { RotateCcw, Plus, Minus } from 'lucide-react';

export type SymbolType = 'apple' | 'star' | 'gem' | 'crown' | 'moon' | 'crystal';

export const SYMBOL_NAMES_AR: Record<SymbolType, string> = {
  apple: 'التفاحة',
  star: 'النجمة',
  gem: 'الجوهرة',
  crown: 'التاج',
  moon: 'الهلال',
  crystal: 'البلورة',
};

export const PuzzleSymbolIcon: React.FC<{
  type: SymbolType;
  size?: number;
  className?: string;
}> = ({ type, size = 36, className = '' }) => {
  switch (type) {
    case 'apple':
      return (
        <svg width={size} height={size} viewBox="0 0 48 48" className={className} aria-label="تفاحة">
          <path d="M24 11 C24 6, 29 4, 31 4" stroke="#78350F" strokeWidth="3" strokeLinecap="round" fill="none" />
          <path d="M25 9 C29 5, 36 7, 34 12 C31 14, 26 12, 25 9 Z" fill="#10B981" />
          <path
            d="M24 13 C16 11, 8 17, 9 27 C10 36, 17 43, 22 43 C23.5 43, 24.5 42, 24 42 C23.5 42, 24.5 43, 26 43 C31 43, 38 36, 39 27 C40 17, 32 11, 24 13 Z"
            fill="#F43F5E"
            stroke="#BE123C"
            strokeWidth="2"
          />
          <path d="M15 20 C13 24, 13 29, 15 32" stroke="#FDA4AF" strokeWidth="2.5" strokeLinecap="round" fill="none" />
        </svg>
      );
    case 'star':
      return (
        <svg width={size} height={size} viewBox="0 0 48 48" className={className} aria-label="نجمة">
          <polygon
            points="24,4 30,16 43,18 33.5,27.5 36,41 24,34.5 12,41 14.5,27.5 5,18 18,16"
            fill="#F59E0B"
            stroke="#B45309"
            strokeWidth="2.2"
            strokeLinejoin="round"
          />
          <circle cx="20" cy="22" r="2" fill="#78350F" />
          <circle cx="28" cy="22" r="2" fill="#78350F" />
          <path d="M21 26 Q24 29 27 26" stroke="#78350F" strokeWidth="2" strokeLinecap="round" fill="none" />
        </svg>
      );
    case 'gem':
      return (
        <svg width={size} height={size} viewBox="0 0 48 48" className={className} aria-label="جوهرة">
          <polygon
            points="14,8 34,8 43,19 24,42 5,19"
            fill="#0EA5E9"
            stroke="#0369A1"
            strokeWidth="2.2"
            strokeLinejoin="round"
          />
          <polyline points="5,19 43,19" stroke="#BAE6FD" strokeWidth="2" />
          <polyline points="14,8 19,19 24,42 29,19 34,8" stroke="#7DD3FC" strokeWidth="1.8" fill="none" />
        </svg>
      );
    case 'crown':
      return (
        <svg width={size} height={size} viewBox="0 0 48 48" className={className} aria-label="تاج">
          <path
            d="M6 36 L10 14 L19 24 L24 11 L29 24 L38 14 L42 36 Z"
            fill="#FBBF24"
            stroke="#B45309"
            strokeWidth="2.2"
            strokeLinejoin="round"
          />
          <rect x="6" y="36" width="36" height="5" rx="2" fill="#D97706" />
          <circle cx="24" cy="28" r="3" fill="#EF4444" />
          <circle cx="14" cy="30" r="2.2" fill="#0EA5E9" />
          <circle cx="34" cy="30" r="2.2" fill="#10B981" />
        </svg>
      );
    case 'moon':
      return (
        <svg width={size} height={size} viewBox="0 0 48 48" className={className} aria-label="هلال">
          <path
            d="M31 8 C20 10, 12 20, 14 31 C16 40, 25 44, 34 40 C25 40, 20 33, 21 24 C22 16, 26 11, 31 8 Z"
            fill="#6366F1"
            stroke="#4338CA"
            strokeWidth="2.2"
            strokeLinejoin="round"
          />
        </svg>
      );
    default:
      return (
        <svg width={size} height={size} viewBox="0 0 48 48" className={className} aria-label="بلورة">
          <polygon
            points="24,4 38,16 38,32 24,44 10,32 10,16"
            fill="#10B981"
            stroke="#047857"
            strokeWidth="2.2"
          />
          <polygon points="24,9 33,18 24,39 15,18" fill="#6EE7B7" opacity="0.5" />
        </svg>
      );
  }
};

export type OwlMood = 'idle' | 'happy' | 'thinking' | 'encouraging' | 'celebrating' | 'super_excited' | 'proud';

export const OwlMascot: React.FC<{
  mood: OwlMood;
  size?: number;
}> = ({ mood, size = 72 }) => {
  const isExcited = mood === 'celebrating' || mood === 'super_excited';
  const isProud = mood === 'proud';

  return (
    <div className={`relative inline-flex items-center justify-center shrink-0 ${isExcited ? 'animate-celebrate' : ''}`}>
      {/* Joy sparkles when excited */}
      {isExcited && (
        <>
          <span className="absolute -top-2.5 -right-2 text-amber-400 text-sm animate-star-twinkle select-none pointer-events-none">✨</span>
          <span className="absolute -top-3 -left-1 text-amber-500 text-xs animate-star-twinkle select-none pointer-events-none">🌟</span>
          <span className="absolute top-1/2 -right-3 text-emerald-500 text-xs animate-bounce select-none pointer-events-none">🎉</span>
          <span className="absolute top-1/2 -left-3 text-purple-500 text-xs animate-bounce select-none pointer-events-none">🎈</span>
        </>
      )}

      <svg width={size} height={size} viewBox="0 0 96 96" className="shrink-0 select-none overflow-visible" aria-hidden="true">
        {/* Left Wing */}
        <g className={isExcited ? 'animate-wing-left' : ''}>
          <path
            d="M24 45 C12 48, 6 62, 16 74 C22 80, 28 72, 28 64 Z"
            fill="#B45309"
            stroke="#78350F"
            strokeWidth="2.5"
            strokeLinejoin="round"
          />
        </g>

        {/* Right Wing */}
        <g className={isExcited ? 'animate-wing-right' : ''}>
          <path
            d="M72 45 C84 48, 90 62, 80 74 C74 80, 68 72, 68 64 Z"
            fill="#B45309"
            stroke="#78350F"
            strokeWidth="2.5"
            strokeLinejoin="round"
          />
        </g>

        {/* Body */}
        <ellipse cx="48" cy="56" rx="28" ry="30" fill="#D97706" stroke="#78350F" strokeWidth="3" />
        {/* Belly patch */}
        <ellipse cx="48" cy="62" rx="19" ry="21" fill="#FEF3C7" />
        {/* Chest feather scallops */}
        <path d="M39 54 Q43 58 47 54 M49 54 Q53 58 57 54 M43 63 Q48 67 53 63" stroke="#D97706" strokeWidth="2.2" strokeLinecap="round" fill="none" />

        {/* Rosy blush cheeks on happy / excited / proud */}
        {(mood === 'happy' || isExcited || isProud) && (
          <>
            <circle cx="27" cy="51" r="4.5" fill="#FDA4AF" opacity="0.85" />
            <circle cx="69" cy="51" r="4.5" fill="#FDA4AF" opacity="0.85" />
          </>
        )}

        {/* Ears / tufts */}
        <path d="M24 34 L18 20 L34 28 Z" fill="#B45309" stroke="#78350F" strokeWidth="2.5" strokeLinejoin="round" />
        <path d="M72 34 L78 20 L62 28 Z" fill="#B45309" stroke="#78350F" strokeWidth="2.5" strokeLinejoin="round" />
        {/* Eyes background */}
        <circle cx="37" cy="40" r="11" fill="#FFFFFF" stroke="#78350F" strokeWidth="2.5" />
        <circle cx="59" cy="40" r="11" fill="#FFFFFF" stroke="#78350F" strokeWidth="2.5" />
        {/* Glasses bridge */}
        <line x1="48" y1="40" x2="48" y2="40" stroke="#1E293B" strokeWidth="3" />

        {/* Pupils based on mood */}
        {isExcited ? (
          <>
            <polygon
              points="37,34 38.5,38 42,38.5 39,41 40,45 37,42.5 34,45 35,41 32,38.5 35.5,38"
              fill="#F59E0B"
              stroke="#B45309"
              strokeWidth="1.2"
            />
            <polygon
              points="59,34 60.5,38 64,38.5 61,41 62,45 59,42.5 56,45 57,41 54,38.5 57.5,38"
              fill="#F59E0B"
              stroke="#B45309"
              strokeWidth="1.2"
            />
            <circle cx="37" cy="40" r="1.5" fill="#FFFFFF" />
            <circle cx="59" cy="40" r="1.5" fill="#FFFFFF" />
          </>
        ) : mood === 'happy' || isProud ? (
          <>
            <path d="M31 40 Q37 32 43 40" stroke="#1E293B" strokeWidth="3.2" strokeLinecap="round" fill="none" />
            <path d="M53 40 Q59 32 65 40" stroke="#1E293B" strokeWidth="3.2" strokeLinecap="round" fill="none" />
          </>
        ) : mood === 'thinking' ? (
          <>
            <circle cx="39" cy="37" r="4.5" fill="#1E293B" />
            <circle cx="61" cy="37" r="4.5" fill="#1E293B" />
            <circle cx="40.5" cy="35.5" r="1.5" fill="#FFFFFF" />
            <circle cx="62.5" cy="35.5" r="1.5" fill="#FFFFFF" />
          </>
        ) : mood === 'encouraging' ? (
          <>
            <circle cx="37" cy="41" r="4.2" fill="#1E293B" />
            <circle cx="59" cy="41" r="4.2" fill="#1E293B" />
            <circle cx="39" cy="39" r="1.8" fill="#FFFFFF" />
            <circle cx="61" cy="39" r="1.8" fill="#FFFFFF" />
            <path d="M31 34 Q37 36 41 34" stroke="#78350F" strokeWidth="1.8" fill="none" />
            <path d="M55 34 Q59 36 65 34" stroke="#78350F" strokeWidth="1.8" fill="none" />
          </>
        ) : (
          <>
            <circle cx="37" cy="40" r="4.5" fill="#1E293B" />
            <circle cx="59" cy="40" r="4.5" fill="#1E293B" />
            <circle cx="38.5" cy="38.5" r="1.5" fill="#FFFFFF" />
            <circle cx="60.5" cy="38.5" r="1.5" fill="#FFFFFF" />
          </>
        )}

        {/* Beak */}
        {isExcited ? (
          <>
            <polygon points="43,44 53,44 48,54" fill="#F59E0B" stroke="#78350F" strokeWidth="2" strokeLinejoin="round" />
            <ellipse cx="48" cy="48" rx="3.5" ry="3" fill="#BE123C" />
          </>
        ) : (
          <polygon points="44,45 52,45 48,52" fill="#F59E0B" stroke="#78350F" strokeWidth="2" strokeLinejoin="round" />
        )}

        {/* Scholar Hat or Golden Crown */}
        {isProud ? (
          <g>
            <path d="M34 22 L40 10 L48 18 L56 10 L62 22 Z" fill="#FBBF24" stroke="#B45309" strokeWidth="2" strokeLinejoin="round" />
            <circle cx="48" cy="18" r="2" fill="#EF4444" />
          </g>
        ) : (
          <>
            <polygon points="48,10 24,20 48,28 72,20" fill="#1E293B" stroke="#0F172A" strokeWidth="2" strokeLinejoin="round" />
            <path d="M66 22 L68 33" stroke="#F59E0B" strokeWidth="2.5" strokeLinecap="round" />
            <circle cx="68" cy="34" r="2.5" fill="#F59E0B" />
          </>
        )}

        {/* Feet */}
        <path d="M36 86 L32 91 M36 86 L36 92 M36 86 L40 91" stroke="#D97706" strokeWidth="2.8" strokeLinecap="round" />
        <path d="M60 86 L56 91 M60 86 L60 92 M60 86 L64 91" stroke="#D97706" strokeWidth="2.8" strokeLinecap="round" />
      </svg>
    </div>
  );
};

// Interactive Counting Frame
export const InteractiveAbacus: React.FC<{
  useEastern: boolean;
}> = ({ useEastern }) => {
  const [count, setCount] = useState<number>(0);

  const handleSetCount = (newVal: number) => {
    const clamped = Math.max(0, Math.min(20, newVal));
    if (clamped !== count) {
      sound.playToggle(clamped > count);
      setCount(clamped);
    }
  };

  return (
    <div className="tactile-card rounded-2xl p-4 bg-[#FAF6EE]">
      <div className="flex items-center justify-between mb-3">
        <div>
          <h3 className="text-sm font-bold text-slate-800 font-display">المعداد البصري المساعد</h3>
          <p className="text-xs text-slate-500">انقر على الكرات للعد والجمع باليد</p>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-500">المجموع:</span>
          <span className="font-mono-num text-lg font-bold text-amber-700 bg-amber-100/80 px-2.5 py-0.5 rounded-lg border border-amber-300">
            {formatNum(count, useEastern)}
          </span>
          <button
            type="button"
            onClick={() => handleSetCount(0)}
            className="p-1.5 text-slate-500 hover:text-slate-800 hover:bg-slate-200/60 rounded-lg transition-colors"
            title="تصفير المعداد"
            aria-label="تصفير المعداد"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </div>

      <div className="space-y-2.5 bg-white p-3 rounded-xl border border-[#E5DEC9]" dir="ltr">
        <div className="flex items-center justify-between gap-1">
          {Array.from({ length: 10 }, (_, idx) => {
            const beadNum = idx + 1;
            const isActive = beadNum <= count;
            const isFirstFive = idx < 5;
            return (
              <button
                key={beadNum}
                type="button"
                onClick={() => handleSetCount(beadNum === count ? beadNum - 1 : beadNum)}
                className={`w-7 h-7 sm:w-8 sm:h-8 rounded-full font-mono-num text-xs font-bold transition-transform duration-150 flex items-center justify-center border-b-2 ${
                  isActive
                    ? isFirstFive
                      ? 'bg-amber-500 text-white border-amber-700 scale-105 shadow-xs'
                      : 'bg-emerald-500 text-white border-emerald-700 scale-105 shadow-xs'
                    : 'bg-slate-100 text-slate-400 border-slate-300 hover:bg-slate-200'
                }`}
                aria-label={`كرة رقم ${beadNum}`}
              >
                {formatNum(beadNum, useEastern)}
              </button>
            );
          })}
        </div>

        <div className="flex items-center justify-between gap-1">
          {Array.from({ length: 10 }, (_, idx) => {
            const beadNum = idx + 11;
            const isActive = beadNum <= count;
            const isFirstFive = idx < 5;
            return (
              <button
                key={beadNum}
                type="button"
                onClick={() => handleSetCount(beadNum === count ? beadNum - 1 : beadNum)}
                className={`w-7 h-7 sm:w-8 sm:h-8 rounded-full font-mono-num text-xs font-bold transition-transform duration-150 flex items-center justify-center border-b-2 ${
                  isActive
                    ? isFirstFive
                      ? 'bg-sky-500 text-white border-sky-700 scale-105 shadow-xs'
                      : 'bg-indigo-500 text-white border-indigo-700 scale-105 shadow-xs'
                    : 'bg-slate-100 text-slate-400 border-slate-300 hover:bg-slate-200'
                }`}
                aria-label={`كرة رقم ${beadNum}`}
              >
                {formatNum(beadNum, useEastern)}
              </button>
            );
          })}
        </div>
      </div>

      <div className="flex items-center justify-between gap-2 mt-3">
        <div className="flex items-center gap-1.5">
          <button
            type="button"
            onClick={() => handleSetCount(count + 1)}
            disabled={count >= 20}
            className="px-2.5 py-1 text-xs font-bold bg-emerald-50 text-emerald-800 border border-emerald-200 rounded-lg hover:bg-emerald-100 disabled:opacity-40 flex items-center gap-1 whitespace-nowrap"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>{formatNum(1, useEastern)}</span>
          </button>
          <button
            type="button"
            onClick={() => handleSetCount(count + 5)}
            disabled={count > 15}
            className="px-2.5 py-1 text-xs font-bold bg-emerald-50 text-emerald-800 border border-emerald-200 rounded-lg hover:bg-emerald-100 disabled:opacity-40 flex items-center gap-1 whitespace-nowrap"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>{formatNum(5, useEastern)}</span>
          </button>
          <button
            type="button"
            onClick={() => handleSetCount(count - 1)}
            disabled={count <= 0}
            className="px-2.5 py-1 text-xs font-bold bg-rose-50 text-rose-800 border border-rose-200 rounded-lg hover:bg-rose-100 disabled:opacity-40 flex items-center gap-1 whitespace-nowrap"
          >
            <Minus className="w-3.5 h-3.5" />
            <span>{formatNum(1, useEastern)}</span>
          </button>
        </div>
        <span className="text-xs text-slate-500">
          العشرات: {formatNum(Math.floor(count / 10), useEastern)} · الآحاد: {formatNum(count % 10, useEastern)}
        </span>
      </div>
    </div>
  );
};
