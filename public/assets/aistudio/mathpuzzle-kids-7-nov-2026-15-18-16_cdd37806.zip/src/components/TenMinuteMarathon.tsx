import React, { useState, useEffect, useRef, useCallback } from 'react';
import { useGameAudio, formatNum } from '../utils/sound';
import {
  ProblemDeduplicator,
  randInt,
  generateSmartOptions,
  getOperationSignature,
  BasicOperator,
} from '../utils/mathEngine';
import { coachService } from '../utils/pedagogicalCoach';
import { OwlMascot, OwlMood } from './GameIllustrations';
import {
  Timer,
  Trophy,
  Flame,
  Zap,
  Sparkles,
  RotateCcw,
  Play,
  Pause,
  ArrowRight,
  Check,
  X,
  Award,
  Coins,
  Medal,
  Star,
  Sliders,
} from 'lucide-react';
import { DifficultyTier, DIFFICULTY_CONFIGS } from '../data/puzzles';

export interface LeaderboardEntry {
  id: string;
  playerName: string;
  score: number;
  solvedCount: number;
  totalAttempted: number;
  accuracy: number;
  durationMinutes: number;
  date: string;
  title: string;
}

const LEADERBOARD_KEY = 'mathpuzzle_marathon_leaderboard_v1';

export const INITIAL_LEADERBOARD: LeaderboardEntry[] = [
  {
    id: 'lb-1',
    playerName: 'سارة العبقرية',
    score: 1850,
    solvedCount: 24,
    totalAttempted: 25,
    accuracy: 96,
    durationMinutes: 10,
    date: '2026-09-28',
    title: 'أسطورة الحساب الذهني 👑',
  },
  {
    id: 'lb-2',
    playerName: 'فارس الأرقام',
    score: 1420,
    solvedCount: 19,
    totalAttempted: 21,
    accuracy: 90,
    durationMinutes: 10,
    date: '2026-09-27',
    title: 'برق الرياضيات السريع ⚡',
  },
  {
    id: 'lb-3',
    playerName: 'يوسف الذكي',
    score: 1180,
    solvedCount: 16,
    totalAttempted: 18,
    accuracy: 88,
    durationMinutes: 10,
    date: '2026-09-26',
    title: 'مكتشف الألغاز البطل 🌟',
  },
  {
    id: 'lb-4',
    playerName: 'نور الهدى',
    score: 950,
    solvedCount: 13,
    totalAttempted: 15,
    accuracy: 86,
    durationMinutes: 10,
    date: '2026-09-25',
    title: 'المفكرة الطموحة 💡',
  },
];

interface MarathonQuestion {
  id: number;
  prompt: string;
  subTitle: string;
  num1: number;
  num2: number;
  op: BasicOperator;
  correctAnswer: number;
  options: number[];
  category: 'sequence' | 'balance' | 'equation' | 'quick_mult';
}

interface TenMinuteMarathonProps {
  useEastern: boolean;
  defaultPlayerName: string;
  globalDifficulty: DifficultyTier;
  onExit: () => void;
  onAwardCoins: (coins: number) => void;
}

export const TenMinuteMarathon: React.FC<TenMinuteMarathonProps> = ({
  useEastern,
  defaultPlayerName,
  globalDifficulty,
  onExit,
  onAwardCoins,
}) => {
  const { playClick, playCorrectPop, playRetry, playStreakCombo, playSuccess, playLevelUnlocked } =
    useGameAudio();

  const deduplicatorRef = useRef(new ProblemDeduplicator(90));

  // Marathon configuration
  const [selectedDuration, setSelectedDuration] = useState<number>(600); // 10 minutes = 600s
  const [isActive, setIsActive] = useState<boolean>(false);
  const [isPaused, setIsPaused] = useState<boolean>(false);
  const [timeLeft, setTimeLeft] = useState<number>(600);
  const [isFinished, setIsFinished] = useState<boolean>(false);

  // Scoring and Stats
  const [score, setScore] = useState<number>(0);
  const scoreRef = useRef<number>(0);
  scoreRef.current = score;

  const [streak, setStreak] = useState<number>(0);
  const [bestStreak, setBestStreak] = useState<number>(0);
  const [solvedCount, setSolvedCount] = useState<number>(0);
  const [totalAttempts, setTotalAttempts] = useState<number>(0);
  const [questionIndex, setQuestionIndex] = useState<number>(0);

  // Question State
  const [currentQuestion, setCurrentQuestion] = useState<MarathonQuestion | null>(null);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [feedback, setFeedback] = useState<'correct' | 'wrong' | null>(null);
  const [coachMood, setCoachMood] = useState<OwlMood>('idle');
  const [coachTip, setCoachTip] = useState<string>('استعد لتحدي العشر دقائق! أجب بأسرع وقت لجمع أكبر عدد من النقاط.');

  // Leaderboard State
  const [leaderboard, setLeaderboard] = useState<LeaderboardEntry[]>(() => {
    try {
      const saved = localStorage.getItem(LEADERBOARD_KEY);
      if (saved) return JSON.parse(saved);
    } catch {}
    return INITIAL_LEADERBOARD;
  });
  const [playerNameInput, setPlayerNameInput] = useState<string>(defaultPlayerName);
  const [hasSavedRecord, setHasSavedRecord] = useState<boolean>(false);
  const [showLeaderboardTab, setShowLeaderboardTab] = useState<boolean>(false);

  // Generate varied, non-repeating puzzle problem
  const generateProblem = useCallback(
    (diff: DifficultyTier, qIdx: number): MarathonQuestion => {
      const types: ('sequence' | 'balance' | 'equation' | 'quick_mult')[] = [
        'equation',
        'sequence',
        'balance',
        'quick_mult',
      ];
      const type = types[qIdx % types.length];

      let prompt = '';
      let subTitle = '';
      let num1 = 0;
      let num2 = 0;
      let op: BasicOperator = '+';
      let correctAnswer = 0;
      let sig = '';

      for (let attempt = 0; attempt < 30; attempt++) {
        if (type === 'sequence') {
          const step = diff === 'easy' ? randInt(1, 5) : diff === 'medium' ? randInt(3, 9) : randInt(5, 16);
          const start = randInt(2, 24);
          const seq = [start, start + step, start + step * 2, start + step * 3];
          correctAnswer = seq[3];
          num1 = seq[2];
          num2 = step;
          op = '+';
          prompt = `${seq[0]} ، ${seq[1]} ، ${seq[2]} ، [ ؟ ]`;
          subTitle = `اكتشف العدد التالي في المتتالية (مقدار الزيادة +${formatNum(step, useEastern)})`;
          sig = `MAR_SEQ:${start}:${step}`;
        } else if (type === 'balance') {
          const leftTotal = diff === 'easy' ? randInt(10, 22) : diff === 'medium' ? randInt(22, 55) : randInt(40, 95);
          const part = randInt(3, leftTotal - 2);
          correctAnswer = leftTotal - part;
          num1 = leftTotal;
          num2 = part;
          op = '-';
          prompt = `كفة الميزان: [ ؟ ] + ${part} = ${leftTotal}`;
          subTitle = 'ما هو الثقل المجهول ليتوازن الميزان؟';
          sig = `MAR_BAL:${leftTotal}:${part}`;
        } else if (type === 'quick_mult' && diff !== 'easy') {
          const f1 = randInt(2, diff === 'medium' ? 9 : 12);
          const f2 = randInt(2, diff === 'medium' ? 8 : 11);
          correctAnswer = f1 * f2;
          num1 = f1;
          num2 = f2;
          op = '×';
          prompt = `${f1} × ${f2} = [ ؟ ]`;
          subTitle = 'احسب ناتج الضرب الذهني السريع';
          sig = getOperationSignature('×', f1, f2);
        } else {
          // Equation (+, -, or ÷ in hard)
          const randRoll = Math.random();
          if (diff === 'hard' && randRoll < 0.28) {
            num2 = randInt(3, 9);
            correctAnswer = randInt(3, 11);
            num1 = num2 * correctAnswer;
            op = '÷';
            prompt = `${num1} ÷ ${num2} = [ ؟ ]`;
            subTitle = 'أوجد خارج القسمة التامة';
            sig = getOperationSignature('÷', num1, num2, true);
          } else if (randRoll > (diff === 'easy' ? 0.35 : 0.5)) {
            num1 = diff === 'easy' ? randInt(3, 12) : diff === 'medium' ? randInt(12, 36) : randInt(25, 62);
            num2 = diff === 'easy' ? randInt(2, 10) : diff === 'medium' ? randInt(8, 26) : randInt(15, 48);
            correctAnswer = num1 + num2;
            op = '+';
            prompt = `${num1} + ${num2} = [ ؟ ]`;
            subTitle = 'أوجد ناتج الجمع الدقيق';
            sig = getOperationSignature('+', num1, num2);
          } else {
            num1 = diff === 'easy' ? randInt(8, 18) : diff === 'medium' ? randInt(20, 52) : randInt(45, 96);
            num2 = diff === 'easy' ? randInt(2, num1 - 2) : diff === 'medium' ? randInt(5, num1 - 5) : randInt(10, num1 - 10);
            correctAnswer = num1 - num2;
            op = '-';
            prompt = `${num1} - ${num2} = [ ؟ ]`;
            subTitle = 'أوجد ناتج الطرح الصحيح';
            sig = getOperationSignature('-', num1, num2, true);
          }
        }

        if (!deduplicatorRef.current.hasSeen(sig)) {
          break;
        }
      }

      deduplicatorRef.current.record(sig);

      const options = generateSmartOptions(correctAnswer, 4, {
        num1,
        num2,
        op,
      });

      return {
        id: qIdx + 1,
        prompt,
        subTitle,
        num1,
        num2,
        op,
        correctAnswer,
        options,
        category: type,
      };
    },
    [useEastern]
  );

  const finishMarathon = useCallback(() => {
    setIsActive(false);
    setIsFinished(true);
    playLevelUnlocked();
    setCoachMood('super_excited');
    setCoachTip('انتهى الوقت! يا لها من جولة أسطورية ومجهود بطولي لا ينسى!');

    // Award virtual coins using up-to-date scoreRef
    const coinsEarned = Math.max(30, Math.floor(scoreRef.current / 15) + 50);
    onAwardCoins(coinsEarned);
  }, [playLevelUnlocked, onAwardCoins]);

  // Stable Countdown Timer Effect
  useEffect(() => {
    if (!isActive || isPaused) return;
    const interval = setInterval(() => {
      setTimeLeft((prev) => (prev > 0 ? prev - 1 : 0));
    }, 1000);
    return () => clearInterval(interval);
  }, [isActive, isPaused]);

  // Trigger finishMarathon cleanly when timeLeft hits 0
  useEffect(() => {
    if (isActive && timeLeft === 0) {
      finishMarathon();
    }
  }, [isActive, timeLeft, finishMarathon]);

  // Start marathon
  const startMarathon = (durationSecs: number = 600) => {
    playClick();
    deduplicatorRef.current.reset();
    setSelectedDuration(durationSecs);
    setTimeLeft(durationSecs);
    setScore(0);
    scoreRef.current = 0;
    setStreak(0);
    setBestStreak(0);
    setSolvedCount(0);
    setTotalAttempts(0);
    setQuestionIndex(0);
    setIsFinished(false);
    setIsActive(true);
    setIsPaused(false);
    setHasSavedRecord(false);
    setShowLeaderboardTab(false);
    setCoachMood('idle');
    setCoachTip('انطلق يا بطل! الوقت يحسب الآن، ركز وحل بأقصى سرعة ممكنة!');

    const firstQ = generateProblem(globalDifficulty, 0);
    setCurrentQuestion(firstQ);
    setSelectedAnswer(null);
    setFeedback(null);
  };

  const handleSelectOption = (num: number) => {
    if (!isActive || isPaused || feedback !== null || !currentQuestion) return;
    setSelectedAnswer(num);
    setTotalAttempts((prev) => prev + 1);
    const nextQIdx = questionIndex + 1;
    setQuestionIndex(nextQIdx);

    const isCorrect = num === currentQuestion.correctAnswer;
    if (isCorrect) {
      setFeedback('correct');
      playCorrectPop();
      const nextStreak = streak + 1;
      setStreak(nextStreak);
      setBestStreak((b) => Math.max(b, nextStreak));
      setSolvedCount((c) => c + 1);

      // Multiplier based on streak
      const multiplier = nextStreak >= 5 ? 2.5 : nextStreak >= 3 ? 1.8 : nextStreak >= 2 ? 1.4 : 1;
      const basePoints = globalDifficulty === 'hard' ? 70 : globalDifficulty === 'medium' ? 50 : 35;
      const earned = Math.round(basePoints * multiplier);
      setScore((s) => s + earned);

      if (nextStreak % 3 === 0) {
        playStreakCombo(nextStreak);
        setCoachMood('super_excited');
        setCoachTip(`سلسلة نارية ${formatNum(nextStreak, useEastern)} إجابات متتالية! نقاطك تتضاعف! 🔥⚡`);
      } else {
        setCoachMood('happy');
        setCoachTip('إجابة صحيحة وسريعة! واصل التقدم!');
      }

      setTimeout(() => {
        const nextQ = generateProblem(globalDifficulty, nextQIdx);
        setCurrentQuestion(nextQ);
        setSelectedAnswer(null);
        setFeedback(null);
      }, 550);
    } else {
      setFeedback('wrong');
      playRetry();
      setStreak(0);
      const diag = coachService.diagnoseMistake(
        num,
        currentQuestion.correctAnswer,
        currentQuestion.op,
        currentQuestion.category === 'sequence' ? 'sequence' : 'marathon',
        currentQuestion.num1,
        currentQuestion.num2
      );
      setCoachMood(diag.mascotMood);
      setCoachTip(diag.advice);

      setTimeout(() => {
        const nextQ = generateProblem(globalDifficulty, nextQIdx);
        setCurrentQuestion(nextQ);
        setSelectedAnswer(null);
        setFeedback(null);
      }, 850);
    }
  };

  const handleSaveToLeaderboard = () => {
    if (hasSavedRecord || !playerNameInput.trim()) return;
    playSuccess();

    const accuracy = totalAttempts > 0 ? Math.round((solvedCount / totalAttempts) * 100) : 0;
    const durationMinutes = Math.round(selectedDuration / 60);

    let title = 'بطل الحساب الصاعد ⭐';
    if (score >= 1500) title = 'أسطورة الحساب الذهني 👑';
    else if (score >= 1000) title = 'برق الرياضيات السريع ⚡';
    else if (score >= 600) title = 'مكتشف الألغاز العبقري 🌟';

    const newEntry: LeaderboardEntry = {
      id: `lb-${Date.now()}`,
      playerName: playerNameInput.trim(),
      score,
      solvedCount,
      totalAttempted: totalAttempts,
      accuracy,
      durationMinutes,
      date: new Date().toISOString().split('T')[0],
      title,
    };

    const updated = [...leaderboard, newEntry]
      .sort((a, b) => b.score - a.score)
      .slice(0, 10);

    setLeaderboard(updated);
    try {
      localStorage.setItem(LEADERBOARD_KEY, JSON.stringify(updated));
    } catch {}

    setHasSavedRecord(true);
    setShowLeaderboardTab(true);
  };

  // Format time MM:SS
  const formatTime = (secs: number) => {
    const mins = Math.floor(secs / 60);
    const rem = secs % 60;
    return `${String(mins).padStart(2, '0')}:${String(rem).padStart(2, '0')}`;
  };

  const progressPercent = Math.max(0, Math.min(100, (timeLeft / selectedDuration) * 100));

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Header bar */}
      <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-[#E5DEC9]">
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={() => {
              playClick();
              onExit();
            }}
            className="px-3.5 py-1.5 text-xs font-bold text-slate-700 bg-[#F4EFE6] hover:bg-[#EAE2D3] rounded-xl border border-[#DCD2C0] flex items-center gap-1.5 transition-colors whitespace-nowrap"
          >
            <ArrowRight className="w-4 h-4" />
            <span>العودة لخريطة الألغاز</span>
          </button>
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-500 text-slate-950 flex items-center gap-1">
                <Trophy className="w-3 h-3" />
                <span>تحدي العشر دقائق الماراثوني</span>
              </span>
              <span className="text-xs text-slate-500 font-medium hidden sm:inline">
                (حل أكبر عدد من الألغاز في وقت قياسي)
              </span>
            </div>
            <h1 className="text-xl font-bold font-display text-slate-900 mt-0.5">
              سباق العشر دقائق الذهبية
            </h1>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => {
              playClick();
              setShowLeaderboardTab((prev) => !prev);
            }}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all border flex items-center gap-1.5 whitespace-nowrap ${
              showLeaderboardTab
                ? 'bg-amber-500 text-slate-950 border-amber-600 shadow-xs'
                : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-50'
            }`}
          >
            <Medal className="w-4 h-4 text-amber-600" />
            <span>لوحة الصدارة المحلية</span>
          </button>
        </div>
      </div>

      {/* Main Container */}
      {!isActive && !isFinished ? (
        /* Intro / Setup Screen */
        <div className="tactile-card rounded-3xl p-6 sm:p-10 bg-white space-y-8">
          <div className="flex flex-col sm:flex-row items-center gap-6 text-center sm:text-right bg-gradient-to-l from-amber-50 via-[#FAF6EE] to-white p-6 rounded-3xl border border-amber-200">
            <OwlMascot mood="super_excited" size={96} />
            <div className="space-y-2 flex-1">
              <div className="text-xs font-bold text-amber-800">
                المستوى الحالي: {DIFFICULTY_CONFIGS[globalDifficulty].label} · التوقيت الموصى به: 10 دقائق
              </div>
              <h2 className="text-2xl sm:text-3xl font-bold font-display text-slate-900">
                هل أنت مستعد لماراثون الألغاز الذهبي؟
              </h2>
              <p className="text-sm text-slate-600 leading-relaxed max-w-xl">
                في هذا التحدي، ستواجه سيلاً متواصلاً من المتتاليات، والموازين، والعمليات الحسابية المتنوعة. كل إجابة صحيحة وسريعة تمنحك نقاطاً مضاعفة وعملات ذهبية!
              </p>
            </div>
          </div>

          {/* Time Picker */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                <Timer className="w-4 h-4 text-amber-600" />
                <span>اختر مدة التحدي المطلوبة:</span>
              </span>
              <span className="text-xs text-slate-500 font-mono-num">
                (الموصى به للأبطال: 10 دقائق كاملة)
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {[
                { secs: 600, label: '10 دقائق (التحدي الكامل)', desc: 'الماراثون الحقيقي لجمع أعلى النقاط', badge: '🏆 الأكثر شهرة' },
                { secs: 300, label: '5 دقائق (سباق متوسط)', desc: 'جلسة تدريب سريعة ومركزة', badge: '⚡ سريع' },
                { secs: 180, label: '3 دقائق (خاطف)', desc: 'تحدٍ قصير لاختبار ردة الفعل', badge: '🎯 خاطف' },
              ].map((t) => (
                <button
                  key={t.secs}
                  type="button"
                  onClick={() => {
                    playClick();
                    setSelectedDuration(t.secs);
                  }}
                  className={`tactile-card rounded-2xl p-4 text-right transition-all border text-slate-800 ${
                    selectedDuration === t.secs
                      ? 'border-amber-500 bg-amber-50/70 ring-2 ring-amber-400/40'
                      : 'hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-center justify-between text-xs font-bold text-amber-700 mb-1">
                    <span>{t.badge}</span>
                    <span className="font-mono-num">{formatTime(t.secs)}</span>
                  </div>
                  <h4 className="font-bold text-sm text-slate-900">{t.label}</h4>
                  <p className="text-[11px] text-slate-500 mt-1">{t.desc}</p>
                </button>
              ))}
            </div>
          </div>

          {/* Start Action */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-4 border-t border-slate-100">
            <div className="text-xs text-slate-500">
              * سيتم تسجيل نتيجتك فوراً في لوحة الصدارة وتكريمك بلقب خاص.
            </div>

            <button
              type="button"
              onClick={() => startMarathon(selectedDuration)}
              className="tactile-button w-full sm:w-auto px-10 py-4 rounded-2xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-display font-bold text-base border-2 border-b-4 border-amber-700 flex items-center justify-center gap-2.5 shadow-md whitespace-nowrap"
            >
              <Play className="w-5 h-5 fill-current" />
              <span>ابدأ التحدي الآن ({formatTime(selectedDuration)})</span>
            </button>
          </div>
        </div>
      ) : isActive && currentQuestion ? (
        /* Active Game Screen */
        <div className="space-y-6">
          {/* Top Live Status Bar */}
          <div className="tactile-card rounded-2xl p-4 bg-white flex flex-wrap items-center justify-between gap-4">
            {/* Countdown Timer */}
            <div className="flex items-center gap-3">
              <div
                className={`p-2.5 rounded-xl border flex items-center gap-2 font-mono-num font-bold text-lg ${
                  timeLeft <= 60
                    ? 'bg-rose-100 text-rose-800 border-rose-300 animate-pulse'
                    : 'bg-amber-50 text-amber-900 border-amber-200'
                }`}
              >
                <Timer className="w-5 h-5" />
                <span>{formatTime(timeLeft)}</span>
              </div>
              <div className="hidden sm:block">
                <div className="text-[10px] font-bold text-slate-400">الوقت المتبقي</div>
                <div className="w-32 bg-slate-100 h-2 rounded-full overflow-hidden border border-slate-200 mt-1">
                  <div
                    className="h-full bg-amber-500 transition-all duration-1000"
                    style={{ width: `${progressPercent}%` }}
                  />
                </div>
              </div>
            </div>

            {/* Score & Streak */}
            <div className="flex items-center gap-4">
              <div className="text-center px-3 py-1 bg-slate-50 rounded-xl border border-slate-200">
                <span className="text-[10px] text-slate-400 block font-bold">النقاط</span>
                <span className="font-mono-num font-bold text-lg text-slate-900">
                  {formatNum(score, useEastern)}
                </span>
              </div>

              <div className="text-center px-3 py-1 bg-amber-50 rounded-xl border border-amber-200 flex items-center gap-1.5">
                <Flame className={`w-5 h-5 ${streak >= 3 ? 'text-amber-500 fill-amber-500 animate-bounce' : 'text-slate-300'}`} />
                <div>
                  <span className="text-[10px] text-amber-800 block font-bold">متتالية</span>
                  <span className="font-mono-num font-bold text-lg text-amber-700">
                    {formatNum(streak, useEastern)}
                  </span>
                </div>
              </div>

              <div className="text-center px-3 py-1 bg-emerald-50 rounded-xl border border-emerald-200">
                <span className="text-[10px] text-emerald-800 block font-bold">محلولة</span>
                <span className="font-mono-num font-bold text-lg text-emerald-700">
                  {formatNum(solvedCount, useEastern)}
                </span>
              </div>

              <button
                type="button"
                onClick={() => {
                  playClick();
                  setIsPaused((p) => !p);
                }}
                className="p-2 text-slate-600 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors"
                title={isPaused ? 'استئناف' : 'إيقاف مؤقت'}
              >
                {isPaused ? <Play className="w-4 h-4 fill-current" /> : <Pause className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {/* Pause Overlay if Paused */}
          {isPaused ? (
            <div className="tactile-card rounded-3xl p-10 bg-white text-center space-y-4">
              <OwlMascot mood="thinking" size={80} />
              <h3 className="text-2xl font-bold font-display text-slate-900">اللعبة متوقفة مؤقتاً</h3>
              <p className="text-xs text-slate-500">خذ نفساً عميقاً ثم تابع التحدي حينما تكون مستعداً!</p>
              <button
                type="button"
                onClick={() => {
                  playClick();
                  setIsPaused(false);
                }}
                className="tactile-button px-8 py-3 rounded-xl bg-amber-500 text-slate-950 font-bold text-sm"
              >
                استئناف اللعب
              </button>
            </div>
          ) : (
            /* Active Question Card */
            <div className="tactile-card rounded-3xl p-6 sm:p-8 bg-white space-y-6">
              <div className="flex items-center justify-between text-xs text-slate-500 border-b border-slate-100 pb-3">
                <span className="font-bold text-amber-800">
                  لغز رقم {formatNum(questionIndex + 1, useEastern)}
                </span>
                <span>{currentQuestion.subTitle}</span>
              </div>

              {/* Central Math Formula Display */}
              <div className="py-6 flex flex-col items-center justify-center bg-gradient-to-b from-[#FAF6EE] to-[#FFFDF7] rounded-2xl border border-[#E5DEC9]">
                <div className="text-3xl sm:text-5xl font-mono-num font-bold tracking-wider text-slate-900" dir="ltr">
                  {formatNum(currentQuestion.prompt, useEastern)}
                </div>
              </div>

              {/* 4 Large Choice Buttons */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2" dir="ltr">
                {currentQuestion.options.map((opt) => {
                  const isSelected = selectedAnswer === opt;
                  const isCorrect = opt === currentQuestion.correctAnswer;
                  let btnColor = 'bg-white border-[#D6CFC2] hover:border-amber-400 hover:bg-amber-50/40 text-slate-800';

                  if (feedback !== null) {
                    if (isCorrect) {
                      btnColor = 'bg-emerald-500 text-white border-emerald-600 scale-105';
                    } else if (isSelected) {
                      btnColor = 'bg-rose-500 text-white border-rose-600 animate-shake';
                    }
                  }

                  return (
                    <button
                      key={opt}
                      type="button"
                      disabled={feedback !== null}
                      onClick={() => handleSelectOption(opt)}
                      className={`tactile-button py-5 px-3 rounded-2xl font-mono-num text-2xl sm:text-3xl font-bold flex items-center justify-center border-2 border-b-4 transition-all ${btnColor}`}
                    >
                      {formatNum(opt, useEastern)}
                    </button>
                  );
                })}
              </div>

              {/* Coach Reaction Bubble */}
              <div className="flex items-center gap-3.5 pt-3 border-t border-slate-100">
                <OwlMascot mood={coachMood} size={54} />
                <div className="flex-1 bg-[#FAF6EE] px-4 py-2.5 rounded-xl border border-[#E5DEC9] text-xs sm:text-sm font-medium text-slate-800">
                  {coachTip}
                </div>
              </div>
            </div>
          )}
        </div>
      ) : (
        /* Finished Results Screen */
        <div className="tactile-card rounded-3xl p-6 sm:p-8 bg-white space-y-8 animate-pop">
          <div className="text-center space-y-3">
            <div className="flex justify-center">
              <OwlMascot mood="super_excited" size={100} />
            </div>
            <div className="text-xs font-bold text-emerald-700 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-200 inline-block">
              ✓ اكتمل ماراثون العشر دقائق بنجاح!
            </div>
            <h2 className="text-3xl font-bold font-display text-slate-900">
              نتيجة مبهرة وأداء بطولي!
            </h2>
            <p className="text-xs sm:text-sm text-slate-600 max-w-md mx-auto">
              لقد واجهت تحدي الوقت بذكاء وتركيز عالٍ. إليك ملخص إنجازاتك في هذه الجولة:
            </p>
          </div>

          {/* Summary Stats Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="tactile-card rounded-2xl p-4 text-center bg-amber-50/60 border-amber-200">
              <span className="text-xs text-amber-800 font-bold block mb-1">النقاط الكلية</span>
              <span className="font-mono-num text-3xl font-bold text-amber-700">
                {formatNum(score, useEastern)}
              </span>
            </div>

            <div className="tactile-card rounded-2xl p-4 text-center bg-emerald-50/60 border-emerald-200">
              <span className="text-xs text-emerald-800 font-bold block mb-1">الألغاز المحلولة</span>
              <span className="font-mono-num text-3xl font-bold text-emerald-700">
                {formatNum(solvedCount, useEastern)}
              </span>
            </div>

            <div className="tactile-card rounded-2xl p-4 text-center bg-sky-50/60 border-sky-200">
              <span className="text-xs text-sky-800 font-bold block mb-1">نسبة الدقة</span>
              <span className="font-mono-num text-3xl font-bold text-sky-700">
                {formatNum(totalAttempts > 0 ? Math.round((solvedCount / totalAttempts) * 100) : 0, useEastern)}%
              </span>
            </div>

            <div className="tactile-card rounded-2xl p-4 text-center bg-purple-50/60 border-purple-200">
              <span className="text-xs text-purple-800 font-bold block mb-1">أعلى متتالية</span>
              <span className="font-mono-num text-3xl font-bold text-purple-700">
                {formatNum(bestStreak, useEastern)}
              </span>
            </div>
          </div>

          {/* Save to Local Leaderboard Form */}
          <div className="p-5 rounded-2xl bg-gradient-to-l from-amber-50 via-white to-amber-50 border-2 border-amber-300 space-y-4">
            <div className="flex items-center gap-2 text-sm font-bold text-amber-900">
              <Trophy className="w-5 h-5 text-amber-600" />
              <span>تسجيل النتيجة في لوحة الصدارة المحلية:</span>
            </div>

            <div className="flex flex-col sm:flex-row items-center gap-3">
              <input
                type="text"
                value={playerNameInput}
                onChange={(e) => setPlayerNameInput(e.target.value)}
                placeholder="اكتب اسمك أو لقبك هنا..."
                disabled={hasSavedRecord}
                className="w-full sm:flex-1 px-4 py-3 rounded-xl border border-amber-300 focus:outline-none focus:ring-2 focus:ring-amber-500 font-bold text-sm bg-white"
              />
              <button
                type="button"
                onClick={handleSaveToLeaderboard}
                disabled={hasSavedRecord || !playerNameInput.trim()}
                className="tactile-button w-full sm:w-auto px-6 py-3 rounded-xl bg-amber-500 hover:bg-amber-400 disabled:opacity-50 text-slate-950 font-bold text-xs whitespace-nowrap flex items-center justify-center gap-2"
              >
                <Check className="w-4 h-4" />
                <span>{hasSavedRecord ? 'تم الحفظ في لوحة الصدارة ✓' : 'حفظ النتيجة الآن'}</span>
              </button>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
            <button
              type="button"
              onClick={() => startMarathon(selectedDuration)}
              className="tactile-button w-full sm:w-auto px-8 py-3.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-sm flex items-center justify-center gap-2 whitespace-nowrap"
            >
              <RotateCcw className="w-4 h-4" />
              <span>إعادة التحدي من جديد</span>
            </button>

            <button
              type="button"
              onClick={() => setShowLeaderboardTab(true)}
              className="tactile-button w-full sm:w-auto px-6 py-3.5 rounded-xl bg-white hover:bg-slate-50 text-slate-800 font-bold text-sm border border-slate-300 flex items-center justify-center gap-2 whitespace-nowrap"
            >
              <Medal className="w-4 h-4 text-amber-600" />
              <span>عرض لوحة الصدارة</span>
            </button>

            <button
              type="button"
              onClick={() => {
                playClick();
                onExit();
              }}
              className="tactile-button w-full sm:w-auto px-6 py-3.5 rounded-xl bg-[#F4EFE6] hover:bg-[#EAE2D3] text-slate-700 font-bold text-sm flex items-center justify-center gap-2 whitespace-nowrap"
            >
              <span>الخريطة الرئيسية</span>
            </button>
          </div>
        </div>
      )}

      {/* Local Leaderboard Modal / Drawer */}
      {showLeaderboardTab && (
        <div className="tactile-card rounded-3xl p-6 sm:p-8 bg-white space-y-6 animate-pop">
          <div className="flex items-center justify-between pb-3 border-b border-[#E5DEC9]">
            <div className="flex items-center gap-2.5">
              <Trophy className="w-6 h-6 text-amber-500" />
              <div>
                <h3 className="text-lg sm:text-xl font-bold font-display text-slate-900">
                  لوحة الصدارة المحلية لأبطال العشر دقائق
                </h3>
                <p className="text-xs text-slate-500">أفضل النتائج المحفوظة على هذا الجهاز</p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => setShowLeaderboardTab(false)}
              className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-right text-xs sm:text-sm">
              <thead>
                <tr className="border-b border-slate-200 text-slate-500 font-bold">
                  <th className="py-2.5 px-3">الترتيب</th>
                  <th className="py-2.5 px-3">اسم البطل</th>
                  <th className="py-2.5 px-3 text-center">النقاط</th>
                  <th className="py-2.5 px-3 text-center">الألغاز</th>
                  <th className="py-2.5 px-3 text-center">الدقة</th>
                  <th className="py-2.5 px-3">اللقب الفخري</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {leaderboard.map((entry, idx) => {
                  const isTop1 = idx === 0;
                  const isTop2 = idx === 1;
                  const isTop3 = idx === 2;

                  return (
                    <tr
                      key={entry.id}
                      className={`transition-colors ${
                        isTop1
                          ? 'bg-amber-50/70 font-bold'
                          : isTop2
                          ? 'bg-slate-50/70 font-medium'
                          : isTop3
                          ? 'bg-orange-50/40'
                          : 'hover:bg-slate-50/50'
                      }`}
                    >
                      <td className="py-3 px-3">
                        <span className="flex items-center gap-1.5 font-bold">
                          {isTop1 ? '🥇 الأول' : isTop2 ? '🥈 الثاني' : isTop3 ? '🥉 الثالث' : `#${idx + 1}`}
                        </span>
                      </td>
                      <td className="py-3 px-3 font-bold text-slate-900">
                        {entry.playerName}
                      </td>
                      <td className="py-3 px-3 text-center font-mono-num font-bold text-amber-700">
                        {formatNum(entry.score, useEastern)}
                      </td>
                      <td className="py-3 px-3 text-center font-mono-num">
                        {formatNum(entry.solvedCount, useEastern)}
                      </td>
                      <td className="py-3 px-3 text-center font-mono-num text-emerald-700 font-bold">
                        {formatNum(entry.accuracy, useEastern)}%
                      </td>
                      <td className="py-3 px-3 text-xs text-slate-600 truncate max-w-[150px]">
                        {entry.title}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
