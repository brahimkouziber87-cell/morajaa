import React, { useState, useEffect, useCallback } from 'react';
import { useGameAudio, formatNum } from '../utils/sound';
import { generateUniqueArithmeticBatch } from '../utils/mathEngine';
import { coachService } from '../utils/pedagogicalCoach';
import { OwlMascot } from './GameIllustrations';
import {
  RotateCcw,
  Sparkles,
  Check,
  Zap,
  Star,
  ArrowRight,
  Flame,
  Award,
} from 'lucide-react';

export type MathOperation = '+' | '-' | '×' | '÷' | 'mix';

export interface PracticeProblem {
  id: number;
  num1: number;
  num2: number;
  op: '+' | '-' | '×' | '÷';
  answer: number;
  options: number[];
}

export const OPERATION_METADATA: Record<
  MathOperation,
  {
    symbol: string;
    name: string;
    desc: string;
    color: string;
    bgBadge: string;
    activeBorder: string;
  }
> = {
  '+': {
    symbol: '+',
    name: 'الجمع فقط',
    desc: 'ضم المجموعات وتكوين العشرات والمئات',
    color: '#10B981',
    bgBadge: 'bg-emerald-50 text-emerald-800 border-emerald-200',
    activeBorder: 'border-emerald-500 bg-emerald-500 text-white',
  },
  '-': {
    symbol: '-',
    name: 'الطرح فقط',
    desc: 'إيجاد الفرق والعد التنازلي المباشر',
    color: '#0EA5E9',
    bgBadge: 'bg-sky-50 text-sky-800 border-sky-200',
    activeBorder: 'border-sky-500 bg-sky-500 text-white',
  },
  '×': {
    symbol: '×',
    name: 'الضرب فقط',
    desc: 'الجمع المتكرر وجداول الضرب الذكية',
    color: '#F59E0B',
    bgBadge: 'bg-amber-50 text-amber-800 border-amber-200',
    activeBorder: 'border-amber-500 bg-amber-500 text-white',
  },
  '÷': {
    symbol: '÷',
    name: 'القسمة فقط',
    desc: 'توزيع الكميات بالتساوي بدون باقٍ',
    color: '#8B5CF6',
    bgBadge: 'bg-indigo-50 text-indigo-800 border-indigo-200',
    activeBorder: 'border-indigo-500 bg-indigo-500 text-white',
  },
  mix: {
    symbol: '🔀',
    name: 'كوكتيل العمليات',
    desc: 'مزيج عشوائي من الجمع والطرح والضرب والقسمة',
    color: '#EC4899',
    bgBadge: 'bg-pink-50 text-pink-800 border-pink-200',
    activeBorder: 'border-pink-500 bg-pink-500 text-white',
  },
};

interface PracticeModeProps {
  useEastern: boolean;
  initialOperation?: MathOperation;
  onExit: () => void;
  onCompleteSession: (correctCount: number, total: number) => void;
}

export const PracticeMode: React.FC<PracticeModeProps> = ({
  useEastern,
  initialOperation = '+',
  onExit,
  onCompleteSession,
}) => {
  const { playClick, playCorrectPop, playRetry, playStreakCombo, playStarReveal, playSuccess } =
    useGameAudio();

  const [operation, setOperation] = useState<MathOperation>(initialOperation);
  const [rangeTier, setRangeTier] = useState<'basic' | 'medium' | 'pro'>('basic');
  const [selectedTable, setSelectedTable] = useState<number | 'all'>('all');

  // Session state
  const [currentIndex, setCurrentIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [streak, setStreak] = useState(0);
  const [bestSessionStreak, setBestSessionStreak] = useState(0);
  const [isCompleted, setIsCompleted] = useState(false);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [feedback, setFeedback] = useState<'correct' | 'wrong' | null>(null);
  const [coachMsg, setCoachMsg] = useState('اختر الإجابة الصحيحة للعملية الرياضية!');
  const [problems, setProblems] = useState<PracticeProblem[]>([]);

  // Generate 10 guaranteed non-repeating problems for this specific operation & range
  const generateProblemList = useCallback(
    (opType: MathOperation, range: 'basic' | 'medium' | 'pro', table: number | 'all'): PracticeProblem[] => {
      return generateUniqueArithmeticBatch({
        count: 10,
        operation: opType,
        rangeTier: range,
        selectedTable: table,
      }).map((item) => ({
        id: item.id,
        num1: item.num1,
        num2: item.num2,
        op: item.op,
        answer: item.answer,
        options: item.options,
      }));
    },
    []
  );

  const startNewSession = useCallback(
    (op: MathOperation, range: 'basic' | 'medium' | 'pro', table: number | 'all') => {
      const generated = generateProblemList(op, range, table);
      setProblems(generated);
      setCurrentIndex(0);
      setScore(0);
      setStreak(0);
      setBestSessionStreak(0);
      setIsCompleted(false);
      setSelectedAnswer(null);
      setFeedback(null);
      setCoachMsg(`تدريب ${OPERATION_METADATA[op].name} (10 مسائل فريدة بلا تكرار): هيا بنا نبدأ!`);
    },
    [generateProblemList]
  );

  useEffect(() => {
    startNewSession(operation, rangeTier, selectedTable);
  }, [operation, rangeTier, selectedTable, startNewSession]);

  const handleSelectAnswer = (opt: number) => {
    if (feedback !== null || isCompleted) return;

    setSelectedAnswer(opt);
    const curr = problems[currentIndex];
    if (!curr) return;

    if (opt === curr.answer) {
      setFeedback('correct');
      const nextScore = score + 1;
      const nextStreak = streak + 1;
      setScore(nextScore);
      setStreak(nextStreak);
      setBestSessionStreak((prev) => Math.max(prev, nextStreak));

      if (nextStreak > 1) {
        playStreakCombo(nextStreak);
      } else {
        playCorrectPop();
      }

      setCoachMsg(
        nextStreak >= 3
          ? `رائع جداً! سلسلة إجابات صحيحة: ${formatNum(nextStreak, useEastern)} متتالية!`
          : `إجابة صحيحة! أحسنت يا بطل.`
      );

      setTimeout(() => {
        if (currentIndex + 1 < problems.length) {
          setCurrentIndex((prev) => prev + 1);
          setSelectedAnswer(null);
          setFeedback(null);
        } else {
          // Finish session
          setIsCompleted(true);
          playSuccess();
          // Sequential star reveals
          const finalStars = nextScore >= 9 ? 3 : nextScore >= 6 ? 2 : 1;
          setTimeout(() => playStarReveal(1), 300);
          if (finalStars >= 2) setTimeout(() => playStarReveal(2), 650);
          if (finalStars >= 3) setTimeout(() => playStarReveal(3), 1000);
          onCompleteSession(nextScore, problems.length);
        }
      }, 700);
    } else {
      setFeedback('wrong');
      setStreak(0);
      playRetry();
      const diag = coachService.diagnoseMistake(
        opt,
        curr.answer,
        curr.op,
        'practice',
        curr.num1,
        curr.num2
      );
      setCoachMsg(
        `${diag.advice} (الإجابة الصحيحة: ${formatNum(curr.answer, useEastern)})`
      );

      setTimeout(() => {
        if (currentIndex + 1 < problems.length) {
          setCurrentIndex((prev) => prev + 1);
          setSelectedAnswer(null);
          setFeedback(null);
        } else {
          setIsCompleted(true);
          playSuccess();
          onCompleteSession(score, problems.length);
        }
      }, 1250);
    }
  };

  const currProb = problems[currentIndex];

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Top Header bar with exit */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#E5DEC9]">
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={() => {
              playClick();
              onExit();
            }}
            className="px-3.5 py-1.5 text-xs font-bold text-slate-700 bg-[#F4EFE6] hover:bg-[#E8E0D0] rounded-xl border border-[#DCD2C0] flex items-center gap-1.5 transition-colors"
          >
            <ArrowRight className="w-4 h-4" />
            <span>العودة لخريطة الألغاز</span>
          </button>
          <div>
            <div className="text-xs text-slate-500 font-bold">وضع الممارسة المركزة</div>
            <h1 className="text-xl font-bold font-display text-slate-900">
              تدريب مخصص على عملية: {OPERATION_METADATA[operation].name}
            </h1>
          </div>
        </div>

        {/* Live session metrics */}
        {!isCompleted && (
          <div className="flex items-center gap-3">
            {streak > 1 && (
              <div className="flex items-center gap-1.5 px-3 py-1 bg-amber-50 text-amber-900 border border-amber-300 rounded-xl text-xs font-bold animate-pop">
                <Flame className="w-4 h-4 text-amber-500 fill-amber-500" />
                <span>سلسلة: {formatNum(streak, useEastern)}</span>
              </div>
            )}
            <div className="px-3 py-1 bg-emerald-50 text-emerald-900 border border-emerald-200 rounded-xl text-xs font-bold">
              النقاط: {formatNum(score, useEastern)} / {formatNum(problems.length, useEastern)}
            </div>
          </div>
        )}
      </div>

      {/* Operation Selection Strip (Buttons: +, -, ×, ÷, mix) */}
      <div className="tactile-card rounded-2xl p-4 bg-white space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <span className="text-xs font-bold text-slate-700">
            اختر العملية الرياضية التي تريد التدرب عليها:
          </span>
          <span className="text-xs text-slate-500 hidden sm:inline">
            (تتغير الأسئلة وتتولد فحصاً فورياً للعملية)
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5">
          {(['+', '-', '×', '÷', 'mix'] as MathOperation[]).map((op) => {
            const meta = OPERATION_METADATA[op];
            const isSelected = operation === op;
            return (
              <button
                key={op}
                type="button"
                onClick={() => {
                  playClick();
                  setOperation(op);
                }}
                className={`tactile-button p-3 rounded-xl border-2 flex flex-col items-center justify-center gap-1 transition-all ${
                  isSelected
                    ? meta.activeBorder + ' shadow-sm scale-102 font-bold'
                    : 'bg-[#FAF6EE] text-slate-800 border-[#E2D9C8] hover:border-amber-400'
                }`}
              >
                <span className="text-2xl font-mono-num font-bold leading-none">{meta.symbol}</span>
                <span className="text-xs font-display">{meta.name}</span>
              </button>
            );
          })}
        </div>

        {/* Range / Table sub-selector */}
        <div className="pt-2 flex flex-wrap items-center justify-between gap-3 border-t border-slate-100 text-xs">
          <div className="flex items-center gap-2">
            <span className="font-bold text-slate-600">نطاق الأعداد:</span>
            <div className="flex items-center gap-1 p-0.5 bg-[#FAF6EE] rounded-lg border border-[#E5DEC9]">
              {(
                [
                  { id: 'basic', label: 'صغيرة (1-12)' },
                  { id: 'medium', label: 'متوسطة (حتى 50)' },
                  { id: 'pro', label: 'كبيرة (حتى 100)' },
                ] as const
              ).map((tier) => (
                <button
                  key={tier.id}
                  type="button"
                  onClick={() => {
                    playClick();
                    setRangeTier(tier.id);
                  }}
                  className={`px-2.5 py-1 rounded-md font-bold transition-colors ${
                    rangeTier === tier.id ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
                  }`}
                >
                  {tier.label}
                </button>
              ))}
            </div>
          </div>

          {/* If Multiplication, optional specific table selector */}
          {operation === '×' && (
            <div className="flex items-center gap-1.5 flex-wrap">
              <span className="font-bold text-slate-600">جدول:</span>
              <button
                type="button"
                onClick={() => setSelectedTable('all')}
                className={`px-2 py-0.5 rounded-lg border text-xs font-bold ${
                  selectedTable === 'all'
                    ? 'bg-amber-500 text-white border-amber-600'
                    : 'bg-white text-slate-700 border-slate-300'
                }`}
              >
                الكل
              </button>
              {[2, 3, 4, 5, 6, 7, 8, 9, 10].map((num) => (
                <button
                  key={num}
                  type="button"
                  onClick={() => setSelectedTable(num)}
                  className={`px-2 py-0.5 rounded-lg border font-mono-num text-xs font-bold ${
                    selectedTable === num
                      ? 'bg-amber-500 text-white border-amber-600'
                      : 'bg-white text-slate-700 border-slate-300'
                  }`}
                >
                  {formatNum(num, useEastern)}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Main Practice Workspace */}
      {!isCompleted && currProb && (
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-start">
          {/* Question Card (8 cols) */}
          <div className="md:col-span-8 tactile-card rounded-3xl p-6 sm:p-8 bg-white space-y-6">
            <div className="flex items-center justify-between text-xs text-slate-500 font-bold">
              <span>
                السؤال {formatNum(currentIndex + 1, useEastern)} من {formatNum(problems.length, useEastern)}
              </span>
              <span className={`px-2.5 py-0.5 rounded-full border ${OPERATION_METADATA[currProb.op].bgBadge}`}>
                عملية ({currProb.op})
              </span>
            </div>

            {/* Micro Progress Bar */}
            <div className="w-full h-2.5 bg-slate-100 rounded-full overflow-hidden border border-slate-200">
              <div
                className="h-full bg-amber-500 transition-all duration-300 rounded-full"
                style={{ width: `${((currentIndex + 1) / problems.length) * 100}%` }}
              />
            </div>

            {/* Big Math Equation Box */}
            <div className="bg-gradient-to-b from-[#FFFDF7] to-[#FAF5E8] p-8 rounded-2xl border-2 border-[#E5DEC9] flex flex-col items-center justify-center gap-4">
              <div
                className="flex items-center justify-center gap-4 font-mono-num text-4xl sm:text-6xl font-bold text-slate-900"
                dir="ltr"
              >
                <span>{formatNum(currProb.num1, useEastern)}</span>
                <span className="text-amber-600 font-bold">{currProb.op}</span>
                <span>{formatNum(currProb.num2, useEastern)}</span>
                <span className="text-slate-400">=</span>
                <span
                  className={`w-16 h-16 sm:w-20 sm:h-20 rounded-2xl flex items-center justify-center border-2 border-dashed ${
                    feedback === 'correct'
                      ? 'bg-emerald-500 text-white border-emerald-600'
                      : feedback === 'wrong'
                      ? 'bg-rose-500 text-white border-rose-600'
                      : 'bg-white text-sky-600 border-sky-400'
                  }`}
                >
                  {selectedAnswer !== null ? formatNum(selectedAnswer, useEastern) : '؟'}
                </span>
              </div>

              {/* Optional Visual Counting representation for basic additions/subtractions */}
              {rangeTier === 'basic' && currProb.num1 <= 10 && currProb.num2 <= 10 && (
                <div className="flex items-center gap-2 pt-2 text-xs text-slate-500 font-mono-num" dir="ltr">
                  <span>●</span>
                  <span>{formatNum(currProb.num1, useEastern)} وحدات</span>
                  <span>{currProb.op}</span>
                  <span>{formatNum(currProb.num2, useEastern)} وحدات</span>
                </div>
              )}
            </div>

            {/* Answer Options Grid */}
            <div className="space-y-2">
              <div className="text-xs font-bold text-slate-600 text-center">
                اختر النتيجة الصحيحة:
              </div>
              <div className="grid grid-cols-2 gap-3" dir="ltr">
                {currProb.options.map((opt, i) => {
                  const isThisSelected = selectedAnswer === opt;
                  const isThisCorrect = opt === currProb.answer;
                  return (
                    <button
                      key={i}
                      type="button"
                      disabled={feedback !== null}
                      onClick={() => handleSelectAnswer(opt)}
                      className={`tactile-button py-4 rounded-2xl font-mono-num text-2xl sm:text-3xl font-bold border-2 border-b-4 transition-all ${
                        isThisSelected && feedback === 'correct'
                          ? 'bg-emerald-600 text-white border-emerald-800 scale-102'
                          : isThisSelected && feedback === 'wrong'
                          ? 'bg-rose-600 text-white border-rose-800'
                          : feedback !== null && isThisCorrect
                          ? 'bg-emerald-100 text-emerald-950 border-emerald-400'
                          : 'bg-[#FAF6EE] text-slate-800 border-[#E2D9C8] hover:bg-amber-100 hover:border-amber-400'
                      }`}
                    >
                      {formatNum(opt, useEastern)}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Coach & Encouragement Card (4 cols) */}
          <div className="md:col-span-4 space-y-4">
            <div className="tactile-card rounded-2xl p-5 bg-white space-y-4 text-center sm:text-right">
              <div className="flex items-center justify-center sm:justify-start gap-3">
                <OwlMascot
                  mood={feedback === 'correct' ? 'happy' : feedback === 'wrong' ? 'encouraging' : 'idle'}
                  size={60}
                />
                <div>
                  <h3 className="text-sm font-bold font-display text-slate-900">المرشد الذكي</h3>
                  <span className="text-xs text-slate-500">التدريب يصنع الأبطال!</span>
                </div>
              </div>

              <p className="text-xs text-slate-700 leading-relaxed bg-[#FAF6EE] p-3 rounded-xl border border-[#E5DEC9]">
                {coachMsg}
              </p>

              <div className="pt-2 border-t border-slate-100 space-y-2 text-xs">
                <div className="flex items-center justify-between text-slate-600">
                  <span>أفضل سلسلة في الجولة:</span>
                  <span className="font-mono-num font-bold text-amber-700">
                    {formatNum(bestSessionStreak, useEastern)} متتالية
                  </span>
                </div>
                <div className="flex items-center justify-between text-slate-600">
                  <span>نوع العملية:</span>
                  <span className="font-bold text-indigo-700">{OPERATION_METADATA[operation].name}</span>
                </div>
              </div>

              <button
                type="button"
                onClick={() => startNewSession(operation, rangeTier, selectedTable)}
                className="w-full py-2.5 rounded-xl border border-slate-300 hover:bg-slate-50 text-xs font-bold text-slate-700 flex items-center justify-center gap-1.5 transition-colors"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>إعادة بدء هذه الجولة</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Completion Summary Card */}
      {isCompleted && (
        <div className="tactile-card rounded-3xl p-8 bg-white text-center max-w-xl mx-auto space-y-6 animate-pop">
          <div className="flex justify-center">
            <OwlMascot mood="happy" size={88} />
          </div>

          <div className="space-y-2">
            <div className="text-xs font-bold text-emerald-700">
              ✓ تم إكمال جولة التدريب بنجاح!
            </div>
            <h2 className="text-2xl sm:text-3xl font-bold font-display text-slate-900">
              تدريب رائع ومثمر!
            </h2>
            <p className="text-sm text-slate-600">
              لقد تدربت على <span className="font-bold">{OPERATION_METADATA[operation].name}</span> وحققت{' '}
              <span className="font-mono-num font-bold text-emerald-700">
                {formatNum(score, useEastern)} من {formatNum(problems.length, useEastern)}
              </span>{' '}
              إجابة صحيحة.
            </p>
          </div>

          {/* Stars */}
          <div className="flex items-center justify-center gap-3">
            {[1, 2, 3].map((starIdx) => {
              const earned = starIdx <= (score >= 9 ? 3 : score >= 6 ? 2 : 1);
              return (
                <div
                  key={starIdx}
                  className={`p-3 rounded-2xl border-2 ${
                    earned ? 'bg-amber-50 border-amber-300 text-amber-500 scale-105' : 'bg-slate-50 border-slate-200 text-slate-300'
                  }`}
                >
                  <Star className={`w-8 h-8 ${earned ? 'fill-amber-400 text-amber-500' : ''}`} />
                </div>
              );
            })}
          </div>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
            <button
              type="button"
              onClick={() => startNewSession(operation, rangeTier, selectedTable)}
              className="tactile-button w-full sm:w-auto px-7 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-sm border-b-4 border-emerald-800 flex items-center justify-center gap-2"
            >
              <RotateCcw className="w-4 h-4" />
              <span>جولة أخرى لنفس العملية</span>
            </button>
            <button
              type="button"
              onClick={onExit}
              className="tactile-button w-full sm:w-auto px-6 py-3 rounded-xl bg-[#FAF6EE] text-slate-800 font-bold text-sm border-b-4 border-[#DCD2C0] flex items-center justify-center gap-2"
            >
              <span>العودة لخريطة الألغاز</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
