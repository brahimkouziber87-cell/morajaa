import {
  randInt,
  generateSmartOptions,
  globalDeduplicator,
  generateUniqueArithmeticBatch,
  shuffleArray,
} from '../utils/mathEngine';

export type PuzzleMode = 'BRIDGE_PUZZLE' | 'BALANCE_LAB' | 'MAGIC_GRID' | 'CODE_BREAKER' | 'SPEED_MATH';
export type DifficultyTier = 'easy' | 'medium' | 'hard';

export interface DifficultyMetadata {
  id: DifficultyTier;
  label: string;
  ageRange: string;
  operations: string[];
  numbersRange: string;
  color: string;
  badgeBg: string;
  description: string;
}

export const DIFFICULTY_CONFIGS: Record<DifficultyTier, DifficultyMetadata> = {
  easy: {
    id: 'easy',
    label: 'سهل (مبتدئ)',
    ageRange: '5 - 7 سنوات',
    operations: ['+', '-'],
    numbersRange: '1 - 15',
    color: '#059669',
    badgeBg: 'bg-emerald-50 text-emerald-800 border-emerald-200',
    description: 'جمع وطرح أساسي بأعداد صغيرة مع تمثيل بصري واضح للعد',
  },
  medium: {
    id: 'medium',
    label: 'متوسط (متمرس)',
    ageRange: '7 - 9 سنوات',
    operations: ['+', '-', '×'],
    numbersRange: '10 - 50',
    color: '#D97706',
    badgeBg: 'bg-amber-50 text-amber-800 border-amber-200',
    description: 'جمع وطرح بالعشرات مع جداول الضرب البسيطة (×2، ×3، ×5)',
  },
  hard: {
    id: 'hard',
    label: 'صعب (عبقري)',
    ageRange: '9 - 12 سنة',
    operations: ['+', '-', '×', '÷'],
    numbersRange: '20 - 100',
    color: '#DC2626',
    badgeBg: 'bg-rose-50 text-rose-800 border-rose-200',
    description: 'عمليات مركبة، قسمة منضبطة، معادلات بمجهولين وأعداد حتى 100',
  },
};

export interface BridgePuzzleData {
  subType: 'sequence' | 'missing_number' | 'visual_groups';
  prompt: string;
  sequence?: (number | null)[];
  stepRule?: string;
  equation?: {
    left: number | null;
    operator: '+' | '-' | '×' | '÷';
    right: number | null;
    result: number | null;
  };
  visualIcon?: 'apple' | 'star' | 'gem' | 'crown' | 'crystal';
  correctAnswer: number;
  options: number[];
}

export interface BalancePuzzleData {
  prompt: string;
  leftFixedWeights: number[];
  leftMysteryCount: number;
  mysteryBoxValue: number;
  rightFixedWeights: number[];
  interactiveMode: 'SOLVE_MYSTERY_BOX' | 'ADD_WEIGHTS_TO_RIGHT';
  availableWeights: number[];
  targetAnswer: number;
  operator?: '+' | '×';
}

export interface MagicGridData {
  prompt: string;
  gridSize: 3;
  targetRowSums: number[];
  targetColSums: number[];
  initialGrid: (number | null)[][];
  solutionGrid: number[][];
  availableTiles: number[];
}

export interface CodeBreakerClue {
  symbols: ('gem' | 'star' | 'apple' | 'crown' | 'moon')[];
  operator: '+' | '-' | '×' | '÷';
  result: number;
  explanation: string;
}

export interface CodeBreakerData {
  prompt: string;
  symbolValues: Record<'gem' | 'star' | 'apple' | 'crown' | 'moon', number>;
  activeSymbols: ('gem' | 'star' | 'apple' | 'crown' | 'moon')[];
  clues: CodeBreakerClue[];
  finalQuestion: {
    s1: 'gem' | 'star' | 'apple' | 'crown' | 'moon';
    op1: '+' | '-' | '×' | '÷';
    s2: 'gem' | 'star' | 'apple' | 'crown' | 'moon';
    op2?: '+' | '-' | '×';
    s3?: 'gem' | 'star' | 'apple' | 'crown' | 'moon';
  };
  correctAnswer: number;
  options: number[];
}

export interface SpeedMathProblem {
  num1: number;
  operator: '+' | '-' | '×' | '÷';
  num2: number;
  answer: number;
  options: number[];
}

export interface LevelConfig {
  id: number;
  worldId: number;
  worldName: string;
  title: string;
  subtitle: string;
  skillTag: string;
  difficulty: DifficultyTier;
  mode: PuzzleMode;
  storyContext: string;
  hints: [string, string, string];
  bridgeData?: BridgePuzzleData;
  balanceData?: BalancePuzzleData;
  gridData?: MagicGridData;
  codeData?: CodeBreakerData;
}

export const WORLDS = [
  {
    id: 1,
    name: 'وادي الجسور والأنماط',
    subtitle: 'الجمع، الطرح، ومتتاليات الأرقام المنطقية',
    skillSummary: 'الحساب المباشر والأنماط',
    accentColor: '#10B981',
  },
  {
    id: 2,
    name: 'مختبر الميزان الذكي',
    subtitle: 'موازنة الكفتين واستنتاج قيمة الصناديق المجهولة',
    skillSummary: 'توازن المعادلات والجبر البصري',
    accentColor: '#0EA5E9',
  },
  {
    id: 3,
    name: 'قلعة الشبكات السحرية',
    subtitle: 'تركيب الأعداد لمطابقة مجموع الصفوف والأعمدة',
    skillSummary: 'التفكير المكاني والجمع المنطقي',
    accentColor: '#F59E0B',
  },
  {
    id: 4,
    name: 'خزينة الشفرات والكنوز',
    subtitle: 'فك شفرات الرموز واستنتاج قيمتها الحسابية',
    skillSummary: 'الاستنتاج وحل المعادلات المتزامنة',
    accentColor: '#8B5CF6',
  },
];

// Dynamic Puzzle Generator conditioned on DifficultyTier with Deduplication
export function generateDynamicPuzzle(
  mode: PuzzleMode,
  difficulty: DifficultyTier,
  seedCounter: number
): LevelConfig {
  if (mode === 'BRIDGE_PUZZLE') {
    const isSequence = seedCounter % 2 === 0;

    if (isSequence) {
      let step = 2;
      let start = 2;
      let stepRuleText = '+2';
      let missingIndex = 3;
      let seq: (number | null)[] = [];
      let ans = 8;

      for (let attempt = 0; attempt < 25; attempt++) {
        if (difficulty === 'easy') {
          step = randInt(1, 3);
          start = randInt(1, 7);
          stepRuleText = `+${step}`;
          missingIndex = randInt(2, 4);
          seq = [0, 1, 2, 3, 4].map((i) => (i === missingIndex ? null : start + i * step));
          ans = start + missingIndex * step;
        } else if (difficulty === 'medium') {
          const isSubtraction = (seedCounter + attempt) % 3 === 0;
          if (isSubtraction) {
            step = randInt(2, 5);
            start = randInt(28, 48);
            stepRuleText = `-${step}`;
            missingIndex = randInt(2, 4);
            seq = [0, 1, 2, 3, 4].map((i) => (i === missingIndex ? null : start - i * step));
            ans = start - missingIndex * step;
          } else {
            step = randInt(4, 8);
            start = randInt(4, 16);
            stepRuleText = `+${step}`;
            missingIndex = randInt(2, 4);
            seq = [0, 1, 2, 3, 4].map((i) => (i === missingIndex ? null : start + i * step));
            ans = start + missingIndex * step;
          }
        } else {
          // Hard: Geometric progression (×2) or larger arithmetic steps (+9..+14 or -8..-11)
          const isMult = (seedCounter + attempt) % 2 === 1;
          if (isMult) {
            step = 2;
            start = randInt(2, 5);
            stepRuleText = `×${step}`;
            missingIndex = randInt(2, 3);
            seq = [0, 1, 2, 3, 4].map((i) => (i === missingIndex ? null : start * Math.pow(step, i)));
            ans = start * Math.pow(step, missingIndex);
          } else {
            step = randInt(8, 13);
            start = randInt(12, 32);
            stepRuleText = `+${step}`;
            missingIndex = randInt(2, 4);
            seq = [0, 1, 2, 3, 4].map((i) => (i === missingIndex ? null : start + i * step));
            ans = start + missingIndex * step;
          }
        }

        const sig = `SEQ:${difficulty}:${start}:${stepRuleText}:${missingIndex}`;
        if (!globalDeduplicator.hasSeen(sig)) {
          globalDeduplicator.record(sig);
          break;
        }
      }

      const opts = generateSmartOptions(ans, 5);

      return {
        id: 100 + seedCounter,
        worldId: 1,
        worldName: 'وادي الجسور والأنماط',
        title: `نمط الجسر (${DIFFICULTY_CONFIGS[difficulty].label})`,
        subtitle: `نمط متتالي بقاعدة حسابية (${stepRuleText})`,
        skillTag: 'الأنماط العددية',
        difficulty,
        mode: 'BRIDGE_PUZZLE',
        storyContext: `سلسلة حجارة الجسر تسير بقاعدة محددة. لاحظ مقدار التغير بين الحجارة لاكتشاف الحجر المفقود!`,
        hints: [
          `قارن بين حجرين متجاورين لمعرفة مقدار القفز الثابت.`,
          `القاعدة هنا هي: (${stepRuleText}) في كل خطوة.`,
          `بتطبيق القاعدة على الحجر السابق، نجد أن العدد المفقود هو ${ans}.`,
        ],
        bridgeData: {
          subType: 'sequence',
          prompt: 'اكتشف العدد المناسب لإكمال حجارة الجسر:',
          sequence: seq,
          stepRule: stepRuleText,
          visualIcon: 'star',
          correctAnswer: ans,
          options: opts,
        },
      };
    } else {
      // Equation Missing Number with Deduplication
      let op: '+' | '-' | '×' | '÷' = '+';
      let left = 5;
      let right = 4;
      let result = 9;

      for (let attempt = 0; attempt < 25; attempt++) {
        if (difficulty === 'easy') {
          op = (seedCounter + attempt) % 2 === 0 ? '+' : '-';
          if (op === '+') {
            left = randInt(2, 9);
            right = randInt(2, 8);
            result = left + right;
          } else {
            left = randInt(8, 15);
            right = randInt(2, left - 2);
            result = left - right;
          }
        } else if (difficulty === 'medium') {
          const choice = (seedCounter + attempt) % 3;
          if (choice === 0) {
            op = '×';
            left = randInt(3, 7);
            right = randInt(3, 7);
            result = left * right;
          } else if (choice === 1) {
            op = '-';
            left = randInt(24, 50);
            right = randInt(8, left - 6);
            result = left - right;
          } else {
            op = '+';
            left = randInt(14, 34);
            right = randInt(11, 26);
            result = left + right;
          }
        } else {
          const choice = (seedCounter + attempt) % 2;
          if (choice === 0) {
            op = '÷';
            right = randInt(3, 9);
            result = randInt(4, 11);
            left = right * result; // clean exact division
          } else {
            op = '×';
            left = randInt(6, 12);
            right = randInt(6, 9);
            result = left * right;
          }
        }

        const sig = `BR_EQ:${op}:${left}:${right}`;
        if (!globalDeduplicator.hasSeen(sig)) {
          globalDeduplicator.record(sig);
          break;
        }
      }

      const ans = right;
      const opts = generateSmartOptions(ans, 5, { num1: left, num2: right, op });

      return {
        id: 110 + seedCounter,
        worldId: 1,
        worldName: 'وادي الجسور والأنماط',
        title: `معادلة الجسر (${DIFFICULTY_CONFIGS[difficulty].label})`,
        subtitle: `إيجاد العدد المفقود في عملية (${op})`,
        skillTag: `حساب (${op})`,
        difficulty,
        mode: 'BRIDGE_PUZZLE',
        storyContext: `لإكمال حجر الجسر، أوجد العدد الناقص الذي يحقق المعادلة بدقة.`,
        hints: [
          `المعادلة هي: ${left} ${op} [؟] = ${result}.`,
          op === '+'
            ? `استخدم العملية العكسية (الطرح): ${result} - ${left}.`
            : op === '-'
            ? `اطرح الناتج (${result}) من العدد الأول (${left}): ${left} - ${result}.`
            : op === '×'
            ? `اقسم الناتج (${result}) على العامل الأول (${left}): ${result} ÷ ${left}.`
            : `اقسم المقسوم (${left}) على الناتج (${result}): ${left} ÷ ${result}.`,
          `العدد الصحيح هو ${ans}.`,
        ],
        bridgeData: {
          subType: 'missing_number',
          prompt: `ما العدد المفقود في المعادلة: ${left} ${op} [؟] = ${result}؟`,
          equation: { left, operator: op, right: null, result },
          visualIcon: 'gem',
          correctAnswer: ans,
          options: opts,
        },
      };
    }
  }

  if (mode === 'BALANCE_LAB') {
    let mysteryCount = 1;
    let mysteryValue = 5;
    let leftKnown = 3;
    let rightWeights: number[] = [];

    for (let attempt = 0; attempt < 25; attempt++) {
      if (difficulty === 'easy') {
        mysteryCount = 1;
        mysteryValue = randInt(3, 9);
        leftKnown = randInt(2, 6);
      } else if (difficulty === 'medium') {
        mysteryCount = 1;
        mysteryValue = randInt(9, 22);
        leftKnown = randInt(6, 16);
      } else {
        // Hard: 2 identical mystery boxes: 2 * [?] + leftKnown = total
        mysteryCount = 2;
        mysteryValue = randInt(7, 18);
        leftKnown = randInt(4, 14);
      }

      const sig = `BAL:${difficulty}:${mysteryCount}:${mysteryValue}:${leftKnown}`;
      if (!globalDeduplicator.hasSeen(sig)) {
        globalDeduplicator.record(sig);
        break;
      }
    }

    const total = mysteryCount * mysteryValue + leftKnown;
    const r1 = difficulty === 'medium' ? Math.floor(total * 0.6) : Math.floor(total / 2);
    const r2 = total - r1;
    rightWeights = [r1, r2];

    // Include mysteryCount * mysteryValue as a cognitive distractor in hard mode (forgetting to divide by 2)
    const rawOpts = generateSmartOptions(mysteryValue, 5, { sortAscending: true });
    if (mysteryCount === 2 && !rawOpts.includes(mysteryValue * 2)) {
      rawOpts[rawOpts.length - 1] = mysteryValue * 2;
    }
    const uniqueOpts = Array.from(new Set([...rawOpts, mysteryValue])).sort((a, b) => a - b);

    return {
      id: 200 + seedCounter,
      worldId: 2,
      worldName: 'مختبر الميزان الذكي',
      title: `ميزان الأوزان (${DIFFICULTY_CONFIGS[difficulty].label})`,
      subtitle: mysteryCount === 2 ? 'صندوقان مجهولان متعادلان' : 'صندوق مجهول واحد',
      skillTag: 'توازن المعادلات',
      difficulty,
      mode: 'BALANCE_LAB',
      storyContext: `الميزان يبحث عن التعادل! الكفة اليسرى بها ${
        mysteryCount > 1
          ? `صندوقان متماثلان (؟) ووزن معلوم (${leftKnown})`
          : `صندوق مجهول (؟) ووزن معلوم (${leftKnown})`
      }، والكفة اليمنى مجموعها ${total}. ما وزن الصندوق الواحد؟`,
      hints: [
        `مجموع الكفة اليمنى هو: ${rightWeights.join(' + ')} = ${total}.`,
        `اطرح الوزن المعلوم (${leftKnown}) من ${total}: يتبقى ${total - leftKnown} ${
          mysteryCount === 2 ? 'للصندوقين معاً' : 'للصندوق'
        }.`,
        mysteryCount === 2
          ? `اقسم ${total - leftKnown} بالتساوي على صندوقين (÷ 2): الناتج هو ${mysteryValue}.`
          : `إذن وزن الصندوق المجهول هو ${mysteryValue}.`,
      ],
      balanceData: {
        prompt: `الميزان متعادل عندما تتساوى الكفتان! كم يزن الصندوق المجهول (؟) الواحد؟`,
        leftFixedWeights: [leftKnown],
        leftMysteryCount: mysteryCount,
        mysteryBoxValue: mysteryValue,
        rightFixedWeights: rightWeights,
        interactiveMode: 'SOLVE_MYSTERY_BOX',
        availableWeights: uniqueOpts,
        targetAnswer: mysteryValue,
      },
    };
  }

  if (mode === 'MAGIC_GRID') {
    let base = difficulty === 'easy' ? randInt(1, 3) : difficulty === 'medium' ? randInt(4, 7) : randInt(8, 12);
    const offsetA = randInt(1, 2);
    const offsetB = randInt(2, 4);

    const sol = [
      [base + offsetA, base + offsetB, base],
      [base, base + offsetA, base + offsetB],
      [base + offsetB, base, base + offsetA],
    ];
    sol[0][0] += randInt(0, 2);
    sol[1][1] += randInt(0, 2);

    const targetRowSums = sol.map((r) => r[0] + r[1] + r[2]);
    const targetColSums = [0, 1, 2].map((c) => sol[0][c] + sol[1][c] + sol[2][c]);

    const init: (number | null)[][] = [
      [sol[0][0], null, sol[0][2]],
      [null, sol[1][1], sol[1][2]],
      [sol[2][0], null, sol[2][2]],
    ];
    const availableTiles = [sol[0][1], sol[1][0], sol[2][1]].sort((a, b) => a - b);

    return {
      id: 300 + seedCounter,
      worldId: 3,
      worldName: 'قلعة الشبكات السحرية',
      title: `الشبكة الموزونة (${DIFFICULTY_CONFIGS[difficulty].label})`,
      subtitle: `مجاميع مستهدفة حتى ${Math.max(...targetRowSums, ...targetColSums)}`,
      skillTag: 'الشبكات الحسابية',
      difficulty,
      mode: 'MAGIC_GRID',
      storyContext: `ضع الأعداد المناسبة في الخانات الفارغة لتتطابق مجاميع كل صف وكل عمود مع الأهداف المطلوبة.`,
      hints: [
        `انظر إلى الصف الأول: لدينا ${sol[0][0]} و ${sol[0][2]}، والمجموع المطلوب هو ${targetRowSums[0]}.`,
        `الخانة المفقودة في الصف الأول = ${targetRowSums[0]} - (${sol[0][0]} + ${sol[0][2]}) = ${sol[0][1]}.`,
        `الخانة المفقودة في الصف الثاني هي ${sol[1][0]}، وفي الصف الثالث هي ${sol[2][1]}.`,
      ],
      gridData: {
        prompt: 'أكمل الخانات الفارغة لتصل إلى المجاميع المستهدفة لكل صف وعمود:',
        gridSize: 3,
        targetRowSums,
        targetColSums,
        initialGrid: init,
        solutionGrid: sol,
        availableTiles,
      },
    };
  }

  // mode === 'CODE_BREAKER' (System of Algebraic Equations)
  let appleVal = 4;
  let starVal = 3;
  let gemVal = 2;
  let crownVal = 6;
  let moonVal = 5;
  let clues: CodeBreakerClue[] = [];
  let finalAns = 9;
  let finalQuestion: CodeBreakerData['finalQuestion'] = {
    s1: 'apple',
    op1: '+',
    s2: 'star',
    op2: '+',
    s3: 'gem',
  };

  for (let attempt = 0; attempt < 25; attempt++) {
    if (difficulty === 'easy') {
      appleVal = randInt(3, 7);
      starVal = randInt(2, 6);
      gemVal = randInt(1, 5);
      clues = [
        {
          symbols: ['apple', 'apple'],
          operator: '+',
          result: appleVal + appleVal,
          explanation: `${appleVal} + ${appleVal} = ${appleVal * 2}، إذن التفاحة = ${appleVal}`,
        },
        {
          symbols: ['apple', 'star'],
          operator: '+',
          result: appleVal + starVal,
          explanation: `${appleVal} + ${starVal} = ${appleVal + starVal}، إذن النجمة = ${starVal}`,
        },
        {
          symbols: ['star', 'gem'],
          operator: '+',
          result: starVal + gemVal,
          explanation: `${starVal} + ${gemVal} = ${starVal + gemVal}، إذن الجوهرة = ${gemVal}`,
        },
      ];
      finalQuestion = { s1: 'apple', op1: '+', s2: 'star', op2: '+', s3: 'gem' };
      finalAns = appleVal + starVal + gemVal;
    } else if (difficulty === 'medium') {
      // Strictly enforce appleVal > starVal so appleVal - starVal > 0 and finalAns > 0!
      starVal = randInt(2, 6);
      appleVal = starVal + randInt(2, 6);
      gemVal = randInt(2, 7);
      clues = [
        {
          symbols: ['apple', 'apple'],
          operator: '+',
          result: appleVal + appleVal,
          explanation: `${appleVal} + ${appleVal} = ${appleVal * 2}، إذن التفاحة = ${appleVal}`,
        },
        {
          symbols: ['apple', 'star'],
          operator: '-',
          result: appleVal - starVal,
          explanation: `${appleVal} - ${starVal} = ${appleVal - starVal}، إذن النجمة = ${starVal}`,
        },
        {
          symbols: ['star', 'gem'],
          operator: '+',
          result: starVal + gemVal,
          explanation: `${starVal} + ${gemVal} = ${starVal + gemVal}، إذن الجوهرة = ${gemVal}`,
        },
      ];
      finalQuestion = { s1: 'apple', op1: '+', s2: 'gem', op2: '-', s3: 'star' };
      finalAns = appleVal + gemVal - starVal;
    } else {
      // Hard: Includes multiplication & order of operations: crown + gem × star
      starVal = randInt(2, 5);
      crownVal = randInt(4, 9);
      gemVal = randInt(2, 5);
      clues = [
        {
          symbols: ['star', 'star'],
          operator: '×',
          result: starVal * starVal,
          explanation: `${starVal} × ${starVal} = ${starVal * starVal}، إذن النجمة = ${starVal}`,
        },
        {
          symbols: ['crown', 'star'],
          operator: '+',
          result: crownVal + starVal,
          explanation: `${crownVal} + ${starVal} = ${crownVal + starVal}، إذن التاج = ${crownVal}`,
        },
        {
          symbols: ['gem', 'star'],
          operator: '×',
          result: gemVal * starVal,
          explanation: `${gemVal} × ${starVal} = ${gemVal * starVal}، إذن الجوهرة = ${gemVal}`,
        },
      ];
      // Mathematical alignment fixed: op2 is '×' to match crownVal + (gemVal * starVal)
      finalQuestion = { s1: 'crown', op1: '+', s2: 'gem', op2: '×', s3: 'star' };
      finalAns = crownVal + gemVal * starVal;
    }

    const sig = `CODE:${difficulty}:${appleVal}:${starVal}:${gemVal}:${crownVal}`;
    if (!globalDeduplicator.hasSeen(sig)) {
      globalDeduplicator.record(sig);
      break;
    }
  }

  const baseOpts = generateSmartOptions(finalAns, 5);
  // In hard mode, include the left-to-right misconception distractor (crown + gem) * star
  if (difficulty === 'hard') {
    const orderTrap = (crownVal + gemVal) * starVal;
    if (orderTrap !== finalAns && !baseOpts.includes(orderTrap)) {
      baseOpts[0] = orderTrap;
    }
  }
  const opts = shuffleArray(Array.from(new Set([...baseOpts, finalAns]))).slice(0, 5);
  if (!opts.includes(finalAns)) {
    opts[0] = finalAns;
  }

  return {
    id: 400 + seedCounter,
    worldId: 4,
    worldName: 'خزينة الشفرات والكنوز',
    title: `شفرة الرموز (${DIFFICULTY_CONFIGS[difficulty].label})`,
    subtitle: `استنتاج جبري من ${clues.length} دلائل`,
    skillTag: 'الاستنتاج المنطقي',
    difficulty,
    mode: 'CODE_BREAKER',
    storyContext:
      difficulty === 'hard'
        ? 'كل رمز يمثل عدداً سرياً. استنتج قيمة الرموز وانتبه لأولوية عملية الضرب قبل الجمع في الشفرة النهائية!'
        : 'كل رمز يمثل عدداً سرياً. استنتج قيمة كل رمز خطوة بخطوة لفتح قفل الخزينة النهائي!',
    hints: [
      `ابدأ بالدليل الأول: ${clues[0].explanation}.`,
      `استخدم القيمة الأولى في الدليل الثاني والثالث: ${clues[1].explanation}، و${clues[2].explanation}.`,
      difficulty === 'hard'
        ? `تذكر أولوية الضرب: احسب (${gemVal} × ${starVal} = ${gemVal * starVal}) أولاً، ثم اجمع التاج (${crownVal}) لتحصل على ${finalAns}.`
        : `عوض القيم في المعادلة النهائية لتحصل على الحل الصحيح: ${finalAns}.`,
    ],
    codeData: {
      prompt:
        difficulty === 'hard'
          ? 'اكتشف قيمة كل رمز ثم احسب الشفرة النهائية (تذكر: الضرب يسبق الجمع!):'
          : 'اكتشف قيمة كل رمز ثم احسب نتيجة المعادلة النهائية:',
      symbolValues: {
        apple: appleVal,
        star: starVal,
        gem: gemVal,
        crown: crownVal,
        moon: moonVal,
      },
      activeSymbols: difficulty === 'hard' ? ['star', 'crown', 'gem'] : ['apple', 'star', 'gem'],
      clues,
      finalQuestion,
      correctAnswer: finalAns,
      options: shuffleArray(opts),
    },
  };
}

// Generate Quick Math Blitz problems for Speed Math Mode based on difficulty (Deduplicated!)
export function generateSpeedProblems(difficulty: DifficultyTier, count: number = 10): SpeedMathProblem[] {
  const rangeTier = difficulty === 'easy' ? 'basic' : difficulty === 'medium' ? 'medium' : 'pro';
  const batch = generateUniqueArithmeticBatch({
    count,
    operation: 'mix',
    rangeTier,
  });

  // Filter operations strictly to those allowed by difficulty tier if needed
  return batch.map((item, idx) => {
    if (difficulty === 'easy' && (item.op === '×' || item.op === '÷')) {
      const op = idx % 2 === 0 ? '+' : '-';
      const n1 = op === '+' ? randInt(2, 9) : randInt(6, 15);
      const n2 = op === '+' ? randInt(1, 8) : randInt(1, n1 - 1);
      const ans = op === '+' ? n1 + n2 : n1 - n2;
      return {
        num1: n1,
        operator: op,
        num2: n2,
        answer: ans,
        options: generateSmartOptions(ans, 4, { num1: n1, num2: n2, op }),
      };
    }
    if (difficulty === 'medium' && item.op === '÷') {
      const n1 = randInt(2, 6);
      const n2 = randInt(2, 6);
      const ans = n1 * n2;
      return {
        num1: n1,
        operator: '×',
        num2: n2,
        answer: ans,
        options: generateSmartOptions(ans, 4, { num1: n1, num2: n2, op: '×' }),
      };
    }
    return {
      num1: item.num1,
      operator: item.op,
      num2: item.num2,
      answer: item.answer,
      options: item.options,
    };
  });
}

// 12 Standard Adventure Levels with progressive difficulty & verified hints
export const ADVENTURE_LEVELS: LevelConfig[] = [
  // WORLD 1
  {
    id: 1,
    worldId: 1,
    worldName: 'وادي الجسور والأنماط',
    title: 'جسر التفاحات الخمس',
    subtitle: 'الجمع البصري المباشر (1 - 15)',
    skillTag: 'الجمع البصري',
    difficulty: 'easy',
    mode: 'BRIDGE_PUZZLE',
    storyContext: 'يريد المستكشف عبور النهر عبر جسر التفاح. اجمع التفاحات في الكفتين لوضع الحجر الصحيح!',
    hints: [
      'لدينا 5 تفاحات في المجموعة الأولى و 4 تفاحات في الثانية.',
      'اجمع المجموعتين معاً: 5 + 4 = 9.',
      'اختر العدد 9 ليعبر المستكشف بأمان.',
    ],
    bridgeData: {
      subType: 'visual_groups',
      prompt: 'ما مجموع التفاحات لإكمال حجر الجسر؟',
      equation: { left: 5, operator: '+', right: 4, result: null },
      visualIcon: 'apple',
      correctAnswer: 9,
      options: [9, 7, 10, 8, 11],
    },
  },
  {
    id: 2,
    worldId: 1,
    worldName: 'وادي الجسور والأنماط',
    title: 'حجارة القفز الثنائية',
    subtitle: 'متتالية القفز بمقدار (+2)',
    skillTag: 'الأنماط العددية',
    difficulty: 'easy',
    mode: 'BRIDGE_PUZZLE',
    storyContext: 'كل حجر في الجسر يزيد بمقدار 2 عن الحجر الذي قبله. اكتشف الحجر المفقود!',
    hints: [
      'الحجارة هي: 2 ثم 4 ثم 6.',
      'في كل خطوة نقفز بمقدار +2.',
      'أضف 2 إلى 6 لتصل إلى 8.',
    ],
    bridgeData: {
      subType: 'sequence',
      prompt: 'ما هو العدد المفقود في سلسلة الجسر؟',
      sequence: [2, 4, 6, null, 10],
      stepRule: '+2',
      visualIcon: 'star',
      correctAnswer: 8,
      options: [7, 10, 8, 9, 12],
    },
  },
  {
    id: 3,
    worldId: 1,
    worldName: 'وادي الجسور والأنماط',
    title: 'بوابة الأعداد المتوسطة',
    subtitle: 'الجمع والطرح بالعشرات (10 - 50)',
    skillTag: 'العدد المفقود',
    difficulty: 'medium',
    mode: 'BRIDGE_PUZZLE',
    storyContext: 'تحتاج البوابة إلى المجموع 35 ولدينا الآن 18. ما هو العدد الإضافي المطلوب؟',
    hints: [
      'المعادلة هي: 18 + [؟] = 35.',
      'استخدم العملية العكسية (الطرح): 35 - 18.',
      'النتيجة الصحيحة هي 17.',
    ],
    bridgeData: {
      subType: 'missing_number',
      prompt: 'ما هو العدد الذي إذا أضفناه إلى 18 أصبح المجموع 35؟',
      equation: { left: 18, operator: '+', right: null, result: 35 },
      visualIcon: 'gem',
      correctAnswer: 17,
      options: [16, 19, 15, 17, 27],
    },
  },

  // WORLD 2
  {
    id: 4,
    worldId: 2,
    worldName: 'مختبر الميزان الذكي',
    title: 'كفتا الميزان الصغير',
    subtitle: 'موازنة أوزان بسيطة حتى 15',
    skillTag: 'موازنة الأوزان',
    difficulty: 'easy',
    mode: 'BALANCE_LAB',
    storyContext: 'الكفة اليمنى تحمل وزناً مقداره 8، واليسرى تحمل 5 مع صندوق مجهول. اختر وزن الصندوق ليتعادل الميزان!',
    hints: [
      'لدينا وزن 5 في الكفة اليسرى.',
      'الكفة اليمنى تزن 8.',
      'نحتاج وزناً إضافياً مقداره: 8 - 5 = 3.',
    ],
    balanceData: {
      prompt: 'كم يزن الصندوق المجهول (؟) ليصبح الميزان في حالة تعادل؟',
      leftFixedWeights: [5],
      leftMysteryCount: 1,
      mysteryBoxValue: 3,
      rightFixedWeights: [8],
      interactiveMode: 'SOLVE_MYSTERY_BOX',
      availableWeights: [2, 3, 4, 5, 6],
      targetAnswer: 3,
    },
  },
  {
    id: 5,
    worldId: 2,
    worldName: 'مختبر الميزان الذكي',
    title: 'سر الصندوق الفضي',
    subtitle: 'معادلة بمجهول واحد حتى 50',
    skillTag: 'المعادلات البصرية',
    difficulty: 'medium',
    mode: 'BALANCE_LAB',
    storyContext: 'الصندوق الغامض مع الوزن 12 يعادلان وزنين مقدارهما 20 و 10 (المجموع 30). كم يزن الصندوق؟',
    hints: [
      'مجموع الكفة اليمنى: 20 + 10 = 30.',
      'الكفة اليسرى: الصندوق + 12 = 30.',
      'اطرح: 30 - 12 = 18.',
    ],
    balanceData: {
      prompt: 'احسب وزن الصندوق الغامض (؟) لتحقيق التوازن:',
      leftFixedWeights: [12],
      leftMysteryCount: 1,
      mysteryBoxValue: 18,
      rightFixedWeights: [20, 10],
      interactiveMode: 'SOLVE_MYSTERY_BOX',
      availableWeights: [15, 16, 17, 18, 19, 22],
      targetAnswer: 18,
    },
  },
  {
    id: 6,
    worldId: 2,
    worldName: 'مختبر الميزان الذكي',
    title: 'تحدي الصندوقين التوأمين',
    subtitle: 'معادلة بمجهولين مضاعفين حتى 100',
    skillTag: 'الضرب والمعادلات',
    difficulty: 'hard',
    mode: 'BALANCE_LAB',
    storyContext: 'صندوقان متطابقان تماماً مع وزن 6 يعادلان 46 (20 + 26). كم يزن الصندوق الواحد؟',
    hints: [
      'الكفة اليمنى مجموعها 20 + 26 = 46.',
      'اطرح الوزن 6: 46 - 6 = 40 (وهذا وزن الصندوقين معاً).',
      'اقسم 40 على 2: وزن الصندوق الواحد هو 20.',
    ],
    balanceData: {
      prompt: 'صندوقان متماثلان (؟) مع الوزن 6 يعادلان 46. كم يزن الصندوق الواحد؟',
      leftFixedWeights: [6],
      leftMysteryCount: 2,
      mysteryBoxValue: 20,
      rightFixedWeights: [20, 26],
      interactiveMode: 'SOLVE_MYSTERY_BOX',
      availableWeights: [15, 18, 20, 23, 40],
      targetAnswer: 20,
    },
  },

  // WORLD 3
  {
    id: 7,
    worldId: 3,
    worldName: 'قلعة الشبكات السحرية',
    title: 'لوحة الشبكة البسيطة',
    subtitle: 'إكمال الصفوف والأعمدة بمجاميع صغيرة (9 - 12)',
    skillTag: 'الشبكات الحسابية',
    difficulty: 'easy',
    mode: 'MAGIC_GRID',
    storyContext: 'ضع الأعداد في الخانات الفارغة ليتطابق مجموع كل صف وكل عمود مع الأهداف المطلوبة.',
    hints: [
      'الصف الأول: 4 + [؟] + 2 = 9، إذن الخانة = 3.',
      'الصف الثاني: 1 + 5 + [؟] = 10، إذن الخانة = 4.',
      'الصف الثالث: 3 + [؟] + 2 = 11، إذن الخانة = 6.',
    ],
    gridData: {
      prompt: 'اختر عدداً وضعه في الخانة المناسبة لمطابقة الأهداف:',
      gridSize: 3,
      targetRowSums: [9, 10, 11],
      targetColSums: [8, 14, 8],
      initialGrid: [
        [4, null, 2],
        [1, 5, null],
        [3, null, 2],
      ],
      solutionGrid: [
        [4, 3, 2],
        [1, 5, 4],
        [3, 6, 2],
      ],
      availableTiles: [3, 4, 6],
    },
  },
  {
    id: 8,
    worldId: 3,
    worldName: 'قلعة الشبكات السحرية',
    title: 'المربع السحري الذهبي (15)',
    subtitle: 'مجموع كل صف وكل عمود يساوي 15',
    skillTag: 'المربع السحري',
    difficulty: 'medium',
    mode: 'MAGIC_GRID',
    storyContext: 'المربع السحري التاريخي (لو شو)! كل صف وكل عمود يجب أن يساوي 15 تماماً.',
    hints: [
      'الصف الأول: 8 + 1 + [؟] = 15، إذن نحتاج إلى 6.',
      'العمود الثالث أصبح: 6 + [؟] + 2 = 15، إذن الخانة اليمنى في الصف الثاني = 7.',
      'يتبقى 3 في بداية الصف الثاني، و 9 في وسط الصف الثالث.',
    ],
    gridData: {
      prompt: 'أكمل المربع السحري ليصبح المجموع في كل اتجاه 15:',
      gridSize: 3,
      targetRowSums: [15, 15, 15],
      targetColSums: [15, 15, 15],
      initialGrid: [
        [8, 1, null],
        [null, 5, null],
        [4, null, 2],
      ],
      solutionGrid: [
        [8, 1, 6],
        [3, 5, 7],
        [4, 9, 2],
      ],
      availableTiles: [3, 6, 7, 9],
    },
  },
  {
    id: 9,
    worldId: 3,
    worldName: 'قلعة الشبكات السحرية',
    title: 'شبكة الحصن الكبرى (30)',
    subtitle: 'مجاميع ثلاثية متساوية (30) في كل صف وعمود',
    skillTag: 'الجمع المركب',
    difficulty: 'hard',
    mode: 'MAGIC_GRID',
    storyContext: 'شبكة متقدمة لمستكشفي الرياضيات الأبطال! مجموع كل صف وكل عمود يساوي 30 تماماً.',
    hints: [
      'الصف الأول: 16 + [؟] + 12 = 30، مجموع المعلوم 28، إذن الخانة = 2.',
      'الصف الثاني: [؟] + 10 + 14 = 30، مجموع المعلوم 24، إذن الخانة = 6.',
      'الصف الثالث: 8 + 18 + [؟] = 30، مجموع المعلوم 26، إذن الخانة الأخيرة = 4.',
    ],
    gridData: {
      prompt: 'أكمل الشبكة الكبرى لتحقيق المجموع 30 في كل صف وعمود:',
      gridSize: 3,
      targetRowSums: [30, 30, 30],
      targetColSums: [30, 30, 30],
      initialGrid: [
        [16, null, 12],
        [null, 10, 14],
        [8, 18, null],
      ],
      solutionGrid: [
        [16, 2, 12],
        [6, 10, 14],
        [8, 18, 4],
      ],
      availableTiles: [2, 4, 6],
    },
  },

  // WORLD 4
  {
    id: 10,
    worldId: 4,
    worldName: 'خزينة الشفرات والكنوز',
    title: 'شفرة التفاحة والتاج',
    subtitle: 'استنتاج بالجمع المباشر (سهل)',
    skillTag: 'استنتاج الرموز',
    difficulty: 'easy',
    mode: 'CODE_BREAKER',
    storyContext: 'كل رمز يخفي رقماً سرياً. استنتج قيمة الرموز لفتح قفل الخزينة الأول!',
    hints: [
      'تفاحة + تفاحة = 8، إذن التفاحة = 4.',
      'تفاحة (4) + تاج = 9، إذن التاج = 5. وتاج (5) + جوهرة = 8، إذن الجوهرة = 3.',
      'المطلوب: تفاحة (4) + تاج (5) + جوهرة (3) = 12.',
    ],
    codeData: {
      prompt: 'اكتشف قيمة كل رمز ثم احسب نتيجة الشفرة النهائية:',
      symbolValues: { apple: 4, crown: 5, gem: 3, star: 2, moon: 1 },
      activeSymbols: ['apple', 'crown', 'gem'],
      clues: [
        {
          symbols: ['apple', 'apple'],
          operator: '+',
          result: 8,
          explanation: '4 + 4 = 8، إذن التفاحة = 4',
        },
        {
          symbols: ['apple', 'crown'],
          operator: '+',
          result: 9,
          explanation: '4 + 5 = 9، إذن التاج = 5',
        },
        {
          symbols: ['crown', 'gem'],
          operator: '+',
          result: 8,
          explanation: '5 + 3 = 8، إذن الجوهرة = 3',
        },
      ],
      finalQuestion: {
        s1: 'apple',
        op1: '+',
        s2: 'crown',
        op2: '+',
        s3: 'gem',
      },
      correctAnswer: 12,
      options: [9, 11, 12, 13, 14],
    },
  },
  {
    id: 11,
    worldId: 4,
    worldName: 'خزينة الشفرات والكنوز',
    title: 'شفرة الهلال والجوهرة',
    subtitle: 'استنتاج بالجمع والطرح (متوسط)',
    skillTag: 'المنطق الجبري',
    difficulty: 'medium',
    mode: 'CODE_BREAKER',
    storyContext: 'الشفرة الثانية تجمع بين الجمع والطرح. تتبع قيمة الرموز بالترتيب!',
    hints: [
      'تاج + تاج = 16، إذن التاج = 8.',
      'تاج (8) - هلال = 5، إذن الهلال = 3.',
      'جوهرة + هلال (3) = 10، إذن الجوهرة = 7. الناتج: 8 + 7 - 3 = 12.',
    ],
    codeData: {
      prompt: 'استنتج قيمة التاج والجوهرة والهلال لفك القفل:',
      symbolValues: { crown: 8, moon: 3, gem: 7, apple: 4, star: 5 },
      activeSymbols: ['crown', 'moon', 'gem'],
      clues: [
        {
          symbols: ['crown', 'crown'],
          operator: '+',
          result: 16,
          explanation: '8 + 8 = 16، إذن التاج = 8',
        },
        {
          symbols: ['crown', 'moon'],
          operator: '-',
          result: 5,
          explanation: '8 - 3 = 5، إذن الهلال = 3',
        },
        {
          symbols: ['gem', 'moon'],
          operator: '+',
          result: 10,
          explanation: '7 + 3 = 10، إذن الجوهرة = 7',
        },
      ],
      finalQuestion: {
        s1: 'crown',
        op1: '+',
        s2: 'gem',
        op2: '-',
        s3: 'moon',
      },
      correctAnswer: 12,
      options: [10, 12, 11, 15, 18],
    },
  },
  {
    id: 12,
    worldId: 4,
    worldName: 'خزينة الشفرات والكنوز',
    title: 'شفرة الكنز الملكي الكبرى',
    subtitle: 'استنتاج بجدول الضرب والجمع (صعب)',
    skillTag: 'الضرب والاستنتاج',
    difficulty: 'hard',
    mode: 'CODE_BREAKER',
    storyContext: 'أنت أمام الخزينة الملكية الكبرى! استخدم مهارات الضرب لحل الشفرة الذهبية.',
    hints: [
      'نجمة × نجمة = 9 (العدد الموجب المضروب في نفسه يعطي 9 هو 3)، إذن النجمة = 3.',
      'تاج + نجمة (3) = 10، إذن التاج = 7.',
      'جوهرة × نجمة (3) = 12، إذن الجوهرة = 4. الناتج: 7 + 4 + 3 = 14.',
    ],
    codeData: {
      prompt: 'حل شفرة الكنز الكبرى باستخدام الضرب والجمع:',
      symbolValues: { star: 3, crown: 7, gem: 4, apple: 2, moon: 6 },
      activeSymbols: ['star', 'crown', 'gem'],
      clues: [
        {
          symbols: ['star', 'star'],
          operator: '×',
          result: 9,
          explanation: '3 × 3 = 9، إذن النجمة = 3',
        },
        {
          symbols: ['crown', 'star'],
          operator: '+',
          result: 10,
          explanation: '7 + 3 = 10، إذن التاج = 7',
        },
        {
          symbols: ['gem', 'star'],
          operator: '×',
          result: 12,
          explanation: '4 × 3 = 12، إذن الجوهرة = 4',
        },
      ],
      finalQuestion: {
        s1: 'crown',
        op1: '+',
        s2: 'gem',
        op2: '+',
        s3: 'star',
      },
      correctAnswer: 14,
      options: [13, 16, 14, 12, 15],
    },
  },
];
