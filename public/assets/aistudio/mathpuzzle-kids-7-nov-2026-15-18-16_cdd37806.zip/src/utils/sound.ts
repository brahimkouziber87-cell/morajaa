// Web Audio API Synthesizer for tactile, child-friendly sound effects
// Zero external dependencies; safe across all modern browsers

import { useState, useCallback, useEffect } from 'react';

class SoundEffects {
  private ctx: AudioContext | null = null;
  public enabled: boolean = true;

  private getContext(): AudioContext | null {
    if (!this.enabled || typeof window === 'undefined') return null;
    if (!this.ctx) {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
    return this.ctx;
  }

  public playClick() {
    const ctx = this.getContext();
    if (!ctx) return;
    try {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(520, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(680, ctx.currentTime + 0.05);

      gain.gain.setValueAtTime(0.12, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.06);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.065);
    } catch {
      // Ignore audio block
    }
  }

  public playToggle(active: boolean = true) {
    const ctx = this.getContext();
    if (!ctx) return;
    try {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      const baseFreq = active ? 587.33 : 440;
      osc.frequency.setValueAtTime(baseFreq, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(baseFreq * 1.15, ctx.currentTime + 0.07);

      gain.gain.setValueAtTime(0.14, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.08);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.085);
    } catch {}
  }

  public playHint() {
    const ctx = this.getContext();
    if (!ctx) return;
    try {
      const notes = [659.25, 880];
      notes.forEach((freq, idx) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        const startTime = ctx.currentTime + idx * 0.09;
        osc.frequency.setValueAtTime(freq, startTime);

        gain.gain.setValueAtTime(0.12, startTime);
        gain.gain.exponentialRampToValueAtTime(0.001, startTime + 0.22);

        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(startTime);
        osc.stop(startTime + 0.24);
      });
    } catch {}
  }

  public playRetry() {
    const ctx = this.getContext();
    if (!ctx) return;
    try {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(280, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(210, ctx.currentTime + 0.18);

      gain.gain.setValueAtTime(0.15, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.2);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.21);
    } catch {}
  }

  // 1. Success chime on puzzle solved
  public playSuccess() {
    const ctx = this.getContext();
    if (!ctx) return;
    try {
      const notes = [523.25, 659.25, 783.99, 1046.5]; // C5, E5, G5, C6
      notes.forEach((freq, idx) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'triangle';
        const startTime = ctx.currentTime + idx * 0.085;
        osc.frequency.setValueAtTime(freq, startTime);

        gain.gain.setValueAtTime(0.18, startTime);
        gain.gain.exponentialRampToValueAtTime(0.001, startTime + 0.35);

        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(startTime);
        osc.stop(startTime + 0.36);
      });
    } catch {}
  }

  // 2. Individual star award sound effect (plays for star 1, 2, 3 progressively)
  public playStarReveal(starIndex: number = 1) {
    const ctx = this.getContext();
    if (!ctx) return;
    try {
      // Different chords and sparkles per star
      let pitches = [523.25, 659.25, 783.99]; // Star 1: C5, E5, G5
      if (starIndex === 2) {
        pitches = [659.25, 830.61, 987.77, 1318.5]; // Star 2: E5, G#5, B5, E6
      } else if (starIndex >= 3) {
        pitches = [783.99, 1046.5, 1318.5, 1567.98, 2093.0]; // Star 3: G5, C6, E6, G6, C7 (Super twinkle)
      }

      pitches.forEach((freq, i) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        const startTime = ctx.currentTime + i * 0.06;
        osc.frequency.setValueAtTime(freq, startTime);

        gain.gain.setValueAtTime(0.16, startTime);
        gain.gain.exponentialRampToValueAtTime(0.001, startTime + 0.38);

        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(startTime);
        osc.stop(startTime + 0.4);
      });
    } catch {}
  }

  // 3. New Level / Milestone Unlocked Fanfare
  public playLevelUnlocked() {
    const ctx = this.getContext();
    if (!ctx) return;
    try {
      const melody = [
        { freq: 440, delay: 0, dur: 0.12 }, // A4
        { freq: 554.37, delay: 0.1, dur: 0.12 }, // C#5
        { freq: 659.25, delay: 0.2, dur: 0.12 }, // E5
        { freq: 880, delay: 0.32, dur: 0.35 }, // A5
        { freq: 783.99, delay: 0.48, dur: 0.12 }, // G5
        { freq: 880, delay: 0.6, dur: 0.12 }, // A5
        { freq: 1108.73, delay: 0.72, dur: 0.55 }, // C#6
      ];

      melody.forEach((note) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'triangle';
        const startTime = ctx.currentTime + note.delay;
        osc.frequency.setValueAtTime(note.freq, startTime);

        gain.gain.setValueAtTime(0.2, startTime);
        gain.gain.exponentialRampToValueAtTime(0.001, startTime + note.dur);

        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(startTime);
        osc.stop(startTime + note.dur + 0.02);
      });
    } catch {}
  }

  // 4. Streak combo chime with escalating pitch
  public playStreakCombo(streak: number = 1) {
    const ctx = this.getContext();
    if (!ctx) return;
    try {
      const baseFreq = Math.min(1000, 440 + (streak - 1) * 60);
      const notes = [baseFreq, baseFreq * 1.25, baseFreq * 1.5];

      notes.forEach((freq, i) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'triangle';
        const startTime = ctx.currentTime + i * 0.055;
        osc.frequency.setValueAtTime(freq, startTime);

        gain.gain.setValueAtTime(0.15, startTime);
        gain.gain.exponentialRampToValueAtTime(0.001, startTime + 0.22);

        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(startTime);
        osc.stop(startTime + 0.24);
      });
    } catch {}
  }

  // 5. Crisp correct pop for practice & speed modes
  public playCorrectPop() {
    const ctx = this.getContext();
    if (!ctx) return;
    try {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(659.25, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(880, ctx.currentTime + 0.08);

      gain.gain.setValueAtTime(0.16, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.15);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.16);
    } catch {}
  }

  public playFanfare() {
    this.playLevelUnlocked();
  }
}

export const sound = new SoundEffects();

/**
 * React Hook for seamless audio integration in components
 */
export function useGameAudio() {
  const [soundEnabled, setSoundEnabled] = useState<boolean>(sound.enabled);

  useEffect(() => {
    sound.enabled = soundEnabled;
  }, [soundEnabled]);

  const toggleSound = useCallback(() => {
    setSoundEnabled((prev) => {
      const next = !prev;
      sound.enabled = next;
      if (next) sound.playClick();
      return next;
    });
  }, []);

  const playClick = useCallback(() => sound.playClick(), []);
  const playToggle = useCallback((active?: boolean) => sound.playToggle(active), []);
  const playHint = useCallback(() => sound.playHint(), []);
  const playRetry = useCallback(() => sound.playRetry(), []);
  const playSuccess = useCallback(() => sound.playSuccess(), []);
  const playStarReveal = useCallback((starIndex?: number) => sound.playStarReveal(starIndex), []);
  const playLevelUnlocked = useCallback(() => sound.playLevelUnlocked(), []);
  const playUnlock = useCallback(() => sound.playLevelUnlocked(), []);
  const playFanfare = useCallback(() => sound.playFanfare(), []);
  const playStreakCombo = useCallback((streak?: number) => sound.playStreakCombo(streak), []);
  const playCorrectPop = useCallback(() => sound.playCorrectPop(), []);

  return {
    soundEnabled,
    toggleSound,
    playClick,
    playToggle,
    playHint,
    playRetry,
    playSuccess,
    playStarReveal,
    playLevelUnlocked,
    playUnlock,
    playFanfare,
    playStreakCombo,
    playCorrectPop,
  };
}

const EASTERN_TO_MOROCCAN: Record<string, string> = {
  '٠': '0', '١': '1', '٢': '2', '٣': '3', '٤': '4',
  '٥': '5', '٦': '6', '٧': '7', '٨': '8', '٩': '9',
};

/**
 * تنسيق الأرقام وفق النظام المعتمد رسمياً في المملكة المغربية والمنهاج الدراسي المغربي
 * (الأرقام العربية المغاربية الأصلية: 0، 1، 2، 3، 4، 5، 6، 7، 8، 9)
 */
export function formatNum(val: number | string, _useEastern: boolean = false): string {
  const str = String(val);
  // تحويل أي أرقام مشرقية واردة إلى الأرقام العربية المعتمدة في المغرب
  return str.replace(/[٠-٩]/g, (d) => EASTERN_TO_MOROCCAN[d] || d);
}

