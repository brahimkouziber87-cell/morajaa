/**
 * Pedagogical Coach & Error Pattern Detector for "بومة الحكمة الذكية"
 * Analyzes recurring mistake patterns and provides targeted pedagogical advice in Arabic.
 */

import { OwlMood } from '../components/GameIllustrations';

export type ErrorPatternType =
  | 'OFF_BY_ONE'
  | 'OFF_BY_TWO'
  | 'INVERTED_OPERATION'
  | 'TEN_CARRY_BORROW'
  | 'MULTIPLICATION_ADDITION_CONFUSION'
  | 'ADJACENT_TABLE_STEP'
  | 'ORDER_OF_OPERATIONS'
  | 'ALGEBRAIC_HALVING_FORGOTTEN'
  | 'SEQUENCE_STEP_ERROR'
  | 'RANDOM_OUTLIER';

export interface MistakeRecord {
  guessed: number;
  expected: number;
  operator?: string;
  context?: string;
  num1?: number;
  num2?: number;
  timestamp: number;
}

export interface CoachResponse {
  advice: string;
  detectedPattern: ErrorPatternType | null;
  patternTitle: string | null;
  mascotMood: OwlMood;
}

export const ERROR_PATTERN_LABELS: Record<
  ErrorPatternType,
  { title: string; remediation: string }
> = {
  OFF_BY_ONE: {
    title: 'فارق خطوة واحدة (±1)',
    remediation: 'التمهل عند العد النهائي والتحقق من الرقم الأخير على المعداد.',
  },
  OFF_BY_TWO: {
    title: 'فارق خطوتين (±2)',
    remediation: 'التحقق من القفز الزوجي أو تجزئة العدد قبل إتمام العملية.',
  },
  TEN_CARRY_BORROW: {
    title: 'الاحتفاظ والاستلاف (العشرات)',
    remediation: 'الانتباه عند تجاوز الآحاد للعدد 9 ونقل العشرة لمنزلة العشرات.',
  },
  INVERTED_OPERATION: {
    title: 'عكس العملية الحسابية',
    remediation: 'قراءة إشارة العملية (+ أو −) بعناية قبل البدء بالحساب الذهني.',
  },
  MULTIPLICATION_ADDITION_CONFUSION: {
    title: 'الخلط بين الضرب والجمع',
    remediation: 'تذكر أن (أ × ب) تعني تكرار جمع العدد (أ) بمقدار (ب) من المرات.',
  },
  ADJACENT_TABLE_STEP: {
    title: 'خطوة مجاورة في جدول الضرب',
    remediation: 'مراجعة المضاعف السابق أو اللاحق في جدول الضرب للتحقق من الدقة.',
  },
  ORDER_OF_OPERATIONS: {
    title: 'أولوية العمليات الحسابية',
    remediation: 'في العبارات المركبة، عملية الضرب (×) تسبق دائماً عمليتي الجمع (+) والطرح (−).',
  },
  ALGEBRAIC_HALVING_FORGOTTEN: {
    title: 'توزيع الوزن على عدة صناديق',
    remediation: 'عند وجود صندوقين متماثلين (2 × ؟)، يجب قسمة الوزن المتبقي على 2.',
  },
  SEQUENCE_STEP_ERROR: {
    title: 'مقدار القفزة في المتتالية',
    remediation: 'حساب الفرق أو النسبة بين حدين متتاليين معلومين قبل استنتاج الحد المفقود.',
  },
  RANDOM_OUTLIER: {
    title: 'تقدير أولي غير مكتمل',
    remediation: 'استخدام التمثيل البصري والمعداد المساعد لتفكيك المسألة إلى أجزاء أبسط.',
  },
};

class PedagogicalCoachService {
  private recentMistakes: MistakeRecord[] = [];
  private consecutiveSolves: number = 0;
  private patternHistory: Record<ErrorPatternType, number> = {
    OFF_BY_ONE: 0,
    OFF_BY_TWO: 0,
    INVERTED_OPERATION: 0,
    TEN_CARRY_BORROW: 0,
    MULTIPLICATION_ADDITION_CONFUSION: 0,
    ADJACENT_TABLE_STEP: 0,
    ORDER_OF_OPERATIONS: 0,
    ALGEBRAIC_HALVING_FORGOTTEN: 0,
    SEQUENCE_STEP_ERROR: 0,
    RANDOM_OUTLIER: 0,
  };

  public logSolve(stars: number = 3): { mood: OwlMood; cheeringMessage: string } {
    this.consecutiveSolves += 1;
    this.recentMistakes = []; // reset consecutive error chain

    if (stars === 3 && this.consecutiveSolves >= 3) {
      return {
        mood: 'super_excited',
        cheeringMessage: '🌟 يا لروعتك يا بطل! ثلاث إجابات متتالية بدقة مذهلة! أنت فخر الأرقام! 🎉',
      };
    }

    if (stars === 3) {
      return {
        mood: 'celebrating',
        cheeringMessage: '🎉 أحسنت صنعاً! إجابة عبقرية ومتقنة في الصميم! النجوم تلمع لك! ✨',
      };
    }

    return {
      mood: 'proud',
      cheeringMessage: 'رائع جداً! بالصبر والمحاولة وصلت للحل الصحيح! أنت تتقدم بسرعة. 🦉👏',
    };
  }

  public getPatternStats(): { type: ErrorPatternType; count: number; title: string; remediation: string }[] {
    return (Object.keys(this.patternHistory) as ErrorPatternType[])
      .map((type) => ({
        type,
        count: this.patternHistory[type],
        title: ERROR_PATTERN_LABELS[type].title,
        remediation: ERROR_PATTERN_LABELS[type].remediation,
      }))
      .filter((item) => item.count > 0)
      .sort((a, b) => b.count - a.count);
  }

  private recordPattern(pattern: ErrorPatternType) {
    this.patternHistory[pattern] = (this.patternHistory[pattern] || 0) + 1;
  }

  public diagnoseMistake(
    guessed: number,
    expected: number,
    operator: string = '+',
    context?: string,
    num1?: number,
    num2?: number
  ): CoachResponse {
    this.consecutiveSolves = 0;
    const diff = Math.abs(guessed - expected);

    const record: MistakeRecord = {
      guessed,
      expected,
      operator,
      context,
      num1,
      num2,
      timestamp: Date.now(),
    };
    this.recentMistakes.push(record);
    if (this.recentMistakes.length > 8) {
      this.recentMistakes.shift();
    }

    // 1. Check Order of Operations error in CodeBreaker or multi-step expressions
    if (context === 'order_of_operations' || (context === 'code_breaker' && operator === '×')) {
      this.recordPattern('ORDER_OF_OPERATIONS');
      return {
        detectedPattern: 'ORDER_OF_OPERATIONS',
        patternTitle: 'قاعدة ذهبية: الضرب يسبق الجمع!',
        advice:
          'انتبه لأولوية العمليات الحسابية يا بطل! عندما تجد جمعاً وضرباً في نفس السطر، احسب عملية الضرب (×) أولاً ثم اجمع الناتج.',
        mascotMood: 'thinking',
      };
    }

    // 2. Check Algebraic Halving Forgotten in Balance Lab (2 * [?] = 2 * expected, student guessed 2 * expected)
    if (context === 'balance' && guessed === expected * 2) {
      this.recordPattern('ALGEBRAIC_HALVING_FORGOTTEN');
      return {
        detectedPattern: 'ALGEBRAIC_HALVING_FORGOTTEN',
        patternTitle: 'انتبه: لديك صندوقان متطابقان!',
        advice: `العدد (${guessed}) هو وزن الصندوقين معاً! اقسم ${guessed} على 2 لمعرفة وزن الصندوق الواحد فقط.`,
        mascotMood: 'thinking',
      };
    }

    // 3. Check Multiplication vs Addition confusion (student added num1 + num2 instead of num1 * num2)
    if (operator === '×' && num1 !== undefined && num2 !== undefined && guessed === num1 + num2) {
      this.recordPattern('MULTIPLICATION_ADDITION_CONFUSION');
      return {
        detectedPattern: 'MULTIPLICATION_ADDITION_CONFUSION',
        patternTitle: 'تنبيه: علامة ضرب (×) وليست جمعاً (+)',
        advice: `لقد قمت بجمع ${num1} + ${num2} = ${guessed}! تذكر أن ${num1} × ${num2} تعني تكرار الـ ${num1} بمقدار ${num2} مرات.`,
        mascotMood: 'thinking',
      };
    }

    // 4. Check Adjacent Multiplication Table Step (e.g. guessed num1 * (num2 +- 1))
    if (
      operator === '×' &&
      num1 !== undefined &&
      num2 !== undefined &&
      (diff === num1 || diff === num2)
    ) {
      this.recordPattern('ADJACENT_TABLE_STEP');
      return {
        detectedPattern: 'ADJACENT_TABLE_STEP',
        patternTitle: 'قريب جداً في جدول الضرب!',
        advice:
          guessed > expected
            ? `أنت في جدول الضرب الصحيح، لكنك زدت تكراراً واحداً! اطرح (${diff}) من إجابتك.`
            : `أنت في جدول الضرب الصحيح، لكن ينقصك تكرار واحد فقط! أضف (${diff}) إلى إجابتك.`,
        mascotMood: 'encouraging',
      };
    }

    // 5. Off-by-one error (تسرع في العد أو الرقم التالي/السابق)
    const offByOneCount = this.recentMistakes.filter((m) => Math.abs(m.guessed - m.expected) === 1).length;
    if (diff === 1) {
      this.recordPattern('OFF_BY_ONE');
      if (offByOneCount >= 2) {
        return {
          detectedPattern: 'OFF_BY_ONE',
          patternTitle: 'تنبيه ذكي: تكرار فارق (1)',
          advice:
            'لاحظت يا بطل أنك قريب جداً بفارق 1 فقط في أكثر من مسألة! هذا يعني أن فكرتك صحيحة تماماً لكن التسرع يخطف الإجابة. عدّ بتمهل على أصابعك أو استخدم كرات المعداد للتأكد.',
          mascotMood: 'thinking',
        };
      }
      return {
        detectedPattern: 'OFF_BY_ONE',
        patternTitle: 'قريب جداً بفارق (1)',
        advice:
          guessed > expected
            ? `أنت قريب للغاية! إجابتك (${guessed}) أكبر برقم واحد فقط عن الحل. جرب إنقاص 1!`
            : `أنت قريب للغاية! إجابتك (${guessed}) أصغر برقم واحد فقط عن الحل. جرب زيادة 1!`,
        mascotMood: 'encouraging',
      };
    }

    // 6. Off-by-two (خطوة طفيفة)
    if (diff === 2) {
      this.recordPattern('OFF_BY_TWO');
      return {
        detectedPattern: 'OFF_BY_TWO',
        patternTitle: 'فارق خطوتين فقط',
        advice:
          guessed > expected
            ? `اقتربت من الصواب! العدد ${guessed} زائد بمقدار 2. تحقق من العد العكسي خطوتين.`
            : `اقتربت من الصواب! العدد ${guessed} ناقص بمقدار 2. تحقق من زيادة خطوتين إضافيتين.`,
        mascotMood: 'encouraging',
      };
    }

    // 7. Ten carry or borrow error (فرق مضاعفات العشرات)
    if (diff === 10 || diff === 9 || diff === 11) {
      this.recordPattern('TEN_CARRY_BORROW');
      return {
        detectedPattern: 'TEN_CARRY_BORROW',
        patternTitle: 'تنبيه: تكوين العشرات ونقل الخانات',
        advice:
          'انتبه لخانات الآحاد والعشرات يا عبقري! عندما تجمع الآحاد وتتجاوز 9، لا تنسَ نقل العشرة الكاملة إلى منزلة العشرات (إعادة التجميع).',
        mascotMood: 'thinking',
      };
    }

    // 8. Inverted operation (جمع بدل طرح أو العكس)
    if (operator === '-' && guessed > expected && guessed > 0) {
      this.recordPattern('INVERTED_OPERATION');
      return {
        detectedPattern: 'INVERTED_OPERATION',
        patternTitle: 'انتبه لإشارة الطرح (−)',
        advice:
          'لاحظت أنك أضفت قيمة بدلاً من إنقاصها! تذكر: علامة الطرح (−) تعني أننا نأخذ من العدد فينقص ولا يزيد.',
        mascotMood: 'thinking',
      };
    }

    if (operator === '+' && guessed < expected) {
      this.recordPattern('INVERTED_OPERATION');
      return {
        detectedPattern: 'INVERTED_OPERATION',
        patternTitle: 'انتبه لإشارة الجمع (+)',
        advice:
          'في عملية الجمع (+)، نضم المجموعتين معاً لتكبر القيمة الإجمالية. تأكد من ضم كل الأعداد.',
        mascotMood: 'encouraging',
      };
    }

    // 9. Sequence step pattern error
    if (context === 'sequence') {
      this.recordPattern('SEQUENCE_STEP_ERROR');
      return {
        detectedPattern: 'SEQUENCE_STEP_ERROR',
        patternTitle: 'سر متتالية الأرقام',
        advice:
          'لكشف اللغز في المتتاليات، قارن بين حجرين متتاليين لمعرفة سر القفزة الثابتة (جمع، طرح، أو مضاعفة)، ثم طبّقها على الحجر المفقود.',
        mascotMood: 'thinking',
      };
    }

    // Default general pedagogical guidance
    this.recordPattern('RANDOM_OUTLIER');
    return {
      detectedPattern: 'RANDOM_OUTLIER',
      patternTitle: 'خطوة نحو الحل',
      advice:
        'لا تقلق يا بطل! الأخطاء هي خطواتنا الأولى نحو العبقرية. جرب استخدام المعداد البصري المساعد بالأسفل لتمثيل المسألة حسياً.',
      mascotMood: 'encouraging',
    };
  }
}

export const coachService = new PedagogicalCoachService();
