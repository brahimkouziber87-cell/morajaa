/**
 * Unified Mathematical Engine & Non-Repeating Problem Generator
 * محرك الرياضيات الموحد ونظام منع تكرار العمليات الحسابية وتوليد المشتتات الذكية
 */

export type BasicOperator = '+' | '-' | '×' | '÷';

/**
 * Random integer in [min, max] inclusive
 */
export function randInt(min: number, max: number): number {
  const low = Math.ceil(Math.min(min, max));
  const high = Math.floor(Math.max(min, max));
  return Math.floor(Math.random() * (high - low + 1)) + low;
}

/**
 * Unbiased Fisher-Yates shuffle (تبديل فيشر-ييتس العشوائي المتوازن)
 * Guarantees uniform permutation and prevents predictable answer positions.
 */
export function shuffleArray<T>(items: readonly T[]): T[] {
  const copy = [...items];
  for (let i = copy.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    const temp = copy[i];
    copy[i] = copy[j];
    copy[j] = temp;
  }
  return copy;
}

/**
 * Generates a canonical signature for an arithmetic operation to prevent
 * both exact repetition and immediate commutative repetition.
 */
export function getOperationSignature(
  op: BasicOperator,
  n1: number,
  n2: number,
  strictOrder: boolean = false
): string {
  if (!strictOrder && (op === '+' || op === '×')) {
    const a = Math.min(n1, n2);
    const b = Math.max(n1, n2);
    return `${op}:${a}:${b}`;
  }
  return `${op}:${n1}:${n2}`;
}

/**
 * Session-wide deduplication tracker using a sliding window Set.
 * Automatically evicts oldest signatures only when the finite space is exhausted.
 */
export class ProblemDeduplicator {
  private seenSignatures: string[] = [];
  private maxWindowSize: number;

  constructor(maxWindowSize: number = 80) {
    this.maxWindowSize = maxWindowSize;
  }

  public hasSeen(signature: string): boolean {
    return this.seenSignatures.includes(signature);
  }

  public record(signature: string): void {
    if (!this.seenSignatures.includes(signature)) {
      this.seenSignatures.push(signature);
      if (this.seenSignatures.length > this.maxWindowSize) {
        this.seenSignatures.shift();
      }
    }
  }

  public reset(): void {
    this.seenSignatures = [];
  }

  public getUniqueCount(): number {
    return this.seenSignatures.length;
  }
}

export const globalDeduplicator = new ProblemDeduplicator(100);

/**
 * Pedagogically Smart Distractor Generator (توليد الخيارات المشتتة الذكية)
 * Replaces naive [ans-2, ans-1, ans, ans+1, ans+2] where the answer was always in the middle!
 * Instead, includes realistic cognitive slips (off-by-one, +-10 place value slip,
 * inverted operation slip, adjacent factor slip) and shuffles the final array.
 */
export function generateSmartOptions(
  correctAnswer: number,
  count: number = 4,
  context?: {
    num1?: number;
    num2?: number;
    op?: BasicOperator;
    sortAscending?: boolean;
  }
): number[] {
  const safeCorrect = Math.max(0, Math.round(correctAnswer));
  const candidates = new Set<number>([safeCorrect]);

  // 1. Cognitive distractors based on operation context
  const plausibleDistractors: number[] = [];

  if (context?.num1 !== undefined && context?.num2 !== undefined && context?.op) {
    const { num1, num2, op } = context;
    if (op === '+') {
      // Inverted operation slip (subtraction instead of addition)
      if (Math.abs(num1 - num2) > 0 && Math.abs(num1 - num2) !== safeCorrect) {
        plausibleDistractors.push(Math.abs(num1 - num2));
      }
      // Ten-carry slip (+10 or -10)
      if (safeCorrect > 12) plausibleDistractors.push(safeCorrect - 10);
      if (safeCorrect >= 10) plausibleDistractors.push(safeCorrect + 10);
    } else if (op === '-') {
      // Addition instead of subtraction
      if (num1 + num2 <= 120) plausibleDistractors.push(num1 + num2);
      // Ten-borrow slip
      if (safeCorrect + 10 <= num1) plausibleDistractors.push(safeCorrect + 10);
    } else if (op === '×') {
      // Addition instead of multiplication (e.g., 3 x 4 -> 7)
      plausibleDistractors.push(num1 + num2);
      // Adjacent multiplication table steps (num1 * (num2 +- 1))
      if (num2 > 1) plausibleDistractors.push(num1 * (num2 - 1));
      plausibleDistractors.push(num1 * (num2 + 1));
    } else if (op === '÷') {
      // Adjacent quotient
      if (safeCorrect > 1) plausibleDistractors.push(safeCorrect - 1);
      plausibleDistractors.push(safeCorrect + 1);
      if (num2 > 1 && Math.abs(num1 - num2) > 0) {
        plausibleDistractors.push(Math.max(1, safeCorrect + 2));
      }
    }
  }

  // 2. Near-miss arithmetic slips (off-by-1, off-by-2, off-by-3)
  const nearOffsets = shuffleArray([1, -1, 2, -2, 3, -3, 4, -4, 5]);
  for (const offset of nearOffsets) {
    const val = safeCorrect + offset;
    if (val > 0 && val !== safeCorrect) {
      plausibleDistractors.push(val);
    }
  }

  // Pick from plausible distractors until we reach `count`
  for (const d of shuffleArray(plausibleDistractors)) {
    if (candidates.size >= count) break;
    if (d > 0 && d !== safeCorrect) {
      candidates.add(d);
    }
  }

  // Fallback fill if still under `count`
  let step = 1;
  while (candidates.size < count) {
    const candidate = safeCorrect + step;
    if (candidate > 0) candidates.add(candidate);
    step = step > 0 ? -step : -step + 1;
  }

  const result = Array.from(candidates);
  if (context?.sortAscending) {
    return result.sort((a, b) => a - b);
  }
  return shuffleArray(result);
}

/**
 * Generates a guaranteed non-repeating batch of arithmetic problems for a given
 * operation and range. Uses combinatorial pool generation + Fisher-Yates shuffle
 * so small pools (like a single multiplication table) have ZERO duplicates!
 */
export interface GeneratedArithmeticItem {
  id: number;
  num1: number;
  num2: number;
  op: BasicOperator;
  answer: number;
  options: number[];
  signature: string;
}

export function generateUniqueArithmeticBatch(params: {
  count: number;
  operation: BasicOperator | 'mix';
  rangeTier: 'basic' | 'medium' | 'pro';
  selectedTable?: number | 'all';
  deduplicator?: ProblemDeduplicator;
}): GeneratedArithmeticItem[] {
  const {
    count,
    operation,
    rangeTier,
    selectedTable = 'all',
    deduplicator = globalDeduplicator,
  } = params;

  const results: GeneratedArithmeticItem[] = [];
  const batchSignatures = new Set<string>();

  // Special Case: Single Multiplication Table (e.g. Table of 5 for 1..10)
  // Instead of random sampling with replacement (which causes 35% duplicates),
  // we generate the exact permutation of [1..10] shuffled!
  if (operation === '×' && selectedTable !== 'all') {
    const multipliers = shuffleArray([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12].slice(0, Math.max(10, count)));
    for (let i = 0; i < count; i++) {
      const m = multipliers[i % multipliers.length];
      // Randomly swap factor order occasionally to teach commutativity (a × b = b × a)
      const swap = i >= 10 && Math.random() > 0.5;
      const n1 = swap ? m : selectedTable;
      const n2 = swap ? selectedTable : m;
      const ans = n1 * n2;
      const sig = getOperationSignature('×', n1, n2, true);
      batchSignatures.add(sig);
      deduplicator.record(sig);

      results.push({
        id: i + 1,
        num1: n1,
        num2: n2,
        op: '×',
        answer: ans,
        options: generateSmartOptions(ans, 4, { num1: n1, num2: n2, op: '×' }),
        signature: sig,
      });
    }
    return results;
  }

  // General Case with rejection sampling against both current batch and session history
  const opsPool: BasicOperator[] =
    operation === 'mix' ? ['+', '-', '×', '÷'] : [operation];

  for (let i = 0; i < count; i++) {
    let chosenOp: BasicOperator = opsPool[i % opsPool.length];
    if (operation === 'mix') {
      chosenOp = opsPool[randInt(0, opsPool.length - 1)];
    }

    let n1 = 1;
    let n2 = 1;
    let ans = 2;
    let sig = '';

    // Try up to 40 times to find a problem not in the current batch or recent history
    for (let attempt = 0; attempt < 40; attempt++) {
      if (chosenOp === '+') {
        if (rangeTier === 'basic') {
          n1 = randInt(1, 10);
          n2 = randInt(1, 10);
        } else if (rangeTier === 'medium') {
          n1 = randInt(11, 38);
          n2 = randInt(6, 29);
        } else {
          n1 = randInt(25, 68);
          n2 = randInt(18, 55);
        }
        ans = n1 + n2;
      } else if (chosenOp === '-') {
        if (rangeTier === 'basic') {
          n1 = randInt(4, 16);
          n2 = randInt(1, n1 - 1);
        } else if (rangeTier === 'medium') {
          n1 = randInt(20, 55);
          n2 = randInt(6, n1 - 4);
        } else {
          n1 = randInt(45, 100);
          n2 = randInt(14, n1 - 8);
        }
        ans = n1 - n2;
      } else if (chosenOp === '×') {
        if (rangeTier === 'basic') {
          n1 = randInt(2, 6);
          n2 = randInt(2, 6);
        } else if (rangeTier === 'medium') {
          n1 = randInt(3, 9);
          n2 = randInt(3, 9);
        } else {
          n1 = randInt(6, 12);
          n2 = randInt(5, 12);
        }
        ans = n1 * n2;
      } else {
        // '÷' Exact division without remainder
        if (rangeTier === 'basic') {
          n2 = randInt(2, 5);
          ans = randInt(2, 6);
        } else if (rangeTier === 'medium') {
          n2 = randInt(3, 8);
          ans = randInt(3, 9);
        } else {
          n2 = randInt(4, 11);
          ans = randInt(4, 12);
        }
        n1 = n2 * ans;
      }

      sig = getOperationSignature(chosenOp, n1, n2, attempt > 20);

      // First 25 attempts: reject if in current batch OR in global recent history
      if (attempt < 25) {
        if (!batchSignatures.has(sig) && !deduplicator.hasSeen(sig)) {
          break;
        }
      } else {
        // Next attempts: strictly reject if in current batch
        if (!batchSignatures.has(sig)) {
          break;
        }
      }
    }

    batchSignatures.add(sig);
    deduplicator.record(sig);

    results.push({
      id: i + 1,
      num1: n1,
      num2: n2,
      op: chosenOp,
      answer: ans,
      options: generateSmartOptions(ans, 4, { num1: n1, num2: n2, op: chosenOp }),
      signature: sig,
    });
  }

  return results;
}
