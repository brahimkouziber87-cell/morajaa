/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import {
  ADVENTURE_LEVELS,
  WORLDS,
  LevelConfig,
  PuzzleMode,
  DifficultyTier,
  DIFFICULTY_CONFIGS,
  generateDynamicPuzzle,
} from './data/puzzles';
import {
  BridgePuzzleStage,
  BalanceLabStage,
  MagicGridStage,
  CodeBreakerStage,
  SpeedMathStage,
} from './components/PuzzleStages';
import { OwlMascot, InteractiveAbacus, OwlMood } from './components/GameIllustrations';
import { AchievementsView, PlayerProgress } from './components/AchievementsView';
import { PracticeMode, MathOperation } from './components/PracticeMode';
import { TenMinuteMarathon } from './components/TenMinuteMarathon';
import {
  DailyRewardsModal,
  DailyRewardState,
  getTodayDateString,
  isClaimableToday,
} from './components/DailyRewardsModal';
import { coachService } from './utils/pedagogicalCoach';
import { MistakeDetails } from './components/PuzzleStages';
import { sound, formatNum, useGameAudio } from './utils/sound';
import {
  Volume2,
  VolumeX,
  Lightbulb,
  ArrowRight,
  Play,
  RotateCcw,
  Star,
  Sparkles,
  Compass,
  Shuffle,
  Zap,
  Sliders,
  Scale,
  Hash,
  KeyRound,
  Target,
  Trophy,
  Coins,
  Gift,
  Flame,
  Check,
} from 'lucide-react';

type ViewState =
  | 'MAP_MENU'
  | 'PLAYING'
  | 'SPEED_MATH'
  | 'ROUND_SUMMARY'
  | 'ACHIEVEMENTS'
  | 'PRACTICE'
  | 'TEN_MIN_MARATHON';

const STORAGE_KEY = 'mathpuzzle_kids_v2';

const DEFAULT_PROGRESS: PlayerProgress = {
  playerName: 'فارس الأرقام',
  levelStars: { 1: 3 },
  quickSolvedCount: 0,
  currentStreak: 1,
  bestStreak: 1,
  difficultyStats: {
    easy: 1,
    medium: 0,
    hard: 0,
  },
  coins: 80,
  dailyReward: {
    lastClaimDate: null,
    currentStreak: 1,
  },
};

export default function App() {
  const audio = useGameAudio();
  const [view, setView] = useState<ViewState>('MAP_MENU');
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  const [useEastern, setUseEastern] = useState<boolean>(false);
  const [globalDifficulty, setGlobalDifficulty] = useState<DifficultyTier>('easy');
  const [selectedWorldFilter, setSelectedWorldFilter] = useState<number>(0);
  const [practiceOperation, setPracticeOperation] = useState<MathOperation>('+');
  const [justUnlockedNewLevel, setJustUnlockedNewLevel] = useState<boolean>(false);

  // Active Puzzle State
  const [activeLevel, setActiveLevel] = useState<LevelConfig>(ADVENTURE_LEVELS[0]);
  const [isQuickPlay, setIsQuickPlay] = useState<boolean>(false);
  const [quickMode, setQuickMode] = useState<PuzzleMode>('BRIDGE_PUZZLE');
  const [quickSeed, setQuickSeed] = useState<number>(1);

  // Coach & Hint State
  const [hintLevel, setHintLevel] = useState<number>(0);
  const [coachMessage, setCoachMessage] = useState<string>('');
  const [coachMood, setCoachMood] = useState<OwlMood>('idle');
  const [mistakePattern, setMistakePattern] = useState<string | null>(null);
  const [lastEarnedStars, setLastEarnedStars] = useState<number>(3);
  const [showDailyRewardsModal, setShowDailyRewardsModal] = useState<boolean>(false);

  // Player Progress
  const [progress, setProgress] = useState<PlayerProgress>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        return {
          ...DEFAULT_PROGRESS,
          ...parsed,
          difficultyStats: {
            easy: parsed.difficultyStats?.easy ?? 1,
            medium: parsed.difficultyStats?.medium ?? 0,
            hard: parsed.difficultyStats?.hard ?? 0,
          },
        };
      }
    } catch {}
    return DEFAULT_PROGRESS;
  });

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(progress));
    } catch {}
  }, [progress]);

  const toggleSound = () => {
    const next = !soundEnabled;
    setSoundEnabled(next);
    sound.enabled = next;
    if (next) sound.playClick();
  };

  const setDifficulty = (tier: DifficultyTier) => {
    sound.playClick();
    setGlobalDifficulty(tier);
    if (isQuickPlay && view === 'PLAYING') {
      const nextSeed = quickSeed + 1;
      setQuickSeed(nextSeed);
      const generated = generateDynamicPuzzle(quickMode, tier, nextSeed);
      setActiveLevel(generated);
      setHintLevel(0);
      setCoachMessage(generated.storyContext);
      setCoachMood('idle');
    }
  };

  const startAdventureLevel = (level: LevelConfig) => {
    sound.playClick();
    setIsQuickPlay(false);
    setActiveLevel(level);
    setGlobalDifficulty(level.difficulty);
    setHintLevel(0);
    setCoachMessage(level.storyContext);
    setCoachMood('idle');
    setView('PLAYING');
  };

  const startQuickChallenge = (mode: PuzzleMode, diff: DifficultyTier = globalDifficulty) => {
    sound.playClick();
    const nextSeed = quickSeed + 1;
    setQuickSeed(nextSeed);
    setQuickMode(mode);
    setGlobalDifficulty(diff);
    setIsQuickPlay(true);
    const generated = generateDynamicPuzzle(mode, diff, nextSeed);
    setActiveLevel(generated);
    setHintLevel(0);
    setCoachMessage(generated.storyContext);
    setCoachMood('idle');
    setView('PLAYING');
  };

  const startSpeedMath = () => {
    sound.playClick();
    setView('SPEED_MATH');
  };

  const handleRequestHint = () => {
    if (hintLevel < 3) {
      sound.playHint();
      const nextHint = hintLevel + 1;
      setHintLevel(nextHint);
      setCoachMood('thinking');
      setCoachMessage(activeLevel.hints[nextHint - 1]);
    }
  };

  const handleMistake = (msg: string, details?: MistakeDetails) => {
    if (details) {
      const diag = coachService.diagnoseMistake(
        details.guessed,
        details.expected,
        details.operator,
        details.context,
        details.num1,
        details.num2
      );
      setCoachMood(diag.mascotMood);
      setCoachMessage(diag.advice);
      setMistakePattern(diag.patternTitle);
    } else {
      setCoachMood('encouraging');
      setCoachMessage(msg);
      setMistakePattern(null);
    }
  };

  const handleSolvePuzzle = (earnedStars: number) => {
    const isNewLevelUnlocked = !isQuickPlay && !progress.levelStars[activeLevel.id + 1] && earnedStars >= 1;
    setJustUnlockedNewLevel(isNewLevelUnlocked);

    // Smart coach celebration cheering
    const cheer = coachService.logSolve(earnedStars);
    setCoachMood(cheer.mood);
    setCoachMessage(cheer.cheeringMessage);
    setMistakePattern(null);

    // Play rich success sound
    audio.playSuccess();

    // Stagger sounds for stars earned
    for (let i = 1; i <= earnedStars; i++) {
      setTimeout(() => {
        audio.playStarReveal(i);
      }, i * 320);
    }

    // Play celebratory level unlock chime if advancing to a new level
    if (isNewLevelUnlocked) {
      setTimeout(() => {
        audio.playUnlock();
      }, (earnedStars + 1) * 360);
    }

    setLastEarnedStars(earnedStars);

    setProgress((prev) => {
      const nextStreak = earnedStars === 3 ? prev.currentStreak + 1 : 1;
      const nextBest = Math.max(prev.bestStreak, nextStreak);
      const diffKey = activeLevel.difficulty;
      const prevDiffCount = prev.difficultyStats?.[diffKey] ?? 0;

      if (isQuickPlay) {
        return {
          ...prev,
          quickSolvedCount: prev.quickSolvedCount + 1,
          currentStreak: nextStreak,
          bestStreak: nextBest,
          difficultyStats: {
            ...prev.difficultyStats,
            [diffKey]: prevDiffCount + 1,
          },
        };
      } else {
        const existingStars = prev.levelStars[activeLevel.id] ?? 0;
        return {
          ...prev,
          levelStars: {
            ...prev.levelStars,
            [activeLevel.id]: Math.max(existingStars, earnedStars),
          },
          currentStreak: nextStreak,
          bestStreak: nextBest,
          difficultyStats: {
            ...prev.difficultyStats,
            [diffKey]: prevDiffCount + 1,
          },
        };
      }
    });

    setView('ROUND_SUMMARY');
  };

  const handleNextPuzzle = () => {
    sound.playClick();
    if (isQuickPlay) {
      startQuickChallenge(quickMode, globalDifficulty);
    } else {
      const currentIndex = ADVENTURE_LEVELS.findIndex((l) => l.id === activeLevel.id);
      const nextLevel = ADVENTURE_LEVELS[currentIndex + 1];
      if (nextLevel) {
        startAdventureLevel(nextLevel);
      } else {
        setView('ACHIEVEMENTS');
      }
    }
  };

  const totalStarsEarned = Object.values(progress.levelStars).reduce((a, b) => a + b, 0);

  const filteredLevels = ADVENTURE_LEVELS.filter((lvl) => {
    const matchesWorld = selectedWorldFilter === 0 || lvl.worldId === selectedWorldFilter;
    const matchesDifficulty = lvl.difficulty === globalDifficulty;
    return matchesWorld && matchesDifficulty;
  });

  return (
    <div className="min-h-screen flex flex-col bg-[#FFFDF7] text-[#1E293B]">
      {/* =====================================================================
          TOP HEADER BAR
      ===================================================================== */}
      <header className="sticky top-0 z-30 flex items-center justify-between px-4 sm:px-8 py-3.5 bg-[#FFFDF7]/95 backdrop-blur-xs border-b border-[#E5DEC9]">
        <div className="flex items-center gap-3">
          <a
            href="#map"
            onClick={(e) => {
              e.preventDefault();
              sound.playClick();
              setView('MAP_MENU');
            }}
            className="text-xl font-bold font-display tracking-tight text-slate-900 whitespace-nowrap"
          >
            MathPuzzle Kids
          </a>
          <span className="hidden sm:inline-block text-xs text-slate-400">|</span>
          <span className="hidden sm:inline-block text-xs font-bold text-amber-700 bg-amber-50 px-2.5 py-0.5 rounded-full border border-amber-200">
            لعبة الحساب الذكي للأطفال
          </span>
        </div>

        {/* 6 Clean Navigation Links */}
        <nav className="hidden md:flex items-center gap-6 text-sm font-bold text-slate-600">
          {/* 1. خريطة الألغاز */}
          {(() => {
            const isActive = view === 'MAP_MENU' || (view === 'PLAYING' && !isQuickPlay);
            return (
              <a
                href="#map"
                onClick={(e) => {
                  e.preventDefault();
                  audio.playClick();
                  setView('MAP_MENU');
                }}
                className={`relative py-1.5 transition-colors whitespace-nowrap ${
                  isActive
                    ? 'text-amber-700 border-b-2 border-amber-600'
                    : 'hover:text-slate-900'
                }`}
              >
                <span>خريطة الألغاز</span>
                {isActive && (
                  <span className="absolute -bottom-1.5 left-1/2 -translate-x-1/2 flex items-center justify-center pointer-events-none">
                    <span className="w-1.5 h-1.5 rounded-full bg-amber-500 ring-2 ring-amber-300 shadow-[0_0_8px_#f59e0b] animate-pulse" />
                  </span>
                )}
              </a>
            );
          })()}

          {/* 2. وضع الممارسة */}
          {(() => {
            const isActive = view === 'PRACTICE';
            return (
              <a
                href="#practice"
                onClick={(e) => {
                  e.preventDefault();
                  audio.playClick();
                  setView('PRACTICE');
                }}
                className={`relative py-1.5 transition-colors whitespace-nowrap flex items-center gap-1.5 ${
                  isActive
                    ? 'text-indigo-700 border-b-2 border-indigo-600'
                    : 'hover:text-slate-900'
                }`}
              >
                <Target className="w-3.5 h-3.5 text-indigo-500" />
                <span>وضع الممارسة</span>
                {isActive && (
                  <span className="absolute -bottom-1.5 left-1/2 -translate-x-1/2 flex items-center justify-center pointer-events-none">
                    <span className="w-1.5 h-1.5 rounded-full bg-indigo-500 ring-2 ring-indigo-300 shadow-[0_0_8px_#6366f1] animate-pulse" />
                  </span>
                )}
              </a>
            );
          })()}

          {/* 3. تحدي الـ 10 دقائق */}
          {(() => {
            const isActive = view === 'TEN_MIN_MARATHON';
            return (
              <a
                href="#ten-min-marathon"
                onClick={(e) => {
                  e.preventDefault();
                  audio.playClick();
                  setView('TEN_MIN_MARATHON');
                }}
                className={`relative py-1.5 transition-colors whitespace-nowrap flex items-center gap-1.5 ${
                  isActive
                    ? 'text-amber-700 border-b-2 border-amber-600'
                    : 'hover:text-slate-900'
                }`}
              >
                <Trophy className="w-3.5 h-3.5 text-amber-500" />
                <span>تحدي الـ 10 دقائق</span>
                {isActive && (
                  <span className="absolute -bottom-1.5 left-1/2 -translate-x-1/2 flex items-center justify-center pointer-events-none">
                    <span className="w-1.5 h-1.5 rounded-full bg-amber-500 ring-2 ring-amber-300 shadow-[0_0_8px_#f59e0b] animate-pulse" />
                  </span>
                )}
              </a>
            );
          })()}

          {/* 4. التحدي السريع */}
          {(() => {
            const isActive = view === 'PLAYING' && isQuickPlay;
            return (
              <a
                href="#quick-challenge"
                onClick={(e) => {
                  e.preventDefault();
                  startQuickChallenge('BRIDGE_PUZZLE', globalDifficulty);
                }}
                className={`relative py-1.5 transition-colors whitespace-nowrap ${
                  isActive
                    ? 'text-amber-700 border-b-2 border-amber-600'
                    : 'hover:text-slate-900'
                }`}
              >
                <span>التحدي السريع</span>
                {isActive && (
                  <span className="absolute -bottom-1.5 left-1/2 -translate-x-1/2 flex items-center justify-center pointer-events-none">
                    <span className="w-1.5 h-1.5 rounded-full bg-amber-500 ring-2 ring-amber-300 shadow-[0_0_8px_#f59e0b] animate-pulse" />
                  </span>
                )}
              </a>
            );
          })()}

          {/* 5. سباق الحساب */}
          {(() => {
            const isActive = view === 'SPEED_MATH';
            return (
              <a
                href="#speed-blitz"
                onClick={(e) => {
                  e.preventDefault();
                  startSpeedMath();
                }}
                className={`relative py-1.5 transition-colors whitespace-nowrap ${
                  isActive
                    ? 'text-amber-700 border-b-2 border-amber-600'
                    : 'hover:text-slate-900'
                }`}
              >
                <span>سباق الحساب</span>
                {isActive && (
                  <span className="absolute -bottom-1.5 left-1/2 -translate-x-1/2 flex items-center justify-center pointer-events-none">
                    <span className="w-1.5 h-1.5 rounded-full bg-amber-500 ring-2 ring-amber-300 shadow-[0_0_8px_#f59e0b] animate-pulse" />
                  </span>
                )}
              </a>
            );
          })()}

          {/* 6. سجل الإنجازات */}
          {(() => {
            const isActive = view === 'ACHIEVEMENTS';
            return (
              <a
                href="#achievements"
                onClick={(e) => {
                  e.preventDefault();
                  audio.playClick();
                  setView('ACHIEVEMENTS');
                }}
                className={`relative py-1.5 transition-colors whitespace-nowrap ${
                  isActive
                    ? 'text-amber-700 border-b-2 border-amber-600'
                    : 'hover:text-slate-900'
                }`}
              >
                <span>سجل الإنجازات</span>
                {isActive && (
                  <span className="absolute -bottom-1.5 left-1/2 -translate-x-1/2 flex items-center justify-center pointer-events-none">
                    <span className="w-1.5 h-1.5 rounded-full bg-amber-500 ring-2 ring-amber-300 shadow-[0_0_8px_#f59e0b] animate-pulse" />
                  </span>
                )}
              </a>
            );
          })()}
        </nav>

        {/* Primary Controls */}
        <div className="flex items-center gap-2.5">
          <div
            className="px-3 py-1.5 text-xs font-bold text-emerald-800 bg-emerald-50 rounded-lg border border-emerald-200 flex items-center gap-1.5 whitespace-nowrap font-mono-num shadow-xs"
            title="الأرقام المعتمدة رسمياً في المملكة المغربية"
          >
            <span className="w-2 h-2 rounded-full bg-emerald-500 inline-block" />
            <span>الأرقام المغربية (0-9)</span>
          </div>
          <button
            type="button"
            onClick={toggleSound}
            className="px-3 py-1.5 text-xs font-bold text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors flex items-center gap-1.5 whitespace-nowrap"
            aria-label={soundEnabled ? 'كتم الصوت' : 'تشغيل الصوت'}
          >
            {soundEnabled ? <Volume2 className="w-4 h-4 text-amber-400" /> : <VolumeX className="w-4 h-4 text-slate-400" />}
            <span className="hidden sm:inline">{soundEnabled ? 'صوت' : 'صامت'}</span>
          </button>
        </div>
      </header>

      {/* =====================================================================
          OMNIPRESENT DIFFICULTY LEVEL SELECTOR BAR
          (سهل 🟢 / متوسط 🟡 / صعب 🔴)
      ===================================================================== */}
      <section className="bg-[#FAF6EE] border-b border-[#E5DEC9] px-4 sm:px-8 py-3">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <Sliders className="w-4 h-4 text-amber-600 shrink-0" />
            <span className="text-xs font-bold text-slate-700 whitespace-nowrap">
              مستوى الصعوبة المختار:
            </span>
            <span className="text-xs text-slate-500 hidden lg:inline">
              (تتغير الأرقام والعمليات الرياضية فوراً)
            </span>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            {(['easy', 'medium', 'hard'] as DifficultyTier[]).map((tier) => {
              const meta = DIFFICULTY_CONFIGS[tier];
              const isSelected = globalDifficulty === tier;
              return (
                <button
                  key={tier}
                  type="button"
                  onClick={() => setDifficulty(tier)}
                  className={`tactile-button px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all border flex items-center gap-2 whitespace-nowrap ${
                    isSelected
                      ? tier === 'easy'
                        ? 'bg-emerald-600 text-white border-emerald-700 shadow-xs'
                        : tier === 'medium'
                        ? 'bg-amber-600 text-white border-amber-700 shadow-xs'
                        : 'bg-rose-600 text-white border-rose-700 shadow-xs'
                      : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-50'
                  }`}
                >
                  <span className={`w-2 h-2 rounded-full ${tier === 'easy' ? 'bg-emerald-400' : tier === 'medium' ? 'bg-amber-400' : 'bg-rose-400'}`} />
                  <span>{meta.label}</span>
                  <span className={`text-[10px] px-1.5 py-0.2 rounded font-mono-num ${isSelected ? 'bg-black/20 text-white' : 'bg-slate-100 text-slate-600'}`}>
                    {meta.operations.join(' ')}
                  </span>
                </button>
              );
            })}
          </div>

          <div className="text-xs text-slate-500 font-medium">
            نطاق الأعداد: <span className="font-bold text-slate-800 font-mono-num">{DIFFICULTY_CONFIGS[globalDifficulty].numbersRange}</span>
          </div>
        </div>
      </section>

      {/* =====================================================================
          MAIN WORKSPACE CONTENT
      ===================================================================== */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-8 py-8">
        {/* -------------------------------------------------------------------
            VIEW 1: ADVENTURE MAP & MODES ('MAP_MENU')
        ------------------------------------------------------------------- */}
        {view === 'MAP_MENU' && (
          <div className="space-y-8">
            {/* ===============================================================
                DAILY LOGIN REWARDS & COINS TOP BAR (شريط مكافآت الدخول اليومي)
            =============================================================== */}
            <section className="bg-gradient-to-r from-amber-500/10 via-amber-400/20 to-amber-500/10 border-2 border-amber-300 rounded-2xl p-3.5 sm:p-4 flex flex-col sm:flex-row items-center justify-between gap-3 shadow-xs">
              <div className="flex items-center gap-3.5 flex-wrap justify-center sm:justify-start">
                {/* Coins Balance */}
                <div className="flex items-center gap-2 bg-white px-3.5 py-1.5 rounded-xl border border-amber-300 shadow-xs">
                  <Coins className="w-5 h-5 text-amber-500 fill-amber-400 animate-coin-glow" />
                  <span className="text-xs text-slate-500 font-bold">العملات الذهبية:</span>
                  <span className="font-mono-num font-bold text-base text-amber-700">
                    {formatNum(progress.coins ?? 80, useEastern)}
                  </span>
                </div>

                {/* Login Streak */}
                <div className="flex items-center gap-2 bg-white px-3.5 py-1.5 rounded-xl border border-amber-200 shadow-xs">
                  <Flame className="w-4 h-4 text-orange-500 fill-orange-400 animate-bounce" />
                  <span className="text-xs text-slate-500 font-bold">سلسلة الدخول:</span>
                  <span className="font-mono-num font-bold text-sm text-orange-600">
                    {formatNum(progress.dailyReward?.currentStreak ?? 1, useEastern)} أيام متتالية
                  </span>
                </div>
              </div>

              {/* Daily Reward Claim Action */}
              <div className="flex items-center gap-2.5">
                {isClaimableToday(progress.dailyReward?.lastClaimDate ?? null) ? (
                  <button
                    type="button"
                    onClick={() => {
                      audio.playClick();
                      setShowDailyRewardsModal(true);
                    }}
                    className="tactile-button px-5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center gap-2 border-2 border-b-3 border-amber-700 shadow-xs animate-pop whitespace-nowrap"
                  >
                    <Gift className="w-4 h-4 fill-slate-950 animate-bounce" />
                    <span>هدية اليوم بانتظارك! انقر للاستلام 🎁</span>
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={() => {
                      audio.playClick();
                      setShowDailyRewardsModal(true);
                    }}
                    className="px-4 py-2 rounded-xl bg-white hover:bg-slate-50 text-emerald-800 border border-emerald-300 font-bold text-xs flex items-center gap-2 whitespace-nowrap"
                  >
                    <Check className="w-4 h-4 text-emerald-600" />
                    <span>تم استلام هدية اليوم (عرض الأسبوع)</span>
                  </button>
                )}
              </div>
            </section>

            {/* Hero Welcome Card */}
            <section className="tactile-card rounded-3xl p-6 sm:p-8 bg-gradient-to-l from-[#FFFDF7] via-[#FAF5E8] to-[#F3EAD6] flex flex-col lg:flex-row items-center justify-between gap-8">
              <div className="flex flex-col sm:flex-row items-center sm:items-start gap-5 text-center sm:text-right">
                <OwlMascot mood="happy" size={88} />
                <div className="space-y-2.5 max-w-xl">
                  <div className="text-xs font-bold text-amber-800">
                    مرحباً بك يا {progress.playerName} · النجوم: {formatNum(totalStarsEarned, useEastern)} · المستوى الحالي: {DIFFICULTY_CONFIGS[globalDifficulty].label}
                  </div>
                  <h1 className="text-2xl sm:text-4xl font-bold font-display text-slate-900 leading-tight">
                    ألغاز الحساب الذكي وتطوير المهارات الرياضية
                  </h1>
                  <p className="text-sm sm:text-base text-slate-600 leading-relaxed">
                    اختر مستوى الصعوبة المناسب لعمرك: <span className="font-bold text-emerald-700">سهل</span> (جمع وطرح)، <span className="font-bold text-amber-700">متوسط</span> (جداول الضرب حتى 50)، أو <span className="font-bold text-rose-700">صعب</span> (قسمة ومعادلات مركبة حتى 100).
                  </p>
                </div>
              </div>

              <div className="flex flex-col sm:flex-row lg:flex-col items-stretch gap-3 shrink-0 w-full sm:w-auto">
                <button
                  type="button"
                  onClick={() => {
                    const nextLvl = filteredLevels[0] || ADVENTURE_LEVELS[0];
                    startAdventureLevel(nextLvl);
                  }}
                  className="tactile-button px-7 py-4 rounded-2xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-display font-bold text-base border-2 border-b-4 border-amber-700 flex items-center justify-center gap-2.5 whitespace-nowrap"
                >
                  <Play className="w-5 h-5 fill-current" />
                  <span>ابدأ مستوى ({DIFFICULTY_CONFIGS[globalDifficulty].label})</span>
                </button>
                <button
                  type="button"
                  onClick={() => startSpeedMath()}
                  className="tactile-button px-6 py-3 rounded-xl bg-white hover:bg-slate-50 text-slate-800 font-display font-bold text-sm border-2 border-b-4 border-[#D6CFC2] flex items-center justify-center gap-2 whitespace-nowrap"
                >
                  <Zap className="w-4 h-4 text-amber-600 fill-amber-500" />
                  <span>سباق الحساب بالوقت</span>
                </button>
              </div>
            </section>

            {/* =====================================================================
                10-MINUTE CHALLENGE BANNER ('تحدي العشر دقائق' في خريطة الألغاز)
            ===================================================================== */}
            <section className="tactile-card rounded-3xl p-6 sm:p-7 bg-gradient-to-l from-amber-50 via-orange-50/50 to-white border-2 border-amber-300 shadow-sm flex flex-col md:flex-row items-center justify-between gap-6">
              <div className="flex items-center gap-5 text-center sm:text-right">
                <div className="p-3.5 bg-amber-100 text-amber-700 rounded-3xl border-2 border-amber-300 shrink-0">
                  <Trophy className="w-9 h-9 animate-bounce text-amber-600" />
                </div>
                <div className="space-y-1.5">
                  <div className="flex items-center gap-2 justify-center sm:justify-start">
                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-500 text-slate-950">
                      تحدي العشر دقائق ⏱️
                    </span>
                    <span className="text-xs text-slate-500 font-medium hidden sm:inline">
                      (حل أكبر عدد من الألغاز في وقت قياسي مع لوحة صدارة محلية)
                    </span>
                  </div>
                  <h3 className="text-xl sm:text-2xl font-bold font-display text-slate-900">
                    ماراثون العشر دقائق الذهبية
                  </h3>
                  <p className="text-xs sm:text-sm text-slate-600 max-w-lg leading-relaxed">
                    أثبت مهارتك في حل سيلاً متواصلاً من الألغاز الحسابية خلال 10 دقائق، واحصل على أوسمة شرفية، وتصدر لوحة الأبطال، واكسب عملات ذهبية إضافية!
                  </p>
                </div>
              </div>

              <div className="flex flex-col sm:flex-row md:flex-col items-stretch gap-2.5 shrink-0 w-full sm:w-auto">
                <button
                  type="button"
                  onClick={() => {
                    audio.playClick();
                    setView('TEN_MIN_MARATHON');
                  }}
                  className="tactile-button px-7 py-3.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-display font-bold text-sm border-2 border-b-4 border-amber-700 flex items-center justify-center gap-2 whitespace-nowrap shadow-xs"
                >
                  <Play className="w-4 h-4 fill-current" />
                  <span>ابدأ تحدي العشر دقائق</span>
                </button>
              </div>
            </section>

            {/* =====================================================================
                TARGETED OPERATION PRACTICE MODE (مدمج في واجهة خريطة الألغاز)
                يسمح للطفل باختيار عملية محددة (جمع فقط، طرح، ضرب، قسمة) بحرية
            ===================================================================== */}
            <section className="tactile-card rounded-3xl p-6 sm:p-7 bg-gradient-to-l from-white via-indigo-50/50 to-purple-50/60 border-2 border-indigo-200/90 shadow-sm space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="space-y-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-indigo-600 text-white flex items-center gap-1">
                      <Target className="w-3.5 h-3.5" />
                      <span>وضع الممارسة الموجهة</span>
                    </span>
                    <span className="text-xs text-slate-500 font-medium">
                      (تدرّب على عملية محددة دون التقيد بمستوى الصعوبة العام)
                    </span>
                  </div>
                  <h3 className="text-lg sm:text-xl font-bold font-display text-slate-900">
                    هل تريد تقوية مهارة معينة؟ اختر عمليتك الرياضية الآن:
                  </h3>
                </div>

                <button
                  type="button"
                  onClick={() => {
                    audio.playClick();
                    setPracticeOperation('mix');
                    setView('PRACTICE');
                  }}
                  className="tactile-button px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold font-display flex items-center justify-center gap-2 self-start sm:self-auto shadow-xs whitespace-nowrap"
                >
                  <Sparkles className="w-4 h-4 text-amber-300" />
                  <span>فتح مختبر الممارسة الشامل</span>
                </button>
              </div>

              {/* 5 Operation Selector Cards */}
              <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 pt-1">
                {[
                  {
                    op: '+' as const,
                    name: 'الجمع فقط',
                    badge: '➕',
                    desc: 'ضم المجموعات وتكوين العشرات',
                    borderHover: 'hover:border-emerald-500 hover:bg-emerald-50/70',
                    badgeBg: 'bg-emerald-100 text-emerald-800',
                  },
                  {
                    op: '-' as const,
                    name: 'الطرح فقط',
                    badge: '➖',
                    desc: 'الفروقات والعد التنازلي',
                    borderHover: 'hover:border-sky-500 hover:bg-sky-50/70',
                    badgeBg: 'bg-sky-100 text-sky-800',
                  },
                  {
                    op: '×' as const,
                    name: 'الضرب فقط',
                    badge: '✖️',
                    desc: 'جداول الضرب والتكرار الذكي',
                    borderHover: 'hover:border-amber-500 hover:bg-amber-50/70',
                    badgeBg: 'bg-amber-100 text-amber-800',
                  },
                  {
                    op: '÷' as const,
                    name: 'القسمة فقط',
                    badge: '➗',
                    desc: 'التوزيع المتساوي العادل',
                    borderHover: 'hover:border-purple-500 hover:bg-purple-50/70',
                    badgeBg: 'bg-purple-100 text-purple-800',
                  },
                  {
                    op: 'mix' as const,
                    name: 'مزيج العمليات',
                    badge: '🔀',
                    desc: 'تحدي العمليات الأربعة',
                    borderHover: 'hover:border-pink-500 hover:bg-pink-50/70',
                    badgeBg: 'bg-pink-100 text-pink-800',
                  },
                ].map((item) => (
                  <button
                    key={item.op}
                    type="button"
                    onClick={() => {
                      audio.playClick();
                      setPracticeOperation(item.op);
                      setView('PRACTICE');
                    }}
                    className={`tactile-card rounded-2xl p-4 text-right transition-all border border-slate-200 bg-white ${item.borderHover} group flex flex-col justify-between`}
                  >
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <span className={`w-8 h-8 rounded-xl flex items-center justify-center text-sm font-bold ${item.badgeBg} group-hover:scale-110 transition-transform`}>
                          {item.badge}
                        </span>
                        <span className="text-[10px] font-bold text-slate-400 font-mono-num">
                          10 تمارين
                        </span>
                      </div>
                      <h4 className="font-bold text-sm text-slate-900 group-hover:text-indigo-700 transition-colors">
                        {item.name}
                      </h4>
                      <p className="text-[11px] text-slate-500 mt-1 line-clamp-2 leading-relaxed">
                        {item.desc}
                      </p>
                    </div>

                    <div className="mt-3 pt-2 border-t border-slate-100 text-[11px] font-bold text-indigo-600 group-hover:text-indigo-800 flex items-center gap-1 justify-end">
                      <span>ابدأ التمرين</span>
                      <ArrowRight className="w-3 h-3 rotate-180" />
                    </div>
                  </button>
                ))}
              </div>
            </section>

            {/* Quick Modes Row */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              <button
                type="button"
                onClick={() => startQuickChallenge('BRIDGE_PUZZLE', globalDifficulty)}
                className="tactile-card rounded-2xl p-4 text-right hover:border-emerald-500 transition-colors flex flex-col justify-between"
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="p-2 bg-emerald-50 text-emerald-700 rounded-xl">
                    <Hash className="w-5 h-5" />
                  </span>
                  <span className="text-[10px] font-bold text-slate-400">توليد فوري</span>
                </div>
                <h3 className="font-bold text-sm text-slate-900">الجسور والأنماط</h3>
                <p className="text-xs text-slate-500 mt-1">متتاليات وحساب مفقود</p>
              </button>

              <button
                type="button"
                onClick={() => startQuickChallenge('BALANCE_LAB', globalDifficulty)}
                className="tactile-card rounded-2xl p-4 text-right hover:border-sky-500 transition-colors flex flex-col justify-between"
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="p-2 bg-sky-50 text-sky-700 rounded-xl">
                    <Scale className="w-5 h-5" />
                  </span>
                  <span className="text-[10px] font-bold text-slate-400">توليد فوري</span>
                </div>
                <h3 className="font-bold text-sm text-slate-900">مختبر الميزان</h3>
                <p className="text-xs text-slate-500 mt-1">توازن الصندوق المجهول</p>
              </button>

              <button
                type="button"
                onClick={() => startQuickChallenge('MAGIC_GRID', globalDifficulty)}
                className="tactile-card rounded-2xl p-4 text-right hover:border-amber-500 transition-colors flex flex-col justify-between"
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="p-2 bg-amber-50 text-amber-700 rounded-xl">
                    <Sparkles className="w-5 h-5" />
                  </span>
                  <span className="text-[10px] font-bold text-slate-400">توليد فوري</span>
                </div>
                <h3 className="font-bold text-sm text-slate-900">الشبكات السحرية</h3>
                <p className="text-xs text-slate-500 mt-1">صفوف وأعمدة موزونة</p>
              </button>

              <button
                type="button"
                onClick={() => startQuickChallenge('CODE_BREAKER', globalDifficulty)}
                className="tactile-card rounded-2xl p-4 text-right hover:border-indigo-500 transition-colors flex flex-col justify-between"
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="p-2 bg-indigo-50 text-indigo-700 rounded-xl">
                    <KeyRound className="w-5 h-5" />
                  </span>
                  <span className="text-[10px] font-bold text-slate-400">توليد فوري</span>
                </div>
                <h3 className="font-bold text-sm text-slate-900">خزينة الشفرات</h3>
                <p className="text-xs text-slate-500 mt-1">استنتاج قيم الرموز</p>
              </button>
            </div>

            {/* Adventure World Filter Tabs */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#E5DEC9] pb-4">
              <div>
                <h2 className="text-xl font-bold font-display text-slate-900">
                  مراحل المغامرة الحسابية (المستوى: {DIFFICULTY_CONFIGS[globalDifficulty].label})
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  العمليات النشطة: {DIFFICULTY_CONFIGS[globalDifficulty].operations.join(' ، ')} | الأعداد: {DIFFICULTY_CONFIGS[globalDifficulty].numbersRange}
                </p>
              </div>

              <div className="flex items-center gap-1 p-1 bg-[#F4EFE6] rounded-xl border border-[#E2D9C8]">
                <button
                  type="button"
                  onClick={() => setSelectedWorldFilter(0)}
                  className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-colors whitespace-nowrap ${
                    selectedWorldFilter === 0 ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  جميع الجزر
                </button>
                {WORLDS.map((w) => (
                  <button
                    key={w.id}
                    type="button"
                    onClick={() => setSelectedWorldFilter(w.id)}
                    className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-colors whitespace-nowrap ${
                      selectedWorldFilter === w.id ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    {w.name.split(' ')[0]} {w.name.split(' ')[1]}
                  </button>
                ))}
              </div>
            </div>

            {/* Adventure Level Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
              {filteredLevels.map((lvl) => {
                const earned = progress.levelStars[lvl.id] ?? 0;
                return (
                  <div
                    key={lvl.id}
                    className="tactile-card rounded-2xl p-5 flex flex-col justify-between bg-white hover:border-amber-400 transition-colors"
                  >
                    <div className="space-y-2.5">
                      <div className="flex items-center justify-between text-xs text-slate-500">
                        <span>المرحلة {formatNum(lvl.id, useEastern)} · {lvl.worldName}</span>
                        <span className="font-mono-num font-bold text-amber-600">
                          {'★'.repeat(earned)}{'☆'.repeat(3 - earned)}
                        </span>
                      </div>

                      <h4 className="text-lg font-bold font-display text-slate-900">
                        {lvl.title}
                      </h4>

                      <p className="text-xs text-slate-600 leading-relaxed">
                        {lvl.storyContext}
                      </p>
                    </div>

                    <div className="pt-5 mt-4 border-t border-slate-100 flex items-center justify-between">
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded border ${DIFFICULTY_CONFIGS[lvl.difficulty].badgeBg}`}>
                        {DIFFICULTY_CONFIGS[lvl.difficulty].label}
                      </span>
                      <button
                        type="button"
                        onClick={() => startAdventureLevel(lvl)}
                        className="tactile-button px-4 py-2 rounded-xl text-xs font-bold font-display bg-slate-900 hover:bg-amber-600 text-white transition-colors flex items-center gap-1.5 whitespace-nowrap"
                      >
                        <span>ابدأ اللغز</span>
                        <Play className="w-3.5 h-3.5 fill-current" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* If no exact level in current world filter matches difficulty */}
            {filteredLevels.length === 0 && (
              <div className="text-center py-10 bg-white rounded-2xl border border-dashed border-slate-300 space-y-3">
                <p className="text-sm font-bold text-slate-700">
                  لا توجد مراحل محددة في هذه الجزيرة بنفس مستوى الصعوبة المختار.
                </p>
                <button
                  type="button"
                  onClick={() => startQuickChallenge('BRIDGE_PUZZLE', globalDifficulty)}
                  className="tactile-button px-5 py-2.5 rounded-xl bg-amber-500 text-slate-900 font-bold text-xs"
                >
                  توليد لغز فوري بالمستوى ({DIFFICULTY_CONFIGS[globalDifficulty].label})
                </button>
              </div>
            )}
          </div>
        )}

        {/* -------------------------------------------------------------------
            VIEW 2: ACTIVE PUZZLE STAGE ('PLAYING')
        ------------------------------------------------------------------- */}
        {view === 'PLAYING' && (
          <div className="space-y-6">
            <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-[#E5DEC9]">
              <div className="flex items-center gap-3">
                <button
                  type="button"
                  onClick={() => {
                    sound.playClick();
                    setView('MAP_MENU');
                  }}
                  className="px-3 py-1.5 text-xs font-bold text-slate-700 bg-[#F4EFE6] hover:bg-[#E8E0D0] rounded-xl border border-[#DCD2C0] flex items-center gap-1.5 whitespace-nowrap"
                >
                  <ArrowRight className="w-4 h-4" />
                  <span>العودة للخريطة</span>
                </button>
                <div>
                  <div className="text-xs text-slate-500 flex items-center gap-2">
                    <span>{activeLevel.worldName}</span>
                    <span>·</span>
                    <span className={`px-2 py-0.2 rounded text-[10px] font-bold border ${DIFFICULTY_CONFIGS[activeLevel.difficulty].badgeBg}`}>
                      {DIFFICULTY_CONFIGS[activeLevel.difficulty].label}
                    </span>
                  </div>
                  <h1 className="text-xl font-bold font-display text-slate-900">
                    {activeLevel.title}
                  </h1>
                </div>
              </div>

              {/* Mode switch for Quick Play */}
              {isQuickPlay ? (
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => startQuickChallenge(quickMode, globalDifficulty)}
                    className="tactile-button px-3.5 py-1.5 rounded-xl bg-amber-100 hover:bg-amber-200 text-amber-900 text-xs font-bold flex items-center gap-1.5"
                  >
                    <Shuffle className="w-3.5 h-3.5" />
                    <span>لغز آخر بنفس المستوى</span>
                  </button>
                </div>
              ) : (
                <div className="text-xs text-slate-500">
                  المرحلة {formatNum(activeLevel.id, useEastern)} من {formatNum(ADVENTURE_LEVELS.length, useEastern)}
                </div>
              )}
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
              {/* Active Stage (7 cols) */}
              <div className="lg:col-span-7 tactile-card rounded-3xl p-6 sm:p-7 bg-white">
                {activeLevel.mode === 'BRIDGE_PUZZLE' && (
                  <BridgePuzzleStage
                    level={activeLevel}
                    useEastern={useEastern}
                    hintLevel={hintLevel}
                    onSolve={handleSolvePuzzle}
                    onMistake={handleMistake}
                  />
                )}
                {activeLevel.mode === 'BALANCE_LAB' && (
                  <BalanceLabStage
                    level={activeLevel}
                    useEastern={useEastern}
                    hintLevel={hintLevel}
                    onSolve={handleSolvePuzzle}
                    onMistake={handleMistake}
                  />
                )}
                {activeLevel.mode === 'MAGIC_GRID' && (
                  <MagicGridStage
                    level={activeLevel}
                    useEastern={useEastern}
                    hintLevel={hintLevel}
                    onSolve={handleSolvePuzzle}
                    onMistake={handleMistake}
                  />
                )}
                {activeLevel.mode === 'CODE_BREAKER' && (
                  <CodeBreakerStage
                    level={activeLevel}
                    useEastern={useEastern}
                    hintLevel={hintLevel}
                    onSolve={handleSolvePuzzle}
                    onMistake={handleMistake}
                  />
                )}
              </div>

              {/* Pedagogical Deck & Abacus (5 cols) */}
              <div className="lg:col-span-5 space-y-5">
                <div className="tactile-card rounded-2xl p-5 bg-white space-y-4">
                  <div className="flex items-start gap-3.5">
                    <OwlMascot mood={coachMood} size={64} />
                    <div className="space-y-1.5 flex-1">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-amber-800">
                          بومة الحكمة الذكية
                        </span>
                        <span className="text-xs text-slate-400 font-mono-num">
                          تلميحات: {formatNum(hintLevel, useEastern)}/{formatNum(3, useEastern)}
                        </span>
                      </div>
                      {mistakePattern && (
                        <div className="flex items-center gap-1.5 text-[11px] font-bold text-amber-900 bg-amber-100/95 px-2.5 py-1 rounded-lg border border-amber-300 w-fit animate-pop">
                          <Lightbulb className="w-3.5 h-3.5 text-amber-600" />
                          <span>تحليل ذكي: {mistakePattern}</span>
                        </div>
                      )}
                      <p className="text-sm font-medium text-slate-800 leading-relaxed bg-[#FAF6EE] p-3 rounded-xl border border-[#E5DEC9]">
                        {formatNum(coachMessage, useEastern)}
                      </p>
                    </div>
                  </div>

                  {hintLevel > 0 && (
                    <div className="space-y-2 pt-2 border-t border-slate-100">
                      <span className="text-xs font-bold text-slate-500 block">
                        خطوات الإرشاد الرياضي:
                      </span>
                      {activeLevel.hints.slice(0, hintLevel).map((h, i) => (
                        <div
                          key={i}
                          className="text-xs text-emerald-950 bg-emerald-50/90 px-3 py-2 rounded-xl border border-emerald-200 leading-relaxed animate-pop"
                        >
                          <span className="font-bold">خطوة {formatNum(i + 1, useEastern)}: </span>
                          {formatNum(h, useEastern)}
                        </div>
                      ))}
                    </div>
                  )}

                  <button
                    type="button"
                    onClick={handleRequestHint}
                    disabled={hintLevel >= 3}
                    className="tactile-button w-full py-2.5 px-4 rounded-xl bg-amber-100 hover:bg-amber-200/80 text-amber-950 font-display font-bold text-xs border border-b-3 border-amber-300 disabled:opacity-40 flex items-center justify-center gap-2 whitespace-nowrap"
                  >
                    <Lightbulb className="w-4 h-4 text-amber-600" />
                    <span>
                      {hintLevel === 0
                        ? 'طلب تلميح توضيحي (خطوة 1 من 3)'
                        : hintLevel < 3
                        ? `اكشف الخطوة التالية (${formatNum(hintLevel + 1, useEastern)} من ${formatNum(3, useEastern)})`
                        : 'تم عرض كل التلميحات المتاحة'}
                    </span>
                  </button>
                </div>

                <InteractiveAbacus useEastern={useEastern} />
              </div>
            </div>
          </div>
        )}

        {/* -------------------------------------------------------------------
            VIEW 3: SPEED MATH BLITZ ('SPEED_MATH')
        ------------------------------------------------------------------- */}
        {view === 'SPEED_MATH' && (
          <div className="max-w-2xl mx-auto space-y-6">
            <div className="flex items-center justify-between pb-4 border-b border-[#E5DEC9]">
              <button
                type="button"
                onClick={() => setView('MAP_MENU')}
                className="px-3 py-1.5 text-xs font-bold text-slate-700 bg-[#F4EFE6] rounded-xl border border-[#DCD2C0] flex items-center gap-1.5"
              >
                <ArrowRight className="w-4 h-4" />
                <span>العودة</span>
              </button>
              <h1 className="text-xl font-bold font-display text-slate-900">
                سباق الحساب الذهني بالوقت
              </h1>
              <div className={`text-xs font-bold px-2.5 py-1 rounded-lg border ${DIFFICULTY_CONFIGS[globalDifficulty].badgeBg}`}>
                {DIFFICULTY_CONFIGS[globalDifficulty].label}
              </div>
            </div>

            <SpeedMathStage
              difficulty={globalDifficulty}
              useEastern={useEastern}
              onComplete={(score, total) => {
                sound.playFanfare();
                setCoachMood('happy');
                setCoachMessage(`أتممت سباق الحساب بنتيجة ${formatNum(score, useEastern)} من ${formatNum(total, useEastern)}!`);
                setProgress((prev) => ({
                  ...prev,
                  quickSolvedCount: prev.quickSolvedCount + score,
                }));
              }}
            />
          </div>
        )}

        {/* -------------------------------------------------------------------
            VIEW 4: ROUND SUMMARY ('ROUND_SUMMARY')
        ------------------------------------------------------------------- */}
        {view === 'ROUND_SUMMARY' && (
          <div className="max-w-xl mx-auto my-8 tactile-card rounded-3xl p-8 bg-white text-center space-y-6 animate-pop">
            <div className="flex justify-center">
              <OwlMascot mood="happy" size={96} />
            </div>

            <div className="space-y-2">
              <div className="text-xs font-bold text-emerald-700">
                ✓ اكتمل اللغز بنجاح · المستوى: {DIFFICULTY_CONFIGS[activeLevel.difficulty].label}
              </div>
              <h2 className="text-3xl font-bold font-display text-slate-900">
                إنجاز رائع يا {progress.playerName}!
              </h2>
              <p className="text-sm text-slate-600">
                لقد حللت لغز «{activeLevel.title}» بمهارة وتفكير رياضي دقيق.
              </p>
            </div>

            {/* Celebratory Level Unlock Notification if a new adventure level was opened */}
            {justUnlockedNewLevel && (
              <div className="bg-gradient-to-r from-amber-500/15 via-amber-400/25 to-amber-500/15 border-2 border-amber-300 rounded-2xl p-4 text-amber-900 text-sm font-bold flex items-center justify-center gap-2.5 animate-bounce shadow-xs">
                <span className="text-xl">🔓</span>
                <span>مبروك! لقد قمت بفتح مرحلة جديدة في خريطة المغامرة!</span>
                <span className="text-xl">🎉</span>
              </div>
            )}

            <div className="flex items-center justify-center gap-3 py-2">
              {[1, 2, 3].map((starNum) => {
                const earned = starNum <= lastEarnedStars;
                return (
                  <div
                    key={starNum}
                    className={`p-3 rounded-2xl border-2 transition-all duration-300 ${
                      earned ? 'bg-amber-50 border-amber-300 text-amber-500 scale-105 shadow-sm' : 'bg-slate-50 border-slate-200 text-slate-300'
                    }`}
                  >
                    <Star className={`w-10 h-10 ${earned ? 'fill-amber-400 text-amber-500 animate-pop' : ''}`} />
                  </div>
                );
              })}
            </div>

            <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
              <button
                type="button"
                onClick={handleNextPuzzle}
                className="tactile-button w-full sm:w-auto px-7 py-3.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-display font-bold text-sm border-b-4 border-emerald-800 flex items-center justify-center gap-2 whitespace-nowrap"
              >
                <Sparkles className="w-4 h-4" />
                <span>اللغز التالي</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  if (isQuickPlay) {
                    startQuickChallenge(quickMode, globalDifficulty);
                  } else {
                    startAdventureLevel(activeLevel);
                  }
                }}
                className="tactile-button w-full sm:w-auto px-5 py-3.5 rounded-xl bg-[#F4EFE6] hover:bg-[#EAE2D3] text-slate-800 font-display font-bold text-sm border-b-4 border-[#D6CFC2] flex items-center justify-center gap-2 whitespace-nowrap"
              >
                <RotateCcw className="w-4 h-4" />
                <span>إعادة اللعب</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  sound.playClick();
                  setView('MAP_MENU');
                }}
                className="tactile-button w-full sm:w-auto px-5 py-3.5 rounded-xl bg-white hover:bg-slate-50 text-slate-700 font-display font-bold text-sm border border-slate-300 flex items-center justify-center gap-2 whitespace-nowrap"
              >
                <Compass className="w-4 h-4" />
                <span>الخريطة</span>
              </button>
            </div>
          </div>
        )}

        {/* -------------------------------------------------------------------
            VIEW 5: TARGETED OPERATION PRACTICE MODE ('PRACTICE')
        ------------------------------------------------------------------- */}
        {view === 'PRACTICE' && (
          <PracticeMode
            useEastern={useEastern}
            initialOperation={practiceOperation}
            onExit={() => {
              audio.playClick();
              setView('MAP_MENU');
            }}
            onCompleteSession={(correctCount, total) => {
              setProgress((prev) => ({
                ...prev,
                quickSolvedCount: prev.quickSolvedCount + correctCount,
                currentStreak: correctCount >= 7 ? prev.currentStreak + 1 : prev.currentStreak,
                bestStreak: Math.max(prev.bestStreak, prev.currentStreak),
              }));
            }}
          />
        )}

        {/* -------------------------------------------------------------------
            VIEW 6: TEN-MINUTE MARATHON ('TEN_MIN_MARATHON')
        ------------------------------------------------------------------- */}
        {view === 'TEN_MIN_MARATHON' && (
          <TenMinuteMarathon
            useEastern={useEastern}
            defaultPlayerName={progress.playerName}
            globalDifficulty={globalDifficulty}
            onExit={() => {
              audio.playClick();
              setView('MAP_MENU');
            }}
            onAwardCoins={(earned) => {
              setProgress((prev) => ({
                ...prev,
                coins: (prev.coins ?? 80) + earned,
              }));
            }}
          />
        )}

        {/* -------------------------------------------------------------------
            VIEW 7: ACHIEVEMENTS & CERTIFICATE ('ACHIEVEMENTS')
        ------------------------------------------------------------------- */}
        {view === 'ACHIEVEMENTS' && (
          <AchievementsView
            progress={progress}
            useEastern={useEastern}
            onUpdateName={(name) => setProgress((prev) => ({ ...prev, playerName: name }))}
            onResetProgress={() => setProgress(DEFAULT_PROGRESS)}
            onSelectLevel={(lvlId) => {
              const found = ADVENTURE_LEVELS.find((l) => l.id === lvlId);
              if (found) startAdventureLevel(found);
            }}
          />
        )}
      </main>

      {/* Daily Rewards Modal when triggered */}
      {showDailyRewardsModal && (
        <DailyRewardsModal
          state={{
            lastClaimDate: progress.dailyReward?.lastClaimDate ?? null,
            currentStreak: progress.dailyReward?.currentStreak ?? 1,
            totalCoins: progress.coins ?? 80,
            claimedHistory: [],
          }}
          useEastern={useEastern}
          onClaim={(coinsEarned) => {
            setProgress((prev) => ({
              ...prev,
              coins: (prev.coins ?? 80) + coinsEarned,
              dailyReward: {
                lastClaimDate: getTodayDateString(),
                currentStreak: ((prev.dailyReward?.currentStreak ?? 1) % 7) + 1,
              },
            }));
          }}
          onClose={() => setShowDailyRewardsModal(false)}
        />
      )}

      {/* Footer */}
      <footer className="mt-auto border-t border-[#E5DEC9] bg-[#FAF6EE] py-5 px-4 sm:px-8">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <span>
            MathPuzzle Kids · مختبر الألعاب الرياضية التعليمية للأطفال
          </span>
          <div className="flex items-center gap-4 flex-wrap justify-center">
            <button type="button" onClick={() => setView('MAP_MENU')} className="hover:text-slate-800">
              الخريطة
            </button>
            <span>·</span>
            <button type="button" onClick={() => { audio.playClick(); setView('PRACTICE'); }} className="hover:text-slate-800">
              وضع الممارسة
            </button>
            <span>·</span>
            <button type="button" onClick={() => { audio.playClick(); setView('TEN_MIN_MARATHON'); }} className="hover:text-slate-800 font-bold text-amber-700">
              تحدي الـ 10 دقائق
            </button>
            <span>·</span>
            <button type="button" onClick={() => startSpeedMath()} className="hover:text-slate-800">
              سباق الحساب
            </button>
            <span>·</span>
            <button type="button" onClick={() => setView('ACHIEVEMENTS')} className="hover:text-slate-800">
              الشهادة والإنجازات
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
}
